from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import os
from dotenv import load_dotenv
from binance.client import Client
from web3 import Web3

load_dotenv()

app = FastAPI()

# CORS middleware configuration with expanded origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "https://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Binance client
binance_client = Client(
    os.getenv('BINANCE_API_KEY'),
    os.getenv('BINANCE_API_SECRET')
)

# Initialize Web3
try:
    w3 = Web3(Web3.HTTPProvider(os.getenv('ETH_NODE_URL')))
except Exception as e:
    print(f"Warning: Failed to initialize Ethereum provider: {e}")
    w3 = None

class ArbitrageOpportunity(BaseModel):
    exchange_pair: str
    price_difference: float
    potential_profit: float
    timestamp: int

@app.get("/")
async def root():
    return {"message": "Crypto Arbitrage API"}

@app.get("/health")
async def health_check():
    return {"status": "ok", "version": "1.0.0"}

@app.get("/opportunities", response_model=List[ArbitrageOpportunity])
async def get_arbitrage_opportunities():
    try:
        # This is a placeholder. Implement actual arbitrage detection logic here
        opportunities = [
            {
                "exchange_pair": "Binance/Uniswap",
                "price_difference": 0.15,
                "potential_profit": 123.45,
                "timestamp": 1625097600
            },
            {
                "exchange_pair": "Bybit/OKX",
                "price_difference": 0.12,
                "potential_profit": 98.76,
                "timestamp": 1625097600
            },
            {
                "exchange_pair": "Deribit/Binance",
                "price_difference": 0.18,
                "potential_profit": 145.67,
                "timestamp": 1625097600
            }
        ]
        return opportunities
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/balances")
async def get_balances():
    try:
        # Get Binance balance
        binance_balance = {"status": "simulated", "balances": [
            {"asset": "BTC", "free": "1.0", "locked": "0.0"},
            {"asset": "ETH", "free": "10.0", "locked": "0.0"},
            {"asset": "USDT", "free": "10000.0", "locked": "0.0"}
        ]}
        
        # Get ETH balance
        eth_balance = 0
        if w3 and os.getenv('ETH_WALLET_ADDRESS'):
            try:
                eth_balance = w3.eth.get_balance(os.getenv('ETH_WALLET_ADDRESS'))
                eth_balance = w3.from_wei(eth_balance, 'ether')
            except Exception as e:
                print(f"Error getting ETH balance: {e}")
                eth_balance = 5.0  # Fallback for demo
        else:
            eth_balance = 5.0  # Fallback for demo
        
        return {
            "binance": binance_balance,
            "ethereum": eth_balance
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/market-prices")
async def get_market_prices():
    try:
        # This is a placeholder. Implement actual market price fetching logic here
        prices = [
            {
                "token": "BTC",
                "spotPrice": 35000.0,
                "futuresPrice": 35700.0,
                "fundingRate": 0.0001,
                "source": "binance",
                "target": "binance",
                "category": "cex"
            },
            {
                "token": "ETH",
                "spotPrice": 2000.0,
                "futuresPrice": 2050.0,
                "fundingRate": 0.0001,
                "source": "binance",
                "target": "binance",
                "category": "cex"
            },
            {
                "token": "SOL",
                "spotPrice": 100.0,
                "futuresPrice": 102.5,
                "fundingRate": 0.0002,
                "source": "binance",
                "target": "binance",
                "category": "cex"
            }
        ]
        return prices
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)