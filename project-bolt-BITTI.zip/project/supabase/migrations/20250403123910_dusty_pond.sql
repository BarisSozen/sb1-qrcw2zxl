/*
  # Add Error Reports Table

  1. New Tables
    - `error_reports`
      - Stores generated error reports
      - Tracks report type and generation time
      - Contains full report content
*/

-- Create error_reports table
CREATE TABLE IF NOT EXISTS error_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_type text NOT NULL CHECK (report_type IN ('monthly', 'manual')),
  content text NOT NULL,
  generated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE error_reports ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated users can view error reports"
  ON error_reports
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert error reports"
  ON error_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_error_reports_type ON error_reports(report_type);
CREATE INDEX idx_error_reports_generated_at ON error_reports(generated_at);