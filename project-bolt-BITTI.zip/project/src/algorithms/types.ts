/**
 * Trading algorithm type definitions
 * 
 * This file contains TypeScript type definitions for the trading algorithms,
 * including trade opportunities, results, and risk assessments.
 */

import { MarketPrice } from '../types/market';

/**
 * Trade opportunity interface
 * 
 * Represents a detected trading opportunity.
 */
export interface TradeOpportunity {
  id: string;
  type: 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular';
  token: string;
  entry: {
    exchange: string;
    price: number;
    timestamp: number;
  };
  exit: {
    exchange: string;
    price: number;
    timestamp: number;
  };
  spread: number;
  volume: number;
  estimatedProfit: number;
  requiredCapital: number;
  riskScore: number;
  metadata: {
    [key: string]: any;
  };
}

/**
 * Trade result interface
 * 
 * Represents the result of an executed trade.
 */
export interface TradeResult {
  success: boolean;
  entry?: {
    price: number;
    timestamp: number;
    txHash?: string;
  };
  exit?: {
    price: number;
    timestamp: number;
    txHash?: string;
  };
  profit?: number;
  fees: number;
  error?: string;
  metadata: {
    [key: string]: any;
  };
}

/**
 * Risk assessment interface
 * 
 * Represents a risk assessment for a trade opportunity.
 */
export interface RiskAssessment {
  riskScore: number;
  maxLoss: number;
  liquidationPrice?: number;
  warnings: string[];
  limits: {
    position: boolean;
    leverage: boolean;
    concentration: boolean;
    liquidity: boolean;
  };
}

/**
 * Position size interface
 * 
 * Represents the calculated position size for a trade.
 */
export interface PositionSize {
  size: number;
  leverage: number;
  margin: number;
  notional: number;
  maxDrawdown: number;
}

/**
 * Trading bot interface
 * 
 * Defines the common interface for all trading bots.
 */
export interface TradingBot {
  id: string;
  name: string;
  type: 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular';
  status: 'running' | 'stopped' | 'error';
  minProfitThreshold: number;
  maxPositionSize: number;
  leverageLimit: number;
  exchanges: string[];
  pairs: string[];
  
  start(): Promise<void>;
  stop(): Promise<void>;
  getStatus(): string;
  
  findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]>;
  validateOpportunity(opportunity: TradeOpportunity): Promise<boolean>;
  checkRiskLimits(opportunity: TradeOpportunity): Promise<RiskAssessment>;
  calculatePosition(opportunity: TradeOpportunity): Promise<PositionSize>;
  executeTrade(opportunity: TradeOpportunity): Promise<TradeResult>;
}

/**
 * Bot configuration interface
 * 
 * Defines the configuration parameters for a trading bot.
 */
export interface BotConfig {
  id: string;
  name: string;
  type: 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular';
  minProfitThreshold: number;
  maxPositionSize: number;
  leverageLimit: number;
  exchanges: string[];
  pairs: string[];
  interval?: number;
  active?: boolean;
  status?: 'running' | 'stopped' | 'error';
  description?: string;
  client_id?: string;
  wallet_address?: string;
  subaccount_id?: string;
  max_gas_price?: number;
  max_slippage?: number;
}

/**
 * Basis opportunity interface
 * 
 * Represents a basis arbitrage opportunity.
 */
export interface BasisOpportunity {
  token: string;
  spotPrice: number;
  futuresPrice: number;
  basisSpread: number;
  annualizedReturn: number;
  daysToExpiry: number;
  requiredCapital: number;
  estimatedProfit: number;
  fundingRate: number;
  timestamp: number;
  source: string;
  target: string;
  category: 'dex' | 'cex' | 'hybrid';
  riskScore: number;
}

/**
 * Trade execution interface
 * 
 * Represents a trade execution record.
 */
export interface TradeExecution {
  opportunity: BasisOpportunity;
  result: {
    success: boolean;
    profit: number;
    commission: number;
    timestamp: number;
    error?: string;
  };
}

/**
 * Opportunity analysis interface
 * 
 * Represents an analysis of a trading opportunity.
 */
export interface OpportunityAnalysis {
  currentPosition: {
    annualizedReturn: number;
    holdingPeriod: number;
    costs: {
      execution: number;
      funding: number;
      total: number;
    };
  };
  newOpportunity: {
    estimatedReturn: number;
    estimatedCosts: {
      execution: number;
      funding: number;
      slippage: number;
      total: number;
    };
    riskAdjustedReturn: number;
  };
  improvement: {
    gross: number;
    net: number;
    percentageImprovement: number;
  };
  recommendation: {
    shouldRotate: boolean;
    reason: string;
    confidence: number;
  };
}

/**
 * Market conditions interface
 * 
 * Represents market conditions for risk assessment.
 */
export interface MarketConditions {
  volatility: number;
  volume: number;
  liquidity: number;
  spreadWidth: number;
  fundingRate: number;
  timestamp: number;
}