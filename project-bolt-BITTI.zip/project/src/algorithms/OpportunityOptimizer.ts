import { supabase } from '../lib/supabaseClient';
import { BasisOpportunity, TradeExecution } from './types';
import { CircuitBreaker } from '../services/CircuitBreaker';

interface Position {
  id: string;
  botId: string;
  clientId: string;
  exchange: string;
  pair: string;
  size: number;
  leverage: number;
  margin: number;
  entryPrice: number;
  currentPrice: number;
  entryTimestamp: Date;
  status: 'open' | 'closed' | 'liquidated';
  pnl: number;
}

interface OpportunityScore {
  opportunity: BasisOpportunity;
  annualizedReturn: number;
  netReturn: number;
  riskAdjustedReturn: number;
  executionCost: number;
  liquidityCost: number;
  totalCost: number;
}

interface RealTimeMetrics {
  currentPrice: number;
  fundingRate: number;
  volume24h: number;
  liquidity: number;
  volatility: number;
  lastUpdate: Date;
}

export class OpportunityOptimizer {
  private readonly MIN_IMPROVEMENT_THRESHOLD = 0.20; // 20% better return required
  private readonly EXECUTION_COST_FACTOR = 0.0015; // 0.15% execution cost
  private readonly SLIPPAGE_FACTOR = 0.001; // 0.1% slippage
  private readonly GAS_COST_USD = 50; // $50 gas cost for DEX trades
  private readonly FUNDING_RATE_WEIGHT = 0.3;
  private readonly BASIS_SPREAD_WEIGHT = 0.7;
  private readonly circuitBreaker: CircuitBreaker;

  constructor() {
    this.circuitBreaker = new CircuitBreaker(3, 60000, 0.8);
  }

  async evaluatePositionRotation(
    currentPosition: Position,
    newOpportunity: BasisOpportunity
  ): Promise<{
    shouldRotate: boolean;
    reason: string;
    expectedImprovement: number;
    costs: {
      exitCost: number;
      entryCost: number;
      netCost: number;
    };
  }> {
    try {
      // Get real-time market data for current position
      const currentMarketData = await this.getRealTimeMetrics(
        currentPosition.pair,
        currentPosition.exchange
      );

      // Get real-time market data for new opportunity
      const newMarketData = await this.getRealTimeMetrics(
        newOpportunity.token,
        newOpportunity.source
      );

      // Calculate current position metrics with real-time data
      const currentMetrics = await this.calculatePositionMetrics(
        currentPosition,
        currentMarketData
      );
      
      // Calculate new opportunity metrics with real-time data
      const opportunityMetrics = await this.calculateOpportunityMetrics(
        newOpportunity,
        newMarketData
      );

      // Calculate all costs involved in rotation
      const costs = this.calculateRotationCosts(
        currentPosition,
        newOpportunity,
        currentMarketData,
        newMarketData
      );

      // Calculate net improvement after costs
      const netImprovement = this.calculateNetImprovement(
        currentMetrics,
        opportunityMetrics,
        costs,
        currentMarketData,
        newMarketData
      );

      // Get market conditions
      const marketConditions = await this.getMarketConditions(
        currentPosition.pair,
        currentPosition.exchange,
        newOpportunity.token,
        newOpportunity.source
      );

      // Make decision
      const decision = this.makeRotationDecision(
        netImprovement,
        costs,
        marketConditions,
        currentMarketData,
        newMarketData
      );

      return {
        shouldRotate: decision.shouldRotate,
        reason: decision.reason,
        expectedImprovement: netImprovement,
        costs: {
          exitCost: costs.exitCost,
          entryCost: costs.entryCost,
          netCost: costs.totalCost
        }
      };
    } catch (error) {
      console.error('Error evaluating position rotation:', error);
      throw error;
    }
  }

  private async getRealTimeMetrics(pair: string, exchange: string): Promise<RealTimeMetrics> {
    // Get latest market data
    const { data: marketData } = await supabase
      .from('market_prices')
      .select('*')
      .eq('source', exchange)
      .eq('token', pair.split('/')[0])
      .order('timestamp', { ascending: false })
      .limit(1)
      .single();

    if (!marketData) {
      throw new Error(`No market data found for ${pair} on ${exchange}`);
    }

    // Get 24h volume
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const { data: volumeData } = await supabase
      .from('market_prices')
      .select('spot_price')
      .eq('source', exchange)
      .eq('token', pair.split('/')[0])
      .gte('timestamp', oneDayAgo.toISOString())
      .order('timestamp', { ascending: false });

    // Calculate volatility from price data
    const volatility = this.calculateVolatility(volumeData?.map(d => d.spot_price) || []);

    return {
      currentPrice: marketData.spot_price,
      fundingRate: marketData.funding_rate || 0,
      volume24h: volumeData?.length || 0,
      liquidity: marketData.liquidity || 0,
      volatility,
      lastUpdate: new Date(marketData.timestamp)
    };
  }

  private async calculatePositionMetrics(
    position: Position,
    realTimeData: RealTimeMetrics
  ) {
    // Calculate actual holding period
    const holdingPeriod = (Date.now() - position.entryTimestamp.getTime()) / (1000 * 60 * 60 * 24);

    // Calculate actual PnL using current market price
    const currentValue = position.size * realTimeData.currentPrice;
    const entryValue = position.size * position.entryPrice;
    const actualPnl = currentValue - entryValue;

    // Calculate actual return (including leverage)
    const actualReturn = (actualPnl / position.margin) * position.leverage;

    // Calculate annualized return based on actual holding period and PnL
    const annualizedReturn = (actualReturn / holdingPeriod) * 365;

    // Calculate actual funding payments
    const fundingPaid = position.size * realTimeData.fundingRate * holdingPeriod;
    const annualizedFundingReturn = (fundingPaid / position.margin) * (365 / holdingPeriod);

    // Calculate total actual return including funding
    const totalActualReturn = annualizedReturn + annualizedFundingReturn;

    return {
      actualPnl,
      annualizedReturn,
      annualizedFundingReturn,
      totalActualReturn,
      holdingPeriod,
      margin: position.margin,
      leverage: position.leverage,
      currentPrice: realTimeData.currentPrice,
      volume24h: realTimeData.volume24h,
      volatility: realTimeData.volatility
    };
  }

  private async calculateOpportunityMetrics(
    opportunity: BasisOpportunity,
    realTimeData: RealTimeMetrics
  ): Promise<OpportunityScore> {
    // Calculate execution costs with real-time data
    const executionCost = this.calculateExecutionCost(
      opportunity.requiredCapital,
      opportunity.category,
      realTimeData
    );

    // Calculate liquidity costs using real-time liquidity data
    const liquidityCost = this.calculateLiquidityCost(
      opportunity.requiredCapital,
      opportunity.category,
      realTimeData
    );

    // Calculate net return after all costs
    const totalCost = executionCost + liquidityCost;
    const netReturn = opportunity.estimatedProfit - totalCost;

    // Calculate annualized return using current market conditions
    const annualizedReturn = this.calculateAnnualizedReturn(
      netReturn,
      opportunity.requiredCapital,
      realTimeData
    );

    // Calculate risk-adjusted return using real-time volatility
    const riskAdjustedReturn = this.calculateRiskAdjustedReturn(
      annualizedReturn,
      opportunity.riskScore,
      realTimeData.volatility
    );

    return {
      opportunity,
      annualizedReturn,
      netReturn,
      riskAdjustedReturn,
      executionCost,
      liquidityCost,
      totalCost
    };
  }

  private calculateExecutionCost(
    capital: number,
    category: 'dex' | 'cex' | 'hybrid',
    realTimeData: RealTimeMetrics
  ): number {
    let cost = capital * this.EXECUTION_COST_FACTOR;

    // Adjust cost based on real-time volume and liquidity
    const volumeAdjustment = Math.min(1 + (capital / realTimeData.volume24h), 1.5);
    cost *= volumeAdjustment;

    // Add gas costs for DEX trades
    if (category === 'dex' || category === 'hybrid') {
      cost += this.GAS_COST_USD;
    }

    // Add extra costs for hybrid execution
    if (category === 'hybrid') {
      cost *= 1.2;
    }

    return cost;
  }

  private calculateLiquidityCost(
    capital: number,
    category: 'dex' | 'cex' | 'hybrid',
    realTimeData: RealTimeMetrics
  ): number {
    // Base slippage adjusted by real-time liquidity
    let slippage = this.SLIPPAGE_FACTOR * (1 + (capital / realTimeData.liquidity));

    // Adjust slippage based on venue and real-time conditions
    switch (category) {
      case 'dex':
        slippage *= 2 * (1 + realTimeData.volatility);
        break;
      case 'hybrid':
        slippage *= 1.5 * (1 + realTimeData.volatility);
        break;
      default:
        slippage *= (1 + realTimeData.volatility);
    }

    return capital * slippage;
  }

  private calculateAnnualizedReturn(
    netReturn: number,
    capital: number,
    realTimeData: RealTimeMetrics
  ): number {
    // Base annualized return
    let annualizedReturn = (netReturn / capital) * 365;

    // Adjust for market volatility
    const volatilityAdjustment = 1 - (realTimeData.volatility / 2);
    annualizedReturn *= volatilityAdjustment;

    return annualizedReturn;
  }

  private calculateRiskAdjustedReturn(
    annualizedReturn: number,
    baseRiskScore: number,
    realTimeVolatility: number
  ): number {
    // Combine base risk score with real-time volatility
    const adjustedRiskScore = (baseRiskScore + realTimeVolatility) / 2;
    return annualizedReturn * (1 - adjustedRiskScore);
  }

  private calculateRotationCosts(currentPosition: Position, newOpportunity: BasisOpportunity) {
    // Calculate exit costs for current position
    const exitCost = currentPosition.size * this.EXECUTION_COST_FACTOR;

    // Calculate entry costs for new opportunity
    const entryCost = this.calculateExecutionCost(
      newOpportunity.requiredCapital,
      newOpportunity.category
    );

    // Add slippage costs
    const exitSlippage = currentPosition.size * this.SLIPPAGE_FACTOR;
    const entrySlippage = newOpportunity.requiredCapital * this.SLIPPAGE_FACTOR;

    // Calculate total costs
    const totalCost = exitCost + entryCost + exitSlippage + entrySlippage;

    return {
      exitCost,
      entryCost,
      exitSlippage,
      entrySlippage,
      totalCost
    };
  }

  private calculateNetImprovement(
    currentMetrics: any,
    opportunityMetrics: OpportunityScore,
    costs: { totalCost: number }
  ): number {
    // Calculate net returns after costs
    const currentNetReturn = currentMetrics.totalReturn;
    const newNetReturn = opportunityMetrics.riskAdjustedReturn - (costs.totalCost / opportunityMetrics.opportunity.requiredCapital);

    // Calculate improvement percentage
    return ((newNetReturn - currentNetReturn) / Math.abs(currentNetReturn)) * 100;
  }

  private async getMarketConditions(
    currentPair: string,
    currentExchange: string,
    newPair: string,
    newExchange: string
  ) {
    // Get market volatility
    const { data: volatilityData } = await supabase
      .from('market_prices')
      .select('spot_price')
      .in('token', [currentPair.split('/')[0], newPair])
      .order('timestamp', { ascending: false })
      .limit(24);

    // Calculate volatility
    const volatility = this.calculateVolatility(volatilityData?.map(d => d.spot_price) || []);

    // Get trading volume
    const { data: volumeData } = await supabase
      .from('market_prices')
      .select('volume')
      .in('source', [currentExchange, newExchange])
      .order('timestamp', { ascending: false })
      .limit(24);

    // Calculate average volume
    const avgVolume = volumeData?.reduce((sum, vol) => sum + (vol.volume || 0), 0) || 0;

    return {
      volatility,
      avgVolume,
      marketHours: this.getMarketHours()
    };
  }

  private calculateVolatility(prices: number[]): number {
    if (prices.length < 2) return 0;
    
    const returns = prices.slice(1).map((price, i) => 
      Math.log(price / prices[i])
    );
    
    const mean = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
    const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - mean, 2), 0) / returns.length;
    
    return Math.sqrt(variance);
  }

  private getMarketHours(): 'normal' | 'high' | 'low' {
    const hour = new Date().getUTCHours();
    
    if (hour >= 12 && hour <= 20) return 'high'; // Peak trading hours
    if (hour >= 4 && hour <= 11) return 'normal'; // Normal trading hours
    return 'low'; // Off-peak hours
  }

  private makeRotationDecision(
    netImprovement: number,
    costs: { totalCost: number },
    marketConditions: { volatility: number; avgVolume: number; marketHours: string }
  ) {
    let shouldRotate = false;
    let reason = '';

    // Base case: Improvement must exceed minimum threshold
    if (netImprovement < this.MIN_IMPROVEMENT_THRESHOLD) {
      return {
        shouldRotate: false,
        reason: `Improvement (${netImprovement.toFixed(2)}%) below minimum threshold (${this.MIN_IMPROVEMENT_THRESHOLD}%)`
      };
    }

    // Check market conditions
    if (marketConditions.volatility > 0.1) { // High volatility
      if (netImprovement < this.MIN_IMPROVEMENT_THRESHOLD * 1.5) {
        return {
          shouldRotate: false,
          reason: 'Higher improvement needed during high volatility'
        };
      }
    }

    // Check trading hours
    if (marketConditions.marketHours === 'low') {
      if (netImprovement < this.MIN_IMPROVEMENT_THRESHOLD * 1.3) {
        return {
          shouldRotate: false,
          reason: 'Higher improvement needed during off-peak hours'
        };
      }
    }

    // If all checks pass, approve rotation
    return {
      shouldRotate: true,
      reason: `Expected improvement of ${netImprovement.toFixed(2)}% exceeds thresholds`
    };
  }
}