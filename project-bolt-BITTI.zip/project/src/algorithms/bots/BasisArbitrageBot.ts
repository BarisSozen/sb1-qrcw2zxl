import { AbstractBot } from '../AbstractBot';
import { MarketPrice, TradeOpportunity, TradeResult, RiskAssessment, PositionSize } from '../types';
import { supabase } from '../../lib/supabaseClient';
import { mean, standardDeviation } from 'simple-statistics';
import { TradeExecutor } from '../../services/TradeExecutor';
import { AccountAbstraction } from '../../services/AccountAbstraction';

interface AccountBalance {
  exchange: string;
  token: string;
  spotBalance: number;
  futuresBalance: number;
  timestamp: number;
}

interface PositionBalance {
  id: string;
  spotExchange: string;
  futuresExchange: string;
  token: string;
  initialSpotBalance: number;
  initialFuturesBalance: number;
  spotEntryPrice: number;
  futuresEntryPrice: number;
  size: number;
  timestamp: number;
}

export class BasisArbitrageBot extends AbstractBot {
  private accountBalances: Map<string, AccountBalance> = new Map();
  private openPositions: Map<string, PositionBalance> = new Map();
  private readonly MIN_LIQUIDITY_RATIO = 0.1;
  private readonly MAX_SLIPPAGE = 0.002;
  private readonly MIN_PROFIT_AFTER_COSTS = 0.001;
  private readonly FUNDING_RATE_WEIGHT = 0.3;
  private readonly BASIS_SPREAD_WEIGHT = 0.7;
  private tradeExecutor: TradeExecutor;

  constructor(config: BotConfig) {
    super(config);
    this.tradeExecutor = new TradeExecutor(
      process.env.ETH_RPC_URL || 'http://localhost:8545',
      process.env.BUNDLER_URL || 'http://localhost:3000'
    );
  }

  async findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]> {
    const opportunities: TradeOpportunity[] = [];
    const tokens = new Set(prices.map(p => p.token));

    for (const token of tokens) {
      const tokenPrices = prices.filter(p => p.token === token);
      
      // Group prices by category
      const dexPrices = tokenPrices.filter(p => p.category === 'dex');
      const cexPrices = tokenPrices.filter(p => p.category === 'cex');
      
      // Find best prices across all venues
      const bestSpotPrice = {
        dex: Math.min(...dexPrices.map(p => p.spotPrice), Infinity),
        cex: Math.min(...cexPrices.map(p => p.spotPrice), Infinity)
      };

      const bestFuturesPrice = {
        dex: Math.max(...dexPrices.map(p => p.futuresPrice), -Infinity),
        cex: Math.max(...cexPrices.map(p => p.futuresPrice), -Infinity)
      };

      // Check DEX-CEX opportunities
      const opportunities1 = this.findCrossVenueOpportunities(
        token,
        dexPrices,
        cexPrices,
        bestSpotPrice,
        bestFuturesPrice
      );

      // Check CEX-CEX opportunities
      const opportunities2 = this.findCexOpportunities(
        token,
        cexPrices,
        bestSpotPrice.cex,
        bestFuturesPrice.cex
      );

      // Check DEX-DEX opportunities
      const opportunities3 = this.findDexOpportunities(
        token,
        dexPrices,
        bestSpotPrice.dex,
        bestFuturesPrice.dex
      );

      opportunities.push(...opportunities1, ...opportunities2, ...opportunities3);
    }

    return opportunities.sort((a, b) => b.estimatedProfit - a.estimatedProfit);
  }

  private findCrossVenueOpportunities(
    token: string,
    dexPrices: MarketPrice[],
    cexPrices: MarketPrice[],
    bestSpotPrice: { dex: number; cex: number },
    bestFuturesPrice: { dex: number; cex: number }
  ): TradeOpportunity[] {
    const opportunities: TradeOpportunity[] = [];

    // DEX spot to CEX futures
    if (bestSpotPrice.dex < Infinity && bestFuturesPrice.cex > -Infinity) {
      const dexSpot = dexPrices.find(p => p.spotPrice === bestSpotPrice.dex);
      const cexFutures = cexPrices.find(p => p.futuresPrice === bestFuturesPrice.cex);

      if (dexSpot && cexFutures) {
        const opportunity = this.createOpportunity(
          token,
          dexSpot,
          cexFutures,
          'dex-cex'
        );
        if (opportunity) opportunities.push(opportunity);
      }
    }

    // CEX spot to DEX futures
    if (bestSpotPrice.cex < Infinity && bestFuturesPrice.dex > -Infinity) {
      const cexSpot = cexPrices.find(p => p.spotPrice === bestSpotPrice.cex);
      const dexFutures = dexPrices.find(p => p.futuresPrice === bestFuturesPrice.dex);

      if (cexSpot && dexFutures) {
        const opportunity = this.createOpportunity(
          token,
          cexSpot,
          dexFutures,
          'cex-dex'
        );
        if (opportunity) opportunities.push(opportunity);
      }
    }

    return opportunities;
  }

  private findCexOpportunities(
    token: string,
    prices: MarketPrice[],
    bestSpotPrice: number,
    bestFuturesPrice: number
  ): TradeOpportunity[] {
    const opportunities: TradeOpportunity[] = [];

    const spotExchange = prices.find(p => p.spotPrice === bestSpotPrice);
    const futuresExchange = prices.find(p => p.futuresPrice === bestFuturesPrice);

    if (spotExchange && futuresExchange && spotExchange.source !== futuresExchange.source) {
      const opportunity = this.createOpportunity(
        token,
        spotExchange,
        futuresExchange,
        'cex-cex'
      );
      if (opportunity) opportunities.push(opportunity);
    }

    return opportunities;
  }

  private findDexOpportunities(
    token: string,
    prices: MarketPrice[],
    bestSpotPrice: number,
    bestFuturesPrice: number
  ): TradeOpportunity[] {
    const opportunities: TradeOpportunity[] = [];

    const spotExchange = prices.find(p => p.spotPrice === bestSpotPrice);
    const futuresExchange = prices.find(p => p.futuresPrice === bestFuturesPrice);

    if (spotExchange && futuresExchange && spotExchange.source !== futuresExchange.source) {
      const opportunity = this.createOpportunity(
        token,
        spotExchange,
        futuresExchange,
        'dex-dex'
      );
      if (opportunity) opportunities.push(opportunity);
    }

    return opportunities;
  }

  private createOpportunity(
    token: string,
    spotMarket: MarketPrice,
    futuresMarket: MarketPrice,
    type: 'dex-cex' | 'cex-dex' | 'cex-cex' | 'dex-dex'
  ): TradeOpportunity | null {
    const basisSpread = ((futuresMarket.futuresPrice - spotMarket.spotPrice) / spotMarket.spotPrice) * 100;
    const daysToExpiry = (futuresMarket.futuresExpiry - Date.now()) / (1000 * 60 * 60 * 24);
    const annualizedReturn = (basisSpread / daysToExpiry) * 365;
    const fundingReturn = futuresMarket.fundingRate * 365 * 100;
    const totalReturn = annualizedReturn + fundingReturn;

    if (totalReturn <= this.minProfitThreshold) return null;

    const volume = Math.min(
      this.maxPositionSize,
      this.maxPositionSize * (totalReturn / (this.minProfitThreshold * 2))
    );

    return {
      id: crypto.randomUUID(),
      type: 'basis',
      token,
      entry: {
        exchange: spotMarket.source,
        price: spotMarket.spotPrice,
        timestamp: Date.now()
      },
      exit: {
        exchange: futuresMarket.source,
        price: futuresMarket.futuresPrice,
        timestamp: Date.now()
      },
      spread: basisSpread,
      volume,
      estimatedProfit: (volume * basisSpread) / 100,
      requiredCapital: volume,
      riskScore: this.calculateRiskScore(basisSpread, daysToExpiry, type, spotMarket.source, futuresMarket.source),
      metadata: {
        type,
        fundingRate: fundingReturn,
        daysToExpiry,
        annualizedReturn: totalReturn,
        spotCategory: spotMarket.category,
        futuresCategory: futuresMarket.category
      }
    };
  }

  protected async executeTradeInternal(opportunity: TradeOpportunity): Promise<TradeResult> {
    const { type, spotCategory, futuresCategory } = opportunity.metadata;

    try {
      let spotResult, futuresResult;

      // Execute spot trade
      if (spotCategory === 'dex') {
        spotResult = await this.executeDexTrade(opportunity, 'spot');
      } else {
        spotResult = await this.executeCexTrade(opportunity, 'spot');
      }

      // Execute futures trade
      if (futuresCategory === 'dex') {
        futuresResult = await this.executeDexTrade(opportunity, 'futures');
      } else {
        futuresResult = await this.executeCexTrade(opportunity, 'futures');
      }

      const profit = 
        (futuresResult.price - spotResult.price) * opportunity.volume -
        (spotResult.fees + futuresResult.fees);

      return {
        success: true,
        entry: {
          price: spotResult.price,
          timestamp: Date.now(),
          txHash: spotResult.txHash
        },
        exit: {
          price: futuresResult.price,
          timestamp: Date.now(),
          txHash: futuresResult.txHash
        },
        profit,
        fees: spotResult.fees + futuresResult.fees,
        metadata: {
          spotOrderId: spotResult.orderId,
          futuresOrderId: futuresResult.orderId,
          type,
          spotExchange: opportunity.entry.exchange,
          futuresExchange: opportunity.exit.exchange
        }
      };
    } catch (error) {
      return {
        success: false,
        fees: 0,
        error: error instanceof Error ? error.message : 'Trade execution failed',
        metadata: {}
      };
    }
  }

  private async executeDexTrade(
    opportunity: TradeOpportunity,
    side: 'spot' | 'futures'
  ) {
    const params = {
      token: opportunity.token,
      amount: opportunity.volume.toString(),
      price: (side === 'spot' ? opportunity.entry.price : opportunity.exit.price).toString(),
      side: side === 'spot' ? 'buy' : 'sell',
      exchange: side === 'spot' ? opportunity.entry.exchange : opportunity.exit.exchange,
      userAddress: this.config.wallet_address || ''
    };

    const txHash = await this.tradeExecutor.executeTrade(params);
    
    return {
      orderId: crypto.randomUUID(),
      txHash,
      price: side === 'spot' ? opportunity.entry.price : opportunity.exit.price,
      fees: opportunity.volume * (side === 'spot' ? opportunity.entry.price : opportunity.exit.price) * 0.003 // 0.3% DEX fee
    };
  }

  private async executeCexTrade(
    opportunity: TradeOpportunity,
    side: 'spot' | 'futures'
  ) {
    // Mock implementation - replace with actual exchange API calls
    return {
      orderId: crypto.randomUUID(),
      txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`,
      price: side === 'spot' ? opportunity.entry.price : opportunity.exit.price,
      fees: opportunity.volume * (side === 'spot' ? opportunity.entry.price : opportunity.exit.price) * 0.001 // 0.1% CEX fee
    };
  }

  private calculateRiskScore(
    basisSpread: number,
    daysToExpiry: number,
    type: string,
    spotExchange: string,
    futuresExchange: string
  ): number {
    let riskScore = 0;
    
    // Spread risk (higher spread = higher risk)
    riskScore += Math.min(basisSpread / 20, 0.3);
    
    // Time risk (longer duration = higher risk)
    riskScore += Math.min(daysToExpiry / 90, 0.3);
    
    // Cross-venue risk
    if (type === 'dex-cex' || type === 'cex-dex') {
      riskScore += 0.2; // Additional risk for cross-venue trades
    }
    
    // Exchange risk
    const exchangeRisk = {
      binance: 0.1,
      bybit: 0.15,
      okx: 0.15,
      deribit: 0.2,
      uniswap: 0.25,
      sushiswap: 0.3
    };
    
    riskScore += (
      exchangeRisk[spotExchange as keyof typeof exchangeRisk] || 0.3
    );
    
    riskScore += (
      exchangeRisk[futuresExchange as keyof typeof exchangeRisk] || 0.3
    );
    
    return Math.min(riskScore, 0.95);
  }

  [Rest of the implementation remains unchanged...]
}