import { ExchangeService } from '../../services/exchanges/ExchangeService';
import { SecurityService } from '../../services/security';
import { MarketPrice, TradeOpportunity, TradeResult, RiskAssessment, PositionSize } from '../types';
import { AbstractBot } from '../AbstractBot';
import type { BotConfig } from '../../types/bots';
import { mean, standardDeviation, variance } from 'simple-statistics';

interface PairStats {
  mean: number;
  stdDev: number;
  zScore: number;
  correlation: number;
  spreadVolatility: number;
  historicalSpread: number[];
}

export class StatisticalArbitrageBot extends AbstractBot {
  private readonly LOOKBACK_PERIODS = 100;
  private readonly Z_SCORE_THRESHOLD = 2;
  private readonly MIN_CORRELATION = 0.7;
  private readonly MAX_POSITION_CORRELATION = 0.3;
  private readonly MIN_SPREAD_VOLATILITY = 0.001;
  private readonly CONFIDENCE_INTERVAL = 0.95;
  private readonly MIN_SAMPLES = 30;

  constructor(config: BotConfig) {
    super(config);
  }

  async findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]> {
    try {
      const opportunities: TradeOpportunity[] = [];
      const pairs = this.getPairCombinations(prices);

      for (const [pair1, pair2] of pairs) {
        // Calculate statistical metrics
        const stats = await this.calculatePairStats(pair1, pair2);
        
        if (!this.isValidOpportunity(stats)) continue;

        // Calculate optimal position size
        const positionSize = this.calculateOptimalSize(stats, pair1.spotPrice, pair2.spotPrice);

        // Calculate expected profit
        const expectedProfit = this.calculateExpectedProfit(stats, positionSize);

        // Only include if meets minimum threshold
        if (expectedProfit.annualizedReturn > this.minProfitThreshold) {
          const opportunity: TradeOpportunity = {
            id: crypto.randomUUID(),
            type: 'statistical',
            token: pair1.token,
            entry: {
              exchange: pair1.source,
              price: pair1.spotPrice,
              timestamp: Date.now()
            },
            exit: {
              exchange: pair2.source,
              price: pair2.spotPrice,
              timestamp: Date.now()
            },
            spread: stats.zScore,
            volume: positionSize,
            estimatedProfit: expectedProfit.expectedValue,
            requiredCapital: positionSize * pair1.spotPrice,
            riskScore: this.calculateRiskScore(stats),
            metadata: {
              correlation: stats.correlation,
              spreadVolatility: stats.spreadVolatility,
              confidenceInterval: this.CONFIDENCE_INTERVAL,
              zScore: stats.zScore,
              meanReversion: stats.mean,
              expectedReturn: expectedProfit.annualizedReturn
            }
          };

          opportunities.push(opportunity);
        }
      }

      return this.rankOpportunities(opportunities);
    } catch (error) {
      console.error('Error finding statistical arbitrage opportunities:', error);
      return [];
    }
  }

  async validateOpportunity(opportunity: TradeOpportunity): Promise<boolean> {
    try {
      // Get latest prices
      const { data: latestPrices } = await supabase
        .from('market_prices')
        .select('*')
        .in('source', [opportunity.entry.exchange, opportunity.exit.exchange])
        .eq('token', opportunity.token)
        .order('timestamp', { ascending: false })
        .limit(2);

      if (!latestPrices || latestPrices.length < 2) return false;

      // Recalculate stats with latest data
      const stats = await this.calculatePairStats(
        latestPrices[0],
        latestPrices[1]
      );

      // Validate statistical significance
      if (!this.isValidOpportunity(stats)) return false;

      // Check if spread has converged
      if (Math.abs(stats.zScore) < this.Z_SCORE_THRESHOLD) return false;

      // Validate liquidity
      const hasLiquidity = await this.checkLiquidity(
        opportunity.token,
        opportunity.volume,
        [opportunity.entry.exchange, opportunity.exit.exchange]
      );

      return hasLiquidity;
    } catch (error) {
      console.error('Error validating statistical arbitrage opportunity:', error);
      return false;
    }
  }

  async checkRiskLimits(opportunity: TradeOpportunity): Promise<RiskAssessment> {
    try {
      // Get current positions
      const { data: positions } = await supabase
        .from('bot_positions')
        .select('*')
        .eq('bot_id', this.id)
        .eq('status', 'open');

      // Calculate position correlation
      const positionCorrelation = positions && positions.length > 0
        ? await this.calculatePositionCorrelation(positions, opportunity)
        : 0;

      // Calculate Value at Risk
      const VaR = this.calculateValueAtRisk(opportunity);

      // Check risk limits
      const warnings: string[] = [];
      
      if (positionCorrelation > this.MAX_POSITION_CORRELATION) {
        warnings.push(`Position correlation (${positionCorrelation.toFixed(2)}) exceeds maximum (${this.MAX_POSITION_CORRELATION})`);
      }

      if (VaR > opportunity.requiredCapital * 0.1) {
        warnings.push(`Value at Risk (${VaR.toFixed(2)}) exceeds 10% of position size`);
      }

      return {
        riskScore: opportunity.riskScore,
        maxLoss: VaR,
        warnings,
        limits: {
          position: opportunity.volume <= this.maxPositionSize,
          leverage: true,
          concentration: positionCorrelation <= this.MAX_POSITION_CORRELATION,
          liquidity: true
        }
      };
    } catch (error) {
      console.error('Error checking risk limits:', error);
      throw error;
    }
  }

  async calculatePosition(opportunity: TradeOpportunity): Promise<PositionSize> {
    try {
      // Get historical volatility
      const volatility = await this.calculateHistoricalVolatility(
        opportunity.token,
        opportunity.entry.exchange
      );

      // Calculate optimal position size based on Kelly Criterion
      const kellyFraction = this.calculateKellyFraction(
        opportunity.metadata.expectedReturn,
        volatility
      );

      // Apply position sizing constraints
      const maxSize = Math.min(
        this.maxPositionSize,
        opportunity.requiredCapital * kellyFraction
      );

      return {
        size: maxSize,
        leverage: 1, // No leverage for statistical arbitrage
        margin: maxSize,
        notional: maxSize,
        maxDrawdown: maxSize * volatility * 2 // 2 standard deviations
      };
    } catch (error) {
      console.error('Error calculating position size:', error);
      throw error;
    }
  }

  private async calculatePairStats(pair1: MarketPrice, pair2: MarketPrice): Promise<PairStats> {
    // Get historical prices
    const { data: historicalPrices } = await supabase
      .from('market_prices')
      .select('*')
      .in('source', [pair1.source, pair2.source])
      .eq('token', pair1.token)
      .order('timestamp', { ascending: false })
      .limit(this.LOOKBACK_PERIODS);

    if (!historicalPrices || historicalPrices.length < this.MIN_SAMPLES) {
      throw new Error('Insufficient historical data');
    }

    // Calculate price spreads
    const spreads = historicalPrices.map(p => 
      Math.log(p.spotPrice / p.futuresPrice)
    );

    // Calculate statistical measures
    const spreadMean = mean(spreads);
    const spreadStdDev = standardDeviation(spreads);
    const currentSpread = Math.log(pair1.spotPrice / pair2.spotPrice);
    const zScore = (currentSpread - spreadMean) / spreadStdDev;

    // Calculate correlation
    const correlation = this.calculateCorrelation(
      historicalPrices.filter(p => p.source === pair1.source).map(p => p.spotPrice),
      historicalPrices.filter(p => p.source === pair2.source).map(p => p.spotPrice)
    );

    return {
      mean: spreadMean,
      stdDev: spreadStdDev,
      zScore,
      correlation,
      spreadVolatility: spreadStdDev / spreadMean,
      historicalSpread: spreads
    };
  }

  private calculateCorrelation(series1: number[], series2: number[]): number {
    if (series1.length !== series2.length || series1.length < 2) return 0;
    
    const mean1 = mean(series1);
    const mean2 = mean(series2);
    const std1 = standardDeviation(series1);
    const std2 = standardDeviation(series2);
    
    const covariance = series1.reduce((sum, x, i) => 
      sum + ((x - mean1) * (series2[i] - mean2)), 0
    ) / (series1.length - 1);
    
    return covariance / (std1 * std2);
  }

  private calculateOptimalSize(
    stats: PairStats,
    price1: number,
    price2: number
  ): number {
    // Kelly Criterion for position sizing
    const winProbability = this.calculateWinProbability(stats);
    const payoffRatio = Math.abs(stats.zScore) * stats.stdDev;
    
    const kellyFraction = (winProbability * payoffRatio - (1 - winProbability)) / payoffRatio;
    
    // Apply conservative fraction and limits
    const conservativeFraction = kellyFraction * 0.5; // Half-Kelly for safety
    const optimalSize = this.maxPositionSize * conservativeFraction;
    
    return Math.min(optimalSize, this.maxPositionSize);
  }

  private calculateExpectedProfit(
    stats: PairStats,
    positionSize: number
  ): { expectedValue: number; annualizedReturn: number } {
    const meanReversionRate = 1 - Math.exp(-stats.correlation);
    const expectedSpreadChange = stats.mean - (stats.zScore * stats.stdDev);
    const expectedValue = positionSize * expectedSpreadChange * meanReversionRate;
    
    // Annualize the return
    const annualTurnover = 252 / meanReversionRate; // Assuming 252 trading days
    const annualizedReturn = expectedValue * annualTurnover / positionSize * 100;
    
    return { expectedValue, annualizedReturn };
  }

  private calculateWinProbability(stats: PairStats): number {
    // Using normal distribution properties
    const zScore = Math.abs(stats.zScore);
    return 1 - (0.5 * (1 + Math.erf(zScore / Math.sqrt(2))));
  }

  private calculateValueAtRisk(opportunity: TradeOpportunity): number {
    const confidence = 0.95; // 95% confidence interval
    const zScore = 1.645; // Z-score for 95% confidence
    const volatility = opportunity.metadata.spreadVolatility;
    
    return opportunity.requiredCapital * volatility * zScore;
  }

  private calculateRiskScore(stats: PairStats): number {
    let riskScore = 0;
    
    // Correlation risk (lower correlation = higher risk)
    riskScore += (1 - Math.abs(stats.correlation)) * 0.3;
    
    // Volatility risk
    riskScore += Math.min(stats.spreadVolatility, 1) * 0.3;
    
    // Z-score risk (extreme values = higher risk)
    const zScoreRisk = Math.min(Math.abs(stats.zScore) / 4, 1);
    riskScore += zScoreRisk * 0.2;
    
    // Mean reversion risk
    const meanReversionStrength = Math.exp(-Math.abs(stats.correlation));
    riskScore += meanReversionStrength * 0.2;
    
    return Math.min(riskScore, 0.95);
  }

  private isValidOpportunity(stats: PairStats): boolean {
    return (
      Math.abs(stats.zScore) > this.Z_SCORE_THRESHOLD &&
      Math.abs(stats.correlation) > this.MIN_CORRELATION &&
      stats.spreadVolatility > this.MIN_SPREAD_VOLATILITY
    );
  }

  private getPairCombinations(prices: MarketPrice[]): [MarketPrice, MarketPrice][] {
    const pairs: [MarketPrice, MarketPrice][] = [];
    
    for (let i = 0; i < prices.length; i++) {
      for (let j = i + 1; j < prices.length; j++) {
        if (
          prices[i].token === prices[j].token &&
          prices[i].source !== prices[j].source
        ) {
          pairs.push([prices[i], prices[j]]);
        }
      }
    }
    
    return pairs;
  }

  private rankOpportunities(opportunities: TradeOpportunity[]): TradeOpportunity[] {
    return opportunities.sort((a, b) => {
      // Calculate risk-adjusted return
      const aReturn = a.metadata.expectedReturn * (1 - a.riskScore);
      const bReturn = b.metadata.expectedReturn * (1 - b.riskScore);
      
      return bReturn - aReturn;
    });
  }

  private async checkLiquidity(
    token: string,
    volume: number,
    exchanges: string[]
  ): Promise<boolean> {
    try {
      const { data: volumeData } = await supabase
        .from('market_prices')
        .select('volume')
        .in('source', exchanges)
        .eq('token', token)
        .order('timestamp', { ascending: false })
        .limit(24);

      if (!volumeData) return false;

      const avgVolume = mean(volumeData.map(d => d.volume || 0));
      return volume <= avgVolume * 0.1; // Position size <= 10% of average volume
    } catch (error) {
      console.error('Error checking liquidity:', error);
      return false;
    }
  }

  private async calculateHistoricalVolatility(
    token: string,
    exchange: string
  ): Promise<number> {
    try {
      const { data: prices } = await supabase
        .from('market_prices')
        .select('spot_price')
        .eq('source', exchange)
        .eq('token', token)
        .order('timestamp', { ascending: false })
        .limit(30);

      if (!prices || prices.length < 2) return 0;

      const returns = prices.slice(1).map((price, i) => 
        Math.log(price.spot_price / prices[i].spot_price)
      );

      return standardDeviation(returns) * Math.sqrt(252); // Annualized volatility
    } catch (error) {
      console.error('Error calculating historical volatility:', error);
      return 0;
    }
  }

  private calculateKellyFraction(
    expectedReturn: number,
    volatility: number
  ): number {
    const winRate = 0.5 + (expectedReturn / (2 * volatility));
    const payoffRatio = (1 + expectedReturn) / (1 - expectedReturn);
    
    const kellyFraction = (winRate * payoffRatio - (1 - winRate)) / payoffRatio;
    return Math.max(0, Math.min(kellyFraction * 0.5, 1)); // Half-Kelly for safety
  }

  private async calculatePositionCorrelation(
    positions: any[],
    newOpportunity: TradeOpportunity
  ): Promise<number> {
    try {
      const returns: number[][] = [];

      // Get historical returns for existing positions
      for (const position of positions) {
        const { data: prices } = await supabase
          .from('market_prices')
          .select('spot_price')
          .eq('source', position.exchange)
          .eq('token', position.pair.split('/')[0])
          .order('timestamp', { ascending: false })
          .limit(30);

        if (prices && prices.length > 1) {
          const posReturns = prices.slice(1).map((price, i) => 
            Math.log(price.spot_price / prices[i].spot_price)
          );
          returns.push(posReturns);
        }
      }

      // Get historical returns for new opportunity
      const { data: newPrices } = await supabase
        .from('market_prices')
        .select('spot_price')
        .eq('source', newOpportunity.entry.exchange)
        .eq('token', newOpportunity.token)
        .order('timestamp', { ascending: false })
        .limit(30);

      if (newPrices && newPrices.length > 1) {
        const newReturns = newPrices.slice(1).map((price, i) => 
          Math.log(price.spot_price / newPrices[i].spot_price)
        );
        returns.push(newReturns);
      }

      // Calculate average correlation
      let totalCorr = 0;
      let count = 0;

      for (let i = 0; i < returns.length; i++) {
        for (let j = i + 1; j < returns.length; j++) {
          totalCorr += Math.abs(this.calculateCorrelation(returns[i], returns[j]));
          count++;
        }
      }

      return count > 0 ? totalCorr / count : 0;
    } catch (error) {
      console.error('Error calculating position correlation:', error);
      return 0;
    }
  }

  protected async executeTradeInternal(opportunity: TradeOpportunity): Promise<TradeResult> {
    try {
      // Execute entry trade
      const entryResult = await this.executeOrder(
        opportunity.token,
        opportunity.entry.exchange,
        opportunity.volume,
        opportunity.entry.price,
        'buy'
      );

      // Execute exit trade
      const exitResult = await this.executeOrder(
        opportunity.token,
        opportunity.exit.exchange,
        opportunity.volume,
        opportunity.exit.price,
        'sell'
      );

      const profit = (exitResult.price - entryResult.price) * opportunity.volume;
      const fees = entryResult.fees + exitResult.fees;

      return {
        success: true,
        entry: {
          price: entryResult.price,
          timestamp: Date.now(),
          txHash: entryResult.txHash
        },
        exit: {
          price: exitResult.price,
          timestamp: Date.now(),
          txHash: exitResult.txHash
        },
        profit: profit - fees,
        fees,
        metadata: {
          entryOrderId: entryResult.orderId,
          exitOrderId: exitResult.orderId,
          strategy: 'statistical_arbitrage',
          zScore: opportunity.metadata.zScore,
          correlation: opportunity.metadata.correlation,
          confidenceInterval: opportunity.metadata.confidenceInterval
        }
      };
    } catch (error) {
      console.error('Error executing statistical arbitrage trade:', error);
      return {
        success: false,
        fees: 0,
        error: error instanceof Error ? error.message : 'Trade execution failed',
        metadata: {}
      };
    }
  }

  private async executeOrder(
    token: string,
    exchange: string,
    volume: number,
    price: number,
    side: 'buy' | 'sell'
  ): Promise<{
    orderId: string;
    txHash: string;
    price: number;
    fees: number;
  }> {
    // Mock implementation - replace with actual exchange API calls
    return {
      orderId: crypto.randomUUID(),
      txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`,
      price,
      fees: volume * price * 0.001 // 0.1% fee
    };
  }
}