import { AbstractBot } from '../AbstractBot';
import { MarketPrice, TradeOpportunity, TradeResult, RiskAssessment, PositionSize } from '../types';

export class PerpetualArbitrageBot extends AbstractBot {
  async findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]> {
    const opportunities: TradeOpportunity[] = [];
    const tokens = new Set(prices.map(p => p.token));

    for (const token of tokens) {
      const tokenPrices = prices.filter(p => p.token === token);
      
      // Find funding rate arbitrage opportunities
      for (let i = 0; i < tokenPrices.length; i++) {
        for (let j = i + 1; j < tokenPrices.length; j++) {
          const longExchange = tokenPrices[i];
          const shortExchange = tokenPrices[j];
          
          // Calculate funding rate differential
          const fundingDiff = (longExchange.fundingRate || 0) - (shortExchange.fundingRate || 0);
          const annualizedReturn = fundingDiff * 365 * 100; // Convert to annual percentage
          
          // Check if meets minimum threshold
          if (Math.abs(annualizedReturn) > this.minProfitThreshold) {
            const volume = Math.min(
              this.maxPositionSize,
              this.maxPositionSize * (Math.abs(annualizedReturn) / (this.minProfitThreshold * 2))
            );

            // Determine which exchange to long/short based on funding rates
            const [entryExchange, exitExchange] = fundingDiff > 0 
              ? [shortExchange, longExchange]  // Long where funding is negative
              : [longExchange, shortExchange]; // Long where funding is positive

            opportunities.push({
              id: crypto.randomUUID(),
              type: 'perpetual',
              token,
              entry: {
                exchange: entryExchange.source,
                price: entryExchange.futuresPrice,
                timestamp: Date.now()
              },
              exit: {
                exchange: exitExchange.source,
                price: exitExchange.futuresPrice,
                timestamp: Date.now()
              },
              spread: Math.abs(fundingDiff * 100), // Convert to percentage
              volume,
              estimatedProfit: (volume * Math.abs(fundingDiff)) / 100,
              requiredCapital: volume,
              riskScore: this.calculateRiskScore(fundingDiff, entryExchange.source, exitExchange.source),
              metadata: {
                longExchangeFunding: longExchange.fundingRate,
                shortExchangeFunding: shortExchange.fundingRate,
                annualizedReturn,
                isLongFirst: fundingDiff > 0
              }
            });
          }
        }
      }
    }

    return opportunities.sort((a, b) => b.estimatedProfit - a.estimatedProfit);
  }

  async validateOpportunity(opportunity: TradeOpportunity): Promise<boolean> {
    // Validate funding rate opportunity
    const metadata = opportunity.metadata;
    
    // Check if funding rates are still valid
    const currentPrices = await this.getMarketPrices();
    const longExchange = currentPrices.find(p => 
      p.token === opportunity.token && 
      p.source === (metadata.isLongFirst ? opportunity.exit.exchange : opportunity.entry.exchange)
    );
    
    const shortExchange = currentPrices.find(p => 
      p.token === opportunity.token && 
      p.source === (metadata.isLongFirst ? opportunity.entry.exchange : opportunity.exit.exchange)
    );

    if (!longExchange || !shortExchange) return false;

    // Calculate current funding rate differential
    const currentFundingDiff = (longExchange.fundingRate || 0) - (shortExchange.fundingRate || 0);
    const currentAnnualizedReturn = currentFundingDiff * 365 * 100;

    // Validate the opportunity is still profitable
    return Math.abs(currentAnnualizedReturn) > this.minProfitThreshold;
  }

  async executeTrade(opportunity: TradeOpportunity): Promise<TradeResult> {
    // Implement trade execution logic
    const metadata = opportunity.metadata;
    const isLongFirst = metadata.isLongFirst;

    try {
      // Execute trades on both exchanges
      const entryResult = await this.executePosition(
        opportunity.token,
        opportunity.entry.exchange,
        opportunity.volume,
        isLongFirst ? 'short' : 'long'
      );

      const exitResult = await this.executePosition(
        opportunity.token,
        opportunity.exit.exchange,
        opportunity.volume,
        isLongFirst ? 'long' : 'short'
      );

      return {
        success: true,
        entry: {
          price: opportunity.entry.price,
          timestamp: Date.now(),
          txHash: entryResult.txHash
        },
        exit: {
          price: opportunity.exit.price,
          timestamp: Date.now(),
          txHash: exitResult.txHash
        },
        fees: entryResult.fees + exitResult.fees,
        metadata: {
          entryOrderId: entryResult.orderId,
          exitOrderId: exitResult.orderId,
          longExchange: isLongFirst ? opportunity.exit.exchange : opportunity.entry.exchange,
          shortExchange: isLongFirst ? opportunity.entry.exchange : opportunity.exit.exchange
        }
      };
    } catch (error) {
      return {
        success: false,
        fees: 0,
        error: error instanceof Error ? error.message : 'Trade execution failed',
        metadata: {}
      };
    }
  }

  async checkRiskLimits(opportunity: TradeOpportunity): Promise<RiskAssessment> {
    const metadata = opportunity.metadata;
    
    // Calculate maximum potential loss
    const maxLoss = opportunity.requiredCapital * (1 / this.leverageLimit);
    
    // Check exchange limits
    const exchangeLimits = await this.checkExchangeLimits(
      opportunity.token,
      [opportunity.entry.exchange, opportunity.exit.exchange],
      opportunity.volume
    );

    // Calculate liquidation prices
    const longLiqPrice = opportunity.entry.price * (1 - 1 / this.leverageLimit);
    const shortLiqPrice = opportunity.exit.price * (1 + 1 / this.leverageLimit);

    return {
      riskScore: opportunity.riskScore,
      maxLoss,
      liquidationPrice: metadata.isLongFirst ? longLiqPrice : shortLiqPrice,
      warnings: exchangeLimits.warnings,
      limits: {
        position: opportunity.volume <= this.maxPositionSize,
        leverage: true, // Perpetual contracts always use leverage
        concentration: exchangeLimits.withinConcentrationLimits,
        liquidity: exchangeLimits.hasLiquidity
      }
    };
  }

  async calculatePosition(opportunity: TradeOpportunity): Promise<PositionSize> {
    // Calculate optimal position size based on funding rate differential
    const annualizedReturn = opportunity.metadata.annualizedReturn;
    const targetLeverage = Math.min(
      this.leverageLimit,
      Math.max(1, Math.abs(annualizedReturn) / 10) // Scale leverage with return
    );

    const notionalSize = opportunity.volume * targetLeverage;
    const requiredMargin = notionalSize / targetLeverage;

    return {
      size: opportunity.volume,
      leverage: targetLeverage,
      margin: requiredMargin,
      notional: notionalSize,
      maxDrawdown: requiredMargin * 0.8 // 80% of margin as max drawdown
    };
  }

  private calculateRiskScore(
    fundingDiff: number,
    exchange1: string,
    exchange2: string
  ): number {
    let riskScore = 0;
    
    // Funding rate risk (higher differential = higher risk)
    riskScore += Math.min(Math.abs(fundingDiff) * 100, 0.3);
    
    // Exchange risk
    const exchangeRisk = {
      binance: 0.1,
      bybit: 0.15,
      okx: 0.15,
      deribit: 0.2
    };
    
    riskScore += (
      exchangeRisk[exchange1 as keyof typeof exchangeRisk] || 0.3
    );
    
    riskScore += (
      exchangeRisk[exchange2 as keyof typeof exchangeRisk] || 0.3
    );
    
    // Add cross-exchange risk
    riskScore += 0.1; // Additional risk for cross-exchange positions
    
    return Math.min(riskScore, 0.95);
  }

  private async checkExchangeLimits(
    token: string,
    exchanges: string[],
    volume: number
  ): Promise<{
    warnings: string[];
    withinConcentrationLimits: boolean;
    hasLiquidity: boolean;
  }> {
    const warnings: string[] = [];
    let withinConcentrationLimits = true;
    let hasLiquidity = true;

    // Check each exchange
    for (const exchange of exchanges) {
      // Get exchange position limits
      const positionLimit = await this.getExchangePositionLimit(exchange, token);
      if (volume > positionLimit) {
        warnings.push(`Volume exceeds ${exchange} position limit`);
        withinConcentrationLimits = false;
      }

      // Check liquidity
      const liquidity = await this.getExchangeLiquidity(exchange, token);
      if (volume > liquidity * 0.1) { // Don't take more than 10% of liquidity
        warnings.push(`Volume may impact ${exchange} liquidity`);
        hasLiquidity = false;
      }
    }

    return {
      warnings,
      withinConcentrationLimits,
      hasLiquidity
    };
  }

  private async executePosition(
    token: string,
    exchange: string,
    volume: number,
    side: 'long' | 'short'
  ): Promise<{
    orderId: string;
    txHash: string;
    fees: number;
  }> {
    // Mock implementation - replace with actual exchange API calls
    return {
      orderId: crypto.randomUUID(),
      txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`,
      fees: volume * 0.001 // 0.1% fee
    };
  }

  private async getExchangePositionLimit(exchange: string, token: string): Promise<number> {
    // Mock implementation - replace with actual exchange API calls
    return this.maxPositionSize * 2;
  }

  private async getExchangeLiquidity(exchange: string, token: string): Promise<number> {
    // Mock implementation - replace with actual exchange API calls
    return this.maxPositionSize * 10;
  }
}