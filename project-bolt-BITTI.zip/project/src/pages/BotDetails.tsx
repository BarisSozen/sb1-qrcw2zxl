import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Activity, Shield, Clock, Zap, DollarSign, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Network, GitGraph } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, AreaChart, Area, BarChart, Bar } from 'recharts';

const BOT_DETAILS = {
  basis: {
    name: 'CEX Basis Arbitrage',
    description: 'Exploits price differences between spot and futures markets on centralized exchanges',
    metrics: {
      sharpeRatio: 2.8,
      sortinoRatio: 3.2,
      volatility: '15.8%',
      recoveryFactor: 3.1,
      winRate: '71.0%',
      successRate: '92.0%',
      profitFactor: '60.0%',
      maxDrawdown: '87.5%',
      recoveryRate: '77.5%'
    }
  },
  perpetual: {
    name: 'Hybrid Basis Arbitrage',
    description: 'Executes basis arbitrage across both centralized and decentralized exchanges',
    metrics: {
      sharpeRatio: 2.5,
      sortinoRatio: 2.9,
      volatility: '17.2%',
      recoveryFactor: 2.8,
      winRate: '68.5%',
      successRate: '89.0%',
      profitFactor: '55.0%',
      maxDrawdown: '82.0%',
      recoveryRate: '72.0%'
    }
  },
  dex: {
    name: 'DEX Basis Arbitrage',
    description: 'Performs basis arbitrage exclusively on decentralized exchanges',
    metrics: {
      sharpeRatio: 2.3,
      sortinoRatio: 2.7,
      volatility: '19.5%',
      recoveryFactor: 2.5,
      winRate: '65.0%',
      successRate: '87.0%',
      profitFactor: '52.0%',
      maxDrawdown: '80.0%',
      recoveryRate: '70.0%'
    }
  },
  statistical: {
    name: 'Statistical Arbitrage',
    description: 'Uses statistical methods to identify trading opportunities',
    metrics: {
      sharpeRatio: 2.6,
      sortinoRatio: 3.0,
      volatility: '16.5%',
      recoveryFactor: 2.9,
      winRate: '69.0%',
      successRate: '90.0%',
      profitFactor: '57.0%',
      maxDrawdown: '85.0%',
      recoveryRate: '75.0%'
    }
  },
  triangular: {
    name: 'Triangular Arbitrage',
    description: 'Uses Bellman-Ford algorithm to find optimal triangular arbitrage opportunities on Uniswap',
    metrics: {
      sharpeRatio: 2.4,
      sortinoRatio: 2.8,
      volatility: '18.2%',
      recoveryFactor: 2.7,
      winRate: '67.5%',
      successRate: '88.0%',
      profitFactor: '54.0%',
      maxDrawdown: '83.0%',
      recoveryRate: '73.0%'
    }
  }
};

// Sample data for triangular arbitrage paths
const triangularPathsData = [
  { name: 'ETH-USDC-WBTC', count: 42, profit: 0.32 },
  { name: 'WBTC-DAI-ETH', count: 38, profit: 0.28 },
  { name: 'ETH-DAI-USDC', count: 35, profit: 0.25 },
  { name: 'LINK-ETH-USDC', count: 30, profit: 0.22 },
  { name: 'USDC-WBTC-DAI', count: 25, profit: 0.18 }
];

// Sample data for gas optimization
const gasOptimizationData = [
  { name: 'Jan', standard: 120, optimized: 65 },
  { name: 'Feb', standard: 132, optimized: 72 },
  { name: 'Mar', standard: 145, optimized: 78 },
  { name: 'Apr', standard: 140, optimized: 75 },
  { name: 'May', standard: 150, optimized: 80 },
  { name: 'Jun', standard: 138, optimized: 74 }
];

// Sample data for execution time
const executionTimeData = [
  { name: '1', time: 450 },
  { name: '2', time: 380 },
  { name: '3', time: 420 },
  { name: '4', time: 390 },
  { name: '5', time: 360 },
  { name: '6', time: 340 },
  { name: '7', time: 320 }
];

const radarData = [
  { metric: 'Sharpe', value: 0.7 },
  { metric: 'Win Rate', value: 0.71 },
  { metric: 'Success', value: 0.92 },
  { metric: 'Profit', value: 0.6 },
  { metric: 'Recovery', value: 0.775 },
  { metric: 'Drawdown', value: 0.875 }
];

export const BotDetails = () => {
  const { botType } = useParams<{ botType: keyof typeof BOT_DETAILS }>();
  const navigate = useNavigate();
  
  if (!botType || !BOT_DETAILS[botType]) {
    return <div>Invalid bot type</div>;
  }

  const botDetails = BOT_DETAILS[botType];
  const metrics = botDetails.metrics;

  // Render specific content for triangular arbitrage bot
  const renderTriangularContent = () => {
    if (botType !== 'triangular') return null;

    return (
      <>
        <div className="bg-white p-6 rounded-lg shadow mt-6">
          <h2 className="text-xl font-bold mb-6 flex items-center">
            <Network className="w-5 h-5 mr-2 text-indigo-500" />
            Triangular Arbitrage Paths
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={triangularPathsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="count" name="Executions" fill="#8884d8" />
                  <Bar yAxisId="right" dataKey="profit" name="Avg. Profit (%)" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Top Performing Paths</h3>
              <p className="text-gray-600">
                The Bellman-Ford algorithm continuously analyzes all possible triangular paths to identify the most profitable opportunities. The chart shows the most frequently executed paths and their average profit percentages.
              </p>
              <div className="bg-indigo-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-indigo-900 mb-2">How It Works</h4>
                <p className="text-sm text-indigo-700">
                  The bot constructs a weighted graph where tokens are vertices and exchange rates are edge weights. It then uses the Bellman-Ford algorithm to detect negative-weight cycles, which represent profitable arbitrage opportunities.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mt-6">
          <h2 className="text-xl font-bold mb-6 flex items-center">
            <Zap className="w-5 h-5 mr-2 text-yellow-500" />
            Gas Optimization
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Gas Efficiency</h3>
              <p className="text-gray-600">
                Our triangular arbitrage bot implements advanced gas optimization techniques to ensure profitability even during high network congestion periods.
              </p>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Flash Swap Usage</span>
                    <span className="font-medium text-green-600">98%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '98%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">MEV Protection</span>
                    <span className="font-medium text-green-600">92%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '92%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Gas Price Optimization</span>
                    <span className="font-medium text-green-600">95%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '95%' }} />
                  </div>
                </div>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={gasOptimizationData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="standard" name="Standard Gas (Gwei)" stroke="#ff7300" />
                  <Line type="monotone" dataKey="optimized" name="Optimized Gas (Gwei)" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mt-6">
          <h2 className="text-xl font-bold mb-6 flex items-center">
            <GitGraph className="w-5 h-5 mr-2 text-blue-500" />
            Execution Performance
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={executionTimeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" label={{ value: 'Days', position: 'insideBottom', offset: -5 }} />
                  <YAxis label={{ value: 'Execution Time (ms)', angle: -90, position: 'insideLeft' }} />
                  <Tooltip formatter={(value) => [`${value} ms`, 'Execution Time']} />
                  <Area type="monotone" dataKey="time" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Execution Metrics</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Avg. Execution Time</div>
                  <div className="text-2xl font-bold">380ms</div>
                  <div className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingDown className="w-4 h-4 mr-1" />
                    12% faster
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Success Rate</div>
                  <div className="text-2xl font-bold">88.0%</div>
                  <div className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    2.5% improved
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Slippage</div>
                  <div className="text-2xl font-bold">0.08%</div>
                  <div className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingDown className="w-4 h-4 mr-1" />
                    0.02% lower
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Paths Analyzed</div>
                  <div className="text-2xl font-bold">1,250+</div>
                  <div className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    15% more
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/bot-performance')}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold">{botDetails.name}</h1>
            <p className="text-gray-600">{botDetails.description}</p>
          </div>
        </div>
      </div>

      {/* Risk Metrics and Performance Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Metrics */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-6 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-purple-500" />
            Risk Metrics
          </h2>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <div className="text-gray-600 mb-1">Sharpe Ratio</div>
              <div className="text-3xl font-bold text-blue-600">{metrics.sharpeRatio}</div>
            </div>
            <div>
              <div className="text-gray-600 mb-1">Sortino Ratio</div>
              <div className="text-3xl font-bold text-green-600">{metrics.sortinoRatio}</div>
            </div>
            <div>
              <div className="text-gray-600 mb-1">Volatility</div>
              <div className="text-3xl font-bold">{metrics.volatility}</div>
            </div>
            <div>
              <div className="text-gray-600 mb-1">Recovery Factor</div>
              <div className="text-3xl font-bold text-purple-600">{metrics.recoveryFactor}</div>
            </div>
          </div>
        </div>

        {/* Performance Radar */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-6">Performance Radar</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="metric" />
                <PolarRadiusAxis domain={[0, 1]} />
                <Radar
                  name="Performance"
                  dataKey="value"
                  stroke="#8884d8"
                  fill="#8884d8"
                  fillOpacity={0.6}
                />
                <Tooltip />
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-2" />
              <span>Sharpe Ratio: {metrics.winRate}</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-2" />
              <span>Win Rate: {metrics.winRate}</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-2" />
              <span>Success Rate: {metrics.successRate}</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-purple-500 mr-2" />
              <span>Profit Factor: {metrics.profitFactor}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Operational Metrics */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-6 flex items-center">
          <Clock className="w-5 h-5 mr-2 text-blue-500" />
          Operational Metrics
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-4">Execution</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Success Rate</span>
                  <span className="font-medium">{metrics.successRate}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full" 
                    style={{ width: metrics.successRate }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Win Rate</span>
                  <span className="font-medium">{metrics.winRate}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full" 
                    style={{ width: metrics.winRate }}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Risk Management</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Max Drawdown</span>
                  <span className="font-medium">{metrics.maxDrawdown}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-red-500 h-2 rounded-full" 
                    style={{ width: metrics.maxDrawdown }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Recovery Rate</span>
                  <span className="font-medium">{metrics.recoveryRate}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-yellow-500 h-2 rounded-full" 
                    style={{ width: metrics.recoveryRate }}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Performance</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Profit Factor</span>
                  <span className="font-medium">{metrics.profitFactor}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-500 h-2 rounded-full" 
                    style={{ width: metrics.profitFactor }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Sharpe Ratio</span>
                  <span className="font-medium">{metrics.sharpeRatio}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-indigo-500 h-2 rounded-full" 
                    style={{ width: `${(metrics.sharpeRatio / 4) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Efficiency Metrics */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-6 flex items-center">
          <Zap className="w-5 h-5 mr-2 text-yellow-500" />
          Efficiency Metrics
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Execution Speed</div>
            <div className="text-2xl font-bold">45ms</div>
            <div className="text-sm text-green-600 flex items-center mt-1">
              <TrendingUp className="w-4 h-4 mr-1" />
              5% faster
            </div>
          </div>
          
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Fill Rate</div>
            <div className="text-2xl font-bold">99.2%</div>
            <div className="text-sm text-green-600 flex items-center mt-1">
              <TrendingUp className="w-4 h-4 mr-1" />
              0.5% improved
            </div>
          </div>
          
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Slippage</div>
            <div className="text-2xl font-bold">0.05%</div>
            <div className="text-sm text-red-600 flex items-center mt-1">
              <TrendingDown className="w-4 h-4 mr-1" />
              0.01% higher
            </div>
          </div>
          
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Cost per Trade</div>
            <div className="text-2xl font-bold">$1.25</div>
            <div className="text-sm text-green-600 flex items-center mt-1">
              <TrendingDown className="w-4 h-4 mr-1" />
              $0.15 lower
            </div>
          </div>
        </div>
      </div>

      {/* Render triangular-specific content */}
      {renderTriangularContent()}
    </div>
  );
};

export default BotDetails;