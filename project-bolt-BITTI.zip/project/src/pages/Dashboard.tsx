import React, { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownRight, Activity, Download, AlertCircle } from 'lucide-react';
import { useArbitrage } from '../hooks/useArbitrage';
import { useDashboardData } from '../hooks/useDashboardData';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { supabase } from '../lib/supabaseClient';

/**
 * Dashboard component
 * 
 * Main dashboard page that displays key performance metrics, arbitrage opportunities,
 * and trading statistics. Includes real-time data visualization and export functionality.
 */
export const Dashboard = () => {
  const [timeframe, setTimeframe] = useState('30d');
  const [isExporting, setIsExporting] = useState(false);
  
  // Fetch arbitrage opportunities
  const {
    opportunities,
    isLoading: arbLoading,
    error: arbError,
    executeTrade,
    scanForOpportunities
  } = useArbitrage(5, 100000, 3);

  // Fetch dashboard data
  const {
    stats,
    botTypePerformance,
    yieldData,
    drawdownHistory,
    isLoading: dashboardLoading,
    error: dashboardError
  } = useDashboardData(timeframe);

  // Set up periodic scanning for opportunities
  useEffect(() => {
    const interval = setInterval(() => {
      scanForOpportunities();
    }, 30000); // Scan every 30 seconds
    
    return () => clearInterval(interval);
  }, [scanForOpportunities]);

  /**
   * Handle trade execution
   * 
   * Executes a trade for the selected opportunity and shows feedback.
   * 
   * @param opportunity - The trading opportunity to execute
   */
  const handleExecuteTrade = async (opportunity: any) => {
    try {
      const success = await executeTrade(opportunity);
      
      if (success) {
        alert(`Trade executed successfully for ${opportunity.token} with estimated profit of $${opportunity.estimatedProfit.toFixed(2)}`);
      } else {
        alert('Trade execution failed. Please try again.');
      }
    } catch (error) {
      console.error('Error executing trade:', error);
      alert(`Error executing trade: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  /**
   * Generate and download a PDF report
   * 
   * Creates a comprehensive PDF report with all dashboard data.
   */
  const handleExportReport = async () => {
    try {
      setIsExporting(true);
      
      const doc = new jsPDF();
      
      // Title
      doc.setFontSize(20);
      doc.text('Dow Digital Capital - Arbitrage Report', 105, 20, { align: 'center' });
      
      // Date
      doc.setFontSize(10);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 105, 30, { align: 'center' });
      doc.text(`Timeframe: ${timeframe}`, 105, 35, { align: 'center' });
      
      // Performance Summary
      doc.setFontSize(16);
      doc.text('Performance Summary', 14, 45);
      
      const performanceData = [
        ['Total P&L', `$${stats?.totalPnl?.toLocaleString() || '0'}`],
        ['Win Rate', `${stats?.winRate?.toFixed(1) || '0'}%`],
        ['Active Bots', `${stats?.activeBots || '0'}`],
        ['Open Positions', `${stats?.openPositions || '0'}`]
      ];
      
      (doc as any).autoTable({
        startY: 50,
        head: [['Metric', 'Value']],
        body: performanceData,
        theme: 'striped',
        headStyles: { fillColor: [0, 26, 26] }
      });
      
      // Bot Performance
      doc.setFontSize(16);
      doc.text('Bot Performance', 14, (doc as any).lastAutoTable.finalY + 15);
      
      const botPerformanceData = botTypePerformance.map(bot => [
        bot.name,
        `${bot.annualYield.toFixed(2)}%`,
        `${bot.totalTrades}`,
        `${bot.activeBots}`
      ]);
      
      (doc as any).autoTable({
        startY: (doc as any).lastAutoTable.finalY + 20,
        head: [['Bot Type', 'Annual Yield', 'Total Trades', 'Active Bots']],
        body: botPerformanceData,
        theme: 'striped',
        headStyles: { fillColor: [0, 26, 26] }
      });
      
      // Arbitrage Opportunities
      doc.setFontSize(16);
      doc.text('Current Arbitrage Opportunities', 14, (doc as any).lastAutoTable.finalY + 15);
      
      const opportunitiesData = opportunities.map(opp => [
        opp.token,
        opp.category,
        `${opp.source} → ${opp.target}`,
        `${opp.basisSpread.toFixed(2)}%`,
        `${opp.annualizedReturn.toFixed(2)}%`,
        `$${opp.requiredCapital.toLocaleString()}`
      ]);
      
      (doc as any).autoTable({
        startY: (doc as any).lastAutoTable.finalY + 20,
        head: [['Token', 'Type', 'Route', 'Spread', 'Annual Return', 'Capital Required']],
        body: opportunitiesData,
        theme: 'striped',
        headStyles: { fillColor: [0, 26, 26] }
      });
      
      // Save the PDF
      doc.save('dow-digital-arbitrage-report.pdf');
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate report. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  // Loading state
  if (dashboardLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Activity className="w-8 h-8 animate-spin text-blue-600" />
        <span className="ml-2 text-gray-600">Loading dashboard data...</span>
      </div>
    );
  }

  // Error state
  if (dashboardError) {
    return (
      <div className="bg-red-50 p-4 rounded-md">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-red-400" />
          <h3 className="ml-2 text-sm font-medium text-red-800">Error loading dashboard data</h3>
        </div>
        <div className="mt-2 text-sm text-red-700">{dashboardError}</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Arbitrage Dashboard</h1>
        <div className="flex space-x-4">
          <select
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            className="px-4 py-2 border rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
          <button
            onClick={handleExportReport}
            disabled={isExporting}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
          >
            <Download className="w-4 h-4 mr-2" />
            {isExporting ? 'Generating...' : 'Export Report'}
          </button>
        </div>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Total P&L</h3>
            {stats?.totalPnl && stats.totalPnl >= 0 ? (
              <ArrowUpRight className="text-green-500" />
            ) : (
              <ArrowDownRight className="text-red-500" />
            )}
          </div>
          <p className={`text-3xl font-bold mt-2 ${stats?.totalPnl && stats.totalPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            ${stats?.totalPnl ? Math.abs(stats.totalPnl).toLocaleString() : '0'}
          </p>
          <p className="text-sm text-gray-500">
            Win Rate: {stats?.winRate ? stats.winRate.toFixed(1) : 0}%
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Active Bots</h3>
            <Activity className="text-blue-500" />
          </div>
          <p className="text-3xl font-bold mt-2">{stats?.activeBots || 0}</p>
          <p className="text-sm text-gray-500">
            Open Positions: {stats?.openPositions || 0}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Total Trades</h3>
            <Activity className="text-purple-500" />
          </div>
          <p className="text-3xl font-bold mt-2">
            {stats?.totalTrades || 0}
          </p>
          <p className="text-sm text-gray-500">
            Best Pair: {stats?.bestPerformingPair || 'N/A'}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Current Balance</h3>
            <Activity className="text-green-500" />
          </div>
          <p className="text-3xl font-bold mt-2">
            ${stats?.currentBalance ? stats.currentBalance.toLocaleString() : '0'}
          </p>
          <p className="text-sm text-gray-500">
            Total Invested: ${stats?.totalInvested ? stats.totalInvested.toLocaleString() : '0'}
          </p>
        </div>
      </div>

      {/* Yield Performance Chart */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Yield Performance</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={yieldData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip formatter={(value) => `${value.toFixed(2)}%`} />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="dexYield" 
                stroke="#10B981" 
                name="DEX Yield" 
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="cexYield" 
                stroke="#3B82F6" 
                name="CEX Yield" 
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="hybridYield" 
                stroke="#6366F1" 
                name="Hybrid Yield" 
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="triangularYield" 
                stroke="#8B5CF6" 
                name="Triangular Yield" 
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="compound" 
                stroke="#F59E0B" 
                name="Compound Yield" 
                strokeWidth={2}
                strokeDasharray="5 5"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Drawdown Chart */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Drawdown History</h2>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={drawdownHistory}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="timestamp" 
                tickFormatter={(value) => new Date(value).toLocaleDateString()} 
              />
              <YAxis 
                tickFormatter={(value) => `${value.toFixed(1)}%`}
              />
              <Tooltip 
                formatter={(value) => [`${Number(value).toFixed(2)}%`, 'Drawdown']}
                labelFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <Area 
                type="monotone" 
                dataKey="drawdown" 
                stroke="#EF4444" 
                fill="#FEE2E2" 
                name="Drawdown" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-sm text-gray-600">Max Drawdown</p>
            <p className="text-xl font-bold text-red-600">
              {stats?.maxDrawdown ? stats.maxDrawdown.toFixed(2) : '0'}%
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Avg Drawdown</p>
            <p className="text-xl font-bold text-orange-600">
              {stats?.avgDrawdown ? stats.avgDrawdown.toFixed(2) : '0'}%
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Recovery Time</p>
            <p className="text-xl font-bold text-blue-600">
              {stats?.recoveryTime ? stats.recoveryTime.toFixed(1) : '0'} days
            </p>
          </div>
        </div>
      </div>

      {/* Live Opportunities */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Live Arbitrage Opportunities</h2>
          <div className="flex items-center">
            <button 
              onClick={scanForOpportunities}
              className="mr-4 px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors"
            >
              Refresh
            </button>
            <div className="flex items-center text-sm text-gray-600">
              <Activity className="w-4 h-4 mr-2" />
              Monitoring markets in real-time
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3">Type</th>
                <th className="text-left py-3">Token</th>
                <th className="text-left py-3">Source</th>
                <th className="text-left py-3">Target</th>
                <th className="text-left py-3">Spread</th>
                <th className="text-left py-3">Annual Return</th>
                <th className="text-left py-3">Required Capital</th>
                <th className="text-left py-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {arbLoading ? (
                <tr>
                  <td colSpan={8} className="py-4 text-center">Loading opportunities...</td>
                </tr>
              ) : arbError ? (
                <tr>
                  <td colSpan={8} className="py-4 text-center text-red-500">
                    Error loading opportunities: {arbError}
                  </td>
                </tr>
              ) : opportunities.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-4 text-center">No arbitrage opportunities found</td>
                </tr>
              ) : (
                opportunities.map((opportunity, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-3 capitalize">{opportunity.category}</td>
                    <td className="py-3">{opportunity.token}</td>
                    <td className="py-3">{opportunity.source}</td>
                    <td className="py-3">{opportunity.target}</td>
                    <td className="py-3 text-green-500">
                      +{opportunity.basisSpread.toFixed(2)}%
                    </td>
                    <td className="py-3 text-green-500">
                      +{opportunity.annualizedReturn.toFixed(2)}%
                    </td>
                    <td className="py-3">
                      ${opportunity.requiredCapital.toLocaleString()}
                    </td>
                    <td className="py-3">
                      <button
                        onClick={() => handleExecuteTrade(opportunity)}
                        disabled={arbLoading}
                        className="inline-flex items-center px-3 py-1 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                      >
                        Execute
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;