import React from 'react';
import { Link } from 'react-router-dom';

// Update the BOT_TYPES constant to include the triangular bot type
const BOT_TYPES = [
  {
    id: 'basis',
    name: 'CEX Basis Arbitrage',
    description: 'Exploits price differences between spot and futures markets on centralized exchanges',
    features: [
      'Cross-exchange basis trading on CEXs',
      'Funding rate optimization',
      'CEX-specific execution strategies',
      'High-frequency trading capabilities'
    ]
  },
  {
    id: 'perpetual',
    name: 'Hybrid Basis Arbitrage',
    description: 'Executes basis arbitrage across both centralized and decentralized exchanges',
    features: [
      'Cross-platform arbitrage',
      'CEX-DEX bridging strategies',
      'Multi-venue execution',
      'Hybrid liquidity optimization'
    ]
  },
  {
    id: 'dex',
    name: 'DEX Basis Arbitrage',
    description: 'Performs basis arbitrage exclusively on decentralized exchanges',
    features: [
      'Smart contract interaction',
      'Gas optimization',
      'MEV protection',
      'Flash loan integration'
    ]
  },
  {
    id: 'statistical',
    name: 'Statistical Arbitrage',
    description: 'Uses statistical methods to identify trading opportunities',
    features: [
      'Mean reversion strategies',
      'Correlation analysis',
      'Volatility modeling',
      'Risk-adjusted position sizing'
    ]
  },
  {
    id: 'triangular',
    name: 'Triangular Arbitrage',
    description: 'Uses Bellman-Ford algorithm to find optimal triangular arbitrage opportunities on Uniswap',
    features: [
      'Real-time price graph analysis',
      'Gas-optimized execution',
      'Smart path finding',
      'Multi-token arbitrage'
    ]
  }
] as const;

const BotPerformance: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Bot Performance Overview</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {BOT_TYPES.map((bot) => (
          <Link
            key={bot.id}
            to={`/bot-performance/${bot.id}`}
            className="block p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow"
          >
            <h2 className="text-xl font-semibold mb-3">{bot.name}</h2>
            <p className="text-gray-600 mb-4">{bot.description}</p>
            <ul className="space-y-2">
              {bot.features.map((feature, index) => (
                <li key={index} className="text-sm text-gray-500">
                  • {feature}
                </li>
              ))}
            </ul>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default BotPerformance;

export { BotPerformance }