import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabaseClient';
import { Key, RefreshCw, AlertTriangle, CheckCircle, XCircle, Eye, EyeOff, Loader } from 'lucide-react';
import { useExchangeConnection } from '../hooks/useExchangeConnection';

const SUPPORTED_EXCHANGES = [
  { id: 'binance', name: 'Binance', icon: '💰', requiresPassphrase: false },
  { id: 'bybit', name: 'Bybit', icon: '🔄', requiresPassphrase: false },
  { id: 'okx', name: 'OKX', icon: '📊', requiresPassphrase: true },
  { id: 'deribit', name: 'Deribit', icon: '🎯', requiresPassphrase: false },
  { id: 'uniswap', name: 'Uniswap', icon: '🦄', requiresPassphrase: false }
] as const;

interface ExchangeApiKey {
  id: string;
  exchange: typeof SUPPORTED_EXCHANGES[number]['id'];
  api_key: string;
  active: boolean;
  created_at: string;
}

export const Exchanges = () => {
  const queryClient = useQueryClient();
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const [testingExchange, setTestingExchange] = useState<string | null>(null);
  
  // Use the exchange connection hook
  const { 
    exchangeStatuses, 
    testConnection, 
    isLoading: connectionLoading 
  } = useExchangeConnection();

  // Fetch API keys
  const { data: apiKeys, isLoading } = useQuery({
    queryKey: ['exchange-api-keys'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('exchange_api_keys')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as ExchangeApiKey[];
    }
  });

  // Toggle API key status mutation
  const toggleApiKey = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase
        .from('exchange_api_keys')
        .update({ active })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exchange-api-keys'] });
    }
  });

  // Delete API key mutation
  const deleteApiKey = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('exchange_api_keys')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exchange-api-keys'] });
    }
  });

  // Rotate API key mutation
  const rotateApiKey = useMutation({
    mutationFn: async ({ id, newApiKey, newApiSecret, newPassphrase }: {
      id: string;
      newApiKey: string;
      newApiSecret: string;
      newPassphrase?: string;
    }) => {
      const { error } = await supabase
        .from('exchange_api_keys')
        .update({
          api_key: newApiKey,
          api_secret: newApiSecret,
          passphrase: newPassphrase || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exchange-api-keys'] });
    }
  });

  const handleToggleKey = async (id: string, currentStatus: boolean) => {
    await toggleApiKey.mutateAsync({ id, active: !currentStatus });
  };

  const handleDeleteKey = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this API key?')) {
      await deleteApiKey.mutateAsync(id);
    }
  };

  const handleRotateKey = async (id: string) => {
    const exchange = apiKeys?.find(key => key.id === id)?.exchange;
    if (!exchange) return;

    const requiresPassphrase = SUPPORTED_EXCHANGES.find(e => e.id === exchange)?.requiresPassphrase;

    const newApiKey = window.prompt('Enter new API key:');
    if (!newApiKey) return;

    const newApiSecret = window.prompt('Enter new API secret:');
    if (!newApiSecret) return;

    let newPassphrase;
    if (requiresPassphrase) {
      newPassphrase = window.prompt('Enter new passphrase:');
      if (!newPassphrase) return;
    }

    await rotateApiKey.mutateAsync({
      id,
      newApiKey,
      newApiSecret,
      newPassphrase
    });
  };

  const handleTestConnection = async (exchange: string) => {
    try {
      setTestingExchange(exchange);
      const success = await testConnection(exchange);
      
      if (success) {
        alert(`Successfully connected to ${exchange}!`);
      } else {
        alert(`Failed to connect to ${exchange}. Please check your API keys.`);
      }
    } catch (error) {
      console.error(`Error testing connection to ${exchange}:`, error);
      alert(`Error testing connection to ${exchange}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setTestingExchange(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Exchange API Keys</h1>
        <button
          onClick={() => window.location.href = '/clients'}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Add New API Key
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {SUPPORTED_EXCHANGES.map(exchange => {
          const status = exchangeStatuses.find(s => s.exchange === exchange.id);
          const exchangeKeys = apiKeys?.filter(key => key.exchange === exchange.id) || [];
          const activeKeys = exchangeKeys.filter(key => key.active).length;
          
          return (
            <div key={exchange.id} className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <span className="mr-2">{exchange.icon}</span>
                  {exchange.name}
                </h3>
                {status?.connected ? (
                  <CheckCircle className="text-green-500" />
                ) : (
                  <AlertTriangle className="text-yellow-500" />
                )}
              </div>
              <p className="text-3xl font-bold mt-2">{exchangeKeys.length}</p>
              <p className="text-sm text-gray-500 mb-4">
                {activeKeys} active / {exchangeKeys.length} total
              </p>
              <button
                onClick={() => handleTestConnection(exchange.id)}
                disabled={testingExchange === exchange.id}
                className="w-full mt-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors flex items-center justify-center"
              >
                {testingExchange === exchange.id ? (
                  <>
                    <Loader className="w-4 h-4 mr-2 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Test Connection
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-4 py-5 sm:px-6">
          <h2 className="text-xl font-semibold">API Keys</h2>
        </div>
        <div className="border-t border-gray-200">
          <table className="min-w-full">
            <thead>
              <tr className="border-b">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Exchange
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  API Key
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Connection
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                    Loading API keys...
                  </td>
                </tr>
              ) : apiKeys?.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                    No API keys found. Add API keys through the Clients page.
                  </td>
                </tr>
              ) : (
                apiKeys?.map((key) => {
                  const exchangeInfo = SUPPORTED_EXCHANGES.find(e => e.id === key.exchange);
                  const connectionStatus = exchangeStatuses.find(s => s.exchange === key.exchange);
                  
                  return (
                    <tr key={key.id} className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <span className="mr-2">
                            {exchangeInfo?.icon}
                          </span>
                          <span className="font-medium">
                            {exchangeInfo?.name}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-mono text-sm">
                        {showSecrets[key.id] ? key.api_key : '••••' + key.api_key.slice(-4)}
                        <button
                          onClick={() => setShowSecrets(prev => ({ ...prev, [key.id]: !prev[key.id] }))}
                          className="ml-2 text-gray-400 hover:text-gray-600"
                        >
                          {showSecrets[key.id] ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(key.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          key.active
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {key.active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          connectionStatus?.connected
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {connectionStatus?.connected ? 'Connected' : 'Disconnected'}
                        </span>
                        {connectionStatus?.error && (
                          <p className="text-xs text-red-500 mt-1">{connectionStatus.error}</p>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => handleToggleKey(key.id, key.active)}
                            className={`p-1 rounded-full ${
                              key.active
                                ? 'text-red-600 hover:text-red-900'
                                : 'text-green-600 hover:text-green-900'
                            }`}
                            title={key.active ? 'Deactivate' : 'Activate'}
                          >
                            {key.active ? (
                              <XCircle className="w-4 h-4" />
                            ) : (
                              <CheckCircle className="w-4 h-4" />
                            )}
                          </button>
                          <button
                            onClick={() => handleRotateKey(key.id)}
                            className="p-1 rounded-full text-blue-600 hover:text-blue-900"
                            title="Rotate API Key"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleTestConnection(key.exchange)}
                            disabled={testingExchange === key.exchange}
                            className="p-1 rounded-full text-green-600 hover:text-green-900"
                            title="Test Connection"
                          >
                            {testingExchange === key.exchange ? (
                              <Loader className="w-4 h-4 animate-spin" />
                            ) : (
                              <CheckCircle className="w-4 h-4" />
                            )}
                          </button>
                          <button
                            onClick={() => handleDeleteKey(key.id)}
                            className="p-1 rounded-full text-red-600 hover:text-red-900"
                            title="Delete"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">API Key Requirements</h2>
        
        <div className="space-y-6">
          {SUPPORTED_EXCHANGES.map(exchange => (
            <div key={exchange.id} className="border-b pb-4 last:border-b-0 last:pb-0">
              <h3 className="text-lg font-semibold mb-2 flex items-center">
                <span className="mr-2">{exchange.icon}</span>
                {exchange.name}
              </h3>
              
              {exchange.id === 'binance' && (
                <div className="space-y-2">
                  <p className="text-gray-700">Binance API keys require the following permissions:</p>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>Enable Reading (mandatory)</li>
                    <li>Enable Spot & Margin Trading (for trading)</li>
                    <li>Enable Futures (for futures trading)</li>
                    <li>Restrict access to trusted IPs only (recommended)</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-2">
                    Create API keys at: <a href="https://www.binance.com/en/my/settings/api-management" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Binance API Management</a>
                  </p>
                </div>
              )}
              
              {exchange.id === 'bybit' && (
                <div className="space-y-2">
                  <p className="text-gray-700">Bybit API keys require the following permissions:</p>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>Read-Only (for market data only)</li>
                    <li>Trade (for executing trades)</li>
                    <li>Wallet (for account balance)</li>
                    <li>IP restriction recommended</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-2">
                    Create API keys at: <a href="https://www.bybit.com/app/user/api-management" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Bybit API Management</a>
                  </p>
                </div>
              )}
              
              {exchange.id === 'okx' && (
                <div className="space-y-2">
                  <p className="text-gray-700">OKX API keys require the following permissions:</p>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>Read permission (mandatory)</li>
                    <li>Trade permission (for trading)</li>
                    <li>Withdrawal permission (not required for this application)</li>
                    <li><strong>Passphrase is required</strong> in addition to API key and secret</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-2">
                    Create API keys at: <a href="https://www.okx.com/account/my-api" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">OKX API Management</a>
                  </p>
                </div>
              )}
              
              {exchange.id === 'deribit' && (
                <div className="space-y-2">
                  <p className="text-gray-700">Deribit API keys require the following permissions:</p>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>Account (for balance information)</li>
                    <li>Trade (for executing trades)</li>
                    <li>Block Trade (not required)</li>
                    <li>IP whitelist recommended</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-2">
                    Create API keys at: <a href="https://www.deribit.com/main#/account?scrollTo=api" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Deribit API Management</a>
                  </p>
                </div>
              )}
              
              {exchange.id === 'uniswap' && (
                <div className="space-y-2">
                  <p className="text-gray-700">Uniswap doesn't require API keys as it's a decentralized exchange.</p>
                  <ul className="list-disc pl-5 text-gray-600">
                    <li>Wallet connection is used instead of API keys</li>
                    <li>Ethereum wallet address must be provided in client settings</li>
                    <li>Gas fees are required for transactions</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-2">
                    No API key setup required. Just ensure wallet addresses are configured in client settings.
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Exchanges;