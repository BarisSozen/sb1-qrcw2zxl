import React from 'react';
import { PDFGenerator } from '../services/PDFGenerator';
import { Download } from 'lucide-react';

export const Documentation = () => {
  const handleDownload = async () => {
    const pdfGenerator = new PDFGenerator();
    const pdfBuffer = await pdfGenerator.generateSystemOverview();
    
    // Create blob and download
    const blob = new Blob([pdfBuffer], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Dow-Digital-Capital-System-Overview.pdf';
    link.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">System Documentation</h1>
        <button
          onClick={handleDownload}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </button>
      </div>
      
      <div className="prose max-w-none">
        <iframe
          src="/docs/SYSTEM_OVERVIEW.md"
          className="w-full h-[calc(100vh-200px)] border rounded-lg"
          title="System Overview"
        />
      </div>
    </div>
  );
};

export default Documentation;