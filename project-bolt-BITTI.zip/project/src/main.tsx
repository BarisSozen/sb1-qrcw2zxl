import 'core-js/stable';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

/**
 * Application entry point
 * 
 * Renders the main App component inside a StrictMode wrapper.
 * StrictMode helps identify potential problems in the application
 * by performing additional checks and warnings during development.
 */
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);