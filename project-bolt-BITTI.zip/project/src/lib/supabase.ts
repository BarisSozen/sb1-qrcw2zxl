// This file is deprecated - use supabaseClient.ts instead
export * from './supabaseClient';