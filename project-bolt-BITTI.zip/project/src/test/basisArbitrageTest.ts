import { BasisArbitrageBot } from '../algorithms/bots/BasisArbitrageBot';
import type { BotConfig } from '../types/bots';
import type { MarketPrice } from '../types/market';

// Create dummy market data
const generateMarketPrices = (): MarketPrice[] => {
  const now = Date.now();
  return [
    // Binance prices
    {
      token: 'BTC',
      spotPrice: 35000,
      futuresPrice: 35700,
      fundingRate: 0.0001,
      futuresExpiry: now + (90 * 24 * 60 * 60 * 1000), // 90 days
      timestamp: now,
      source: 'binance',
      target: 'binance',
      category: 'cex'
    },
    // Bybit prices with a profitable spread
    {
      token: 'BTC',
      spotPrice: 34800,
      futuresPrice: 35900,
      fundingRate: 0.0002,
      futuresExpiry: now + (90 * 24 * 60 * 60 * 1000),
      timestamp: now,
      source: 'bybit',
      target: 'bybit',
      category: 'cex'
    },
    // ETH prices on Binance
    {
      token: 'ETH',
      spotPrice: 2000,
      futuresPrice: 2050,
      fundingRate: 0.0001,
      futuresExpiry: now + (90 * 24 * 60 * 60 * 1000),
      timestamp: now,
      source: 'binance',
      target: 'binance',
      category: 'cex'
    },
    // ETH prices on Bybit with opportunity
    {
      token: 'ETH',
      spotPrice: 1980,
      futuresPrice: 2070,
      fundingRate: 0.00015,
      futuresExpiry: now + (90 * 24 * 60 * 60 * 1000),
      timestamp: now,
      source: 'bybit',
      target: 'bybit',
      category: 'cex'
    }
  ];
};

// Test configuration
const testConfig: BotConfig = {
  id: 'test-bot-1',
  name: 'Test Basis Bot',
  type: 'basis',
  minProfitThreshold: 0.5, // 0.5% minimum profit
  maxPositionSize: 100000, // $100k max position
  leverageLimit: 3,
  exchanges: ['binance', 'bybit'],
  pairs: ['BTC/USD', 'ETH/USD'],
  interval: 1000, // 1 second interval
  active: true,
  status: 'running',
  description: 'Test bot for basis arbitrage'
};

async function runTest() {
  console.log('\x1b[36m%s\x1b[0m', 'Starting Basis Arbitrage Bot Test');
  console.log('\x1b[36m%s\x1b[0m', '-----------------------------------');

  // Initialize bot
  const bot = new BasisArbitrageBot(testConfig);
  
  // Generate test market data
  const marketPrices = generateMarketPrices();
  
  console.log('\x1b[33m%s\x1b[0m', '\nMarket Prices:');
  console.log(JSON.stringify(marketPrices, null, 2));
  
  try {
    // Find opportunities
    console.log('\x1b[33m%s\x1b[0m', '\nSearching for arbitrage opportunities...');
    const opportunities = await bot.findOpportunities(marketPrices);
    
    console.log('\x1b[32m%s\x1b[0m', '\nFound Opportunities:');
    console.log(JSON.stringify(opportunities, null, 2));
    
    // Test each opportunity
    for (const opportunity of opportunities) {
      console.log('\x1b[33m%s\x1b[0m', `\nValidating opportunity: ${opportunity.id}`);
      const isValid = await bot.validateOpportunity(opportunity);
      console.log('\x1b[36m%s\x1b[0m', `Opportunity valid: ${isValid}`);
      
      if (isValid) {
        console.log('\x1b[33m%s\x1b[0m', '\nCalculating position size...');
        const position = await bot.calculatePosition(opportunity);
        console.log('\x1b[36m%s\x1b[0m', 'Position details:', JSON.stringify(position, null, 2));
        
        console.log('\x1b[33m%s\x1b[0m', '\nChecking risk limits...');
        const riskAssessment = await bot.checkRiskLimits(opportunity);
        console.log('\x1b[36m%s\x1b[0m', 'Risk assessment:', JSON.stringify(riskAssessment, null, 2));
        
        if (!riskAssessment.warnings.length && Object.values(riskAssessment.limits).every(limit => limit)) {
          console.log('\x1b[33m%s\x1b[0m', '\nExecuting trade...');
          const result = await bot.executeTrade(opportunity);
          console.log('\x1b[32m%s\x1b[0m', 'Trade result:', JSON.stringify(result, null, 2));
        } else {
          console.log('\x1b[31m%s\x1b[0m', '\nTrade skipped due to risk limits:', {
            warnings: riskAssessment.warnings,
            limits: riskAssessment.limits
          });
        }
      }
    }
    
    // Clean exit after test completion
    process.exit(0);
  } catch (error) {
    console.error('\x1b[31m%s\x1b[0m', 'Error during test:', error);
    process.exit(1);
  }
}

// Handle process signals
process.on('SIGINT', () => {
  console.log('\nGracefully shutting down...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\nGracefully shutting down...');
  process.exit(0);
});

// Run the test
runTest().catch((error) => {
  console.error('\x1b[31m%s\x1b[0m', 'Unhandled error:', error);
  process.exit(1);
});