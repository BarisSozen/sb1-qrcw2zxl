import React from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { 
  LayoutDashboard, 
  LineChart, 
  Settings, 
  Shield, 
  Users, 
  Activity, 
  Bot,
  DollarSign,
  Key
} from 'lucide-react';

/**
 * Navbar component
 * 
 * Provides navigation for the application with a sidebar menu.
 * Highlights the current active route and renders child routes via Outlet.
 */
export const Navbar: React.FC = () => {
  const location = useLocation();

  // Navigation items configuration
  const navItems = [
    { path: '/dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { path: '/trades', name: 'Trades', icon: LineChart },
    { path: '/clients', name: 'Clients', icon: Users },
    { path: '/exchanges', name: 'Exchanges', icon: Key },
    { path: '/risk-report', name: 'Risk Report', icon: Shield },
    { path: '/bot-performance', name: 'Bot Performance', icon: Activity },
    { path: '/bot-management', name: 'Bot Management', icon: Bot },
    { path: '/sales-commission', name: 'Sales Commission', icon: DollarSign },
    { path: '/settings', name: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200">
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center h-16 px-6 border-b border-gray-200">
            <Link to="/" className="text-xl font-semibold text-gray-900">
              Dow Digital
            </Link>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${
                    isActive
                      ? 'bg-gray-100 text-gray-900'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 ml-64">
        <div className="p-8">
          <Outlet />
        </div>
      </div>
    </div>
  );
};