import { format as dateFns } from 'date-fns';
import { supabase } from '../lib/supabaseClient';

export interface ErrorLog {
  id: string;
  timestamp: string;
  level: 'error' | 'warn' | 'info';
  message: string;
  stack?: string;
  context: {
    botId?: string;
    clientId?: string;
    exchange?: string;
    pair?: string;
    [key: string]: any;
  };
  resolved: boolean;
  resolvedAt?: string;
  resolvedBy?: string;
  resolution?: string;
}

export class ErrorLoggingService {
  private static instance: ErrorLoggingService;

  private constructor() {}

  public static getInstance(): ErrorLoggingService {
    if (!ErrorLoggingService.instance) {
      ErrorLoggingService.instance = new ErrorLoggingService();
    }
    return ErrorLoggingService.instance;
  }

  async logError(error: Error, context: ErrorLog['context']): Promise<void> {
    try {
      const errorLog: Omit<ErrorLog, 'id'> = {
        timestamp: new Date().toISOString(),
        level: 'error',
        message: error.message,
        stack: error.stack,
        context,
        resolved: false
      };

      // Log to console in development
      if (import.meta.env.DEV) {
        console.error('[Error Log]', {
          ...errorLog,
          context
        });
      }

      // Log to Supabase
      const { error: dbError } = await supabase
        .from('error_logs')
        .insert([errorLog]);

      if (dbError) throw dbError;

      // Check if this is a critical error
      if (this.isCriticalError(error, context)) {
        await this.handleCriticalError(error, context);
      }
    } catch (loggingError) {
      console.error('Failed to log error:', loggingError);
    }
  }

  async generateMonthlyReport(): Promise<string> {
    try {
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 1);

      const { data: errors, error } = await supabase
        .from('error_logs')
        .select('*')
        .gte('timestamp', startDate.toISOString())
        .order('timestamp', { ascending: false });

      if (error) throw error;

      // Group errors by type
      const groupedErrors = this.groupErrors(errors || []);

      // Generate report content
      let report = `Error Report - ${dateFns(new Date(), 'MMMM yyyy')}\n\n`;
      report += `Total Errors: ${errors?.length || 0}\n`;
      report += `Resolved: ${errors?.filter(e => e.resolved).length || 0}\n`;
      report += `Unresolved: ${errors?.filter(e => !e.resolved).length || 0}\n\n`;

      // Add error groups
      Object.entries(groupedErrors).forEach(([type, errors]) => {
        report += `\n${type} (${errors.length} occurrences):\n`;
        errors.forEach(error => {
          report += `- ${error.message}\n`;
          if (error.context.botId) {
            report += `  Bot: ${error.context.botId}\n`;
          }
          report += `  First seen: ${dateFns(new Date(error.timestamp), 'PPpp')}\n`;
          report += `  Status: ${error.resolved ? 'Resolved' : 'Unresolved'}\n`;
        });
      });

      return report;
    } catch (error) {
      console.error('Failed to generate monthly report:', error);
      throw error;
    }
  }

  private groupErrors(errors: ErrorLog[]): Record<string, ErrorLog[]> {
    const groups: Record<string, ErrorLog[]> = {};

    errors.forEach(error => {
      const type = this.categorizeError(error);
      if (!groups[type]) {
        groups[type] = [];
      }
      groups[type].push(error);
    });

    return groups;
  }

  private categorizeError(error: ErrorLog): string {
    if (error.message.includes('API')) return 'API Errors';
    if (error.message.includes('database')) return 'Database Errors';
    if (error.message.includes('timeout')) return 'Timeout Errors';
    if (error.context.exchange) return 'Exchange Errors';
    if (error.context.botId) return 'Bot Errors';
    return 'Other Errors';
  }

  private isCriticalError(error: Error, context: ErrorLog['context']): boolean {
    // Define critical error conditions
    const criticalConditions = [
      error.message.includes('database connection'),
      error.message.includes('API key invalid'),
      error.message.includes('insufficient funds'),
      error.message.includes('liquidation'),
      context.failedAttempts && context.failedAttempts > 3
    ];

    return criticalConditions.some(condition => condition);
  }

  private async handleCriticalError(error: Error, context: ErrorLog['context']): Promise<void> {
    try {
      // Log critical error to security incidents
      await supabase
        .from('security_incidents')
        .insert([{
          type: 'Critical Error',
          description: error.message,
          risk_level: 'high',
          status: 'active',
          bot_id: context.botId,
          client_id: context.clientId
        }]);

      // Update bot status if applicable
      if (context.botId) {
        await supabase
          .from('bot_configs')
          .update({ status: 'error' })
          .eq('id', context.botId);
      }
    } catch (error) {
      console.error('Failed to handle critical error:', error);
    }
  }
}