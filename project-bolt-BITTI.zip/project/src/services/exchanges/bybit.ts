/**
 * Bybit Service
 * 
 * This service provides methods for interacting with the Bybit exchange API.
 */
export class BybitService {
  private readonly BASE_URL = 'https://api.bybit.com';
  private readonly API_KEY: string;
  private readonly API_SECRET: string;
  private readonly USE_TESTNET: boolean;

  /**
   * Constructor
   * 
   * @param apiKey - Bybit API key
   * @param apiSecret - Bybit API secret
   * @param useTestnet - Whether to use the testnet (default: false)
   */
  constructor(apiKey: string, apiSecret: string, useTestnet: boolean = false) {
    this.API_KEY = apiKey;
    this.API_SECRET = apiSecret;
    this.USE_TESTNET = useTestnet;
    
    if (this.USE_TESTNET) {
      this.BASE_URL = 'https://api-testnet.bybit.com';
    }
  }

  /**
   * Generate signature for API request
   * 
   * @param timestamp - Request timestamp
   * @param method - HTTP method
   * @param path - Request path
   * @param queryString - Query string or request body
   * @returns HMAC signature
   */
  private async generateSignature(
    timestamp: number,
    method: string,
    path: string,
    queryString: string = ''
  ): Promise<string> {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(this.API_SECRET),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    
    const signString = `${timestamp}${this.API_KEY}${queryString}`;
    const signature = await crypto.subtle.sign(
      'HMAC',
      key,
      encoder.encode(signString)
    );
    
    // Convert to hex
    return Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  /**
   * Make a request to the Bybit API
   * 
   * @param method - HTTP method
   * @param path - API endpoint path
   * @param params - Request parameters
   * @param isPrivate - Whether this is a private API request
   * @returns Promise that resolves to the API response
   */
  private async request(
    method: 'GET' | 'POST' | 'DELETE',
    path: string,
    params: Record<string, any> = {},
    isPrivate: boolean = false
  ): Promise<any> {
    try {
      const url = new URL(`${this.BASE_URL}${path}`);
      const timestamp = Date.now();
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      
      let body: string | null = null;
      
      if (isPrivate) {
        headers['X-BAPI-API-KEY'] = this.API_KEY;
        headers['X-BAPI-TIMESTAMP'] = timestamp.toString();
        headers['X-BAPI-RECV-WINDOW'] = '5000';
      }
      
      // Handle query parameters for GET requests
      if (method === 'GET') {
        Object.entries(params).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            url.searchParams.append(key, value.toString());
          }
        });
        
        if (isPrivate) {
          const queryString = url.searchParams.toString();
          const signature = await this.generateSignature(timestamp, method, path, queryString);
          headers['X-BAPI-SIGN'] = signature;
        }
      } else {
        // Handle body for POST/DELETE requests
        body = JSON.stringify(params);
        
        if (isPrivate) {
          const signature = await this.generateSignature(timestamp, method, path, body);
          headers['X-BAPI-SIGN'] = signature;
        }
      }
      
      const response = await fetch(url.toString(), {
        method,
        headers,
        body: method === 'GET' ? null : body
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Bybit API error: ${response.status} ${response.statusText} - ${JSON.stringify(errorData)}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Bybit request error:', error);
      throw error;
    }
  }

  /**
   * Get account balance
   * 
   * @returns Promise that resolves to account balance data
   */
  async getAccountBalance(): Promise<any> {
    return this.request('GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED' }, true);
  }

  /**
   * Get market price for a symbol
   * 
   * @param symbol - Trading symbol (e.g., 'BTCUSDT')
   * @returns Promise that resolves to market price data
   */
  async getMarketPrice(symbol: string): Promise<any> {
    // Convert symbol format if needed
    const formattedSymbol = symbol.replace('/', '');
    
    // Get ticker data
    const tickerResponse = await this.request('GET', '/v5/market/tickers', {
      category: 'spot',
      symbol: formattedSymbol
    });
    
    if (!tickerResponse.result || !tickerResponse.result.list || tickerResponse.result.list.length === 0) {
      throw new Error(`No ticker data found for ${symbol}`);
    }
    
    const ticker = tickerResponse.result.list[0];
    
    // Get order book data
    const orderBookResponse = await this.request('GET', '/v5/market/orderbook', {
      category: 'spot',
      symbol: formattedSymbol,
      limit: 5
    });
    
    if (!orderBookResponse.result) {
      throw new Error(`No order book data found for ${symbol}`);
    }
    
    return {
      symbol: formattedSymbol,
      price: parseFloat(ticker.lastPrice),
      bid: parseFloat(orderBookResponse.result.b[0][0]),
      ask: parseFloat(orderBookResponse.result.a[0][0]),
      volume: parseFloat(ticker.volume24h),
      timestamp: Date.now()
    };
  }

  /**
   * Place a limit order
   * 
   * @param symbol - Trading symbol (e.g., 'BTCUSDT')
   * @param side - Order side ('Buy' or 'Sell')
   * @param quantity - Order quantity
   * @param price - Order price
   * @returns Promise that resolves to the order result
   */
  async placeLimitOrder(
    symbol: string,
    side: 'Buy' | 'Sell',
    quantity: number,
    price: number
  ): Promise<any> {
    const formattedSymbol = symbol.replace('/', '');
    
    return this.request('POST', '/v5/order/create', {
      category: 'spot',
      symbol: formattedSymbol,
      side,
      orderType: 'Limit',
      qty: quantity.toString(),
      price: price.toString(),
      timeInForce: 'GTC'
    }, true);
  }

  /**
   * Place a market order
   * 
   * @param symbol - Trading symbol (e.g., 'BTCUSDT')
   * @param side - Order side ('Buy' or 'Sell')
   * @param quantity - Order quantity
   * @returns Promise that resolves to the order result
   */
  async placeMarketOrder(
    symbol: string,
    side: 'Buy' | 'Sell',
    quantity: number
  ): Promise<any> {
    const formattedSymbol = symbol.replace('/', '');
    
    return this.request('POST', '/v5/order/create', {
      category: 'spot',
      symbol: formattedSymbol,
      side,
      orderType: 'Market',
      qty: quantity.toString()
    }, true);
  }

  /**
   * Get open orders
   * 
   * @param symbol - Optional trading symbol to filter by
   * @returns Promise that resolves to open orders
   */
  async getOpenOrders(symbol?: string): Promise<any> {
    const params: Record<string, any> = {
      category: 'spot',
      limit: 50
    };
    
    if (symbol) {
      params.symbol = symbol.replace('/', '');
    }
    
    return this.request('GET', '/v5/order/realtime', params, true);
  }

  /**
   * Cancel an order
   * 
   * @param symbol - Trading symbol
   * @param orderId - Order ID
   * @returns Promise that resolves to the cancellation result
   */
  async cancelOrder(symbol: string, orderId: string): Promise<any> {
    return this.request('POST', '/v5/order/cancel', {
      category: 'spot',
      symbol: symbol.replace('/', ''),
      orderId
    }, true);
  }

  /**
   * Get funding rate for a futures symbol
   * 
   * @param symbol - Futures symbol (e.g., 'BTCUSDT')
   * @returns Promise that resolves to funding rate data
   */
  async getFundingRate(symbol: string): Promise<any> {
    const formattedSymbol = symbol.replace('/', '');
    
    return this.request('GET', '/v5/market/funding/history', {
      category: 'linear',
      symbol: formattedSymbol,
      limit: 1
    });
  }
}