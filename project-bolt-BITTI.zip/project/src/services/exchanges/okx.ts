/**
 * OKX Service
 * 
 * This service provides methods for interacting with the OKX exchange API.
 * OKX requires an API key, secret, and passphrase for authentication.
 */
export class OKXService {
  private readonly BASE_URL = 'https://www.okx.com';
  private readonly API_KEY: string;
  private readonly API_SECRET: string;
  private readonly PASSPHRASE: string;
  private readonly USE_DEMO: boolean;

  /**
   * Constructor
   * 
   * @param apiKey - OKX API key
   * @param apiSecret - OKX API secret
   * @param passphrase - OKX API passphrase
   * @param useDemo - Whether to use the demo trading environment (default: false)
   */
  constructor(apiKey: string, apiSecret: string, passphrase: string, useDemo: boolean = false) {
    this.API_KEY = apiKey;
    this.API_SECRET = apiSecret;
    this.PASSPHRASE = passphrase;
    this.USE_DEMO = useDemo;
  }

  /**
   * Generate signature for API request
   * 
   * @param timestamp - ISO timestamp
   * @param method - HTTP method
   * @param path - Request path
   * @param body - Request body (if any)
   * @returns Promise that resolves to the signature
   */
  private async generateSignature(
    timestamp: string,
    method: string,
    path: string,
    body?: string
  ): Promise<string> {
    const encoder = new TextEncoder();
    const message = `${timestamp}${method}${path}${body || ''}`;
    
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(this.API_SECRET),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    
    const signature = await crypto.subtle.sign(
      'HMAC',
      key,
      encoder.encode(message)
    );
    
    // Convert to base64
    return btoa(String.fromCharCode(...new Uint8Array(signature)));
  }

  /**
   * Make a request to the OKX API
   * 
   * @param method - HTTP method
   * @param path - API endpoint path
   * @param params - Request parameters
   * @param isPrivate - Whether this is a private API request
   * @returns Promise that resolves to the API response
   */
  private async request(
    method: 'GET' | 'POST',
    path: string,
    params: Record<string, any> = {},
    isPrivate: boolean = false
  ): Promise<any> {
    try {
      const url = `${this.BASE_URL}${path}`;
      const timestamp = new Date().toISOString();
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      
      let body: string | null = null;
      
      // Add query parameters for GET requests
      let requestPath = path;
      if (method === 'GET' && Object.keys(params).length > 0) {
        const queryString = Object.entries(params)
          .map(([key, value]) => `${key}=${encodeURIComponent(String(value))}`)
          .join('&');
        requestPath = `${path}?${queryString}`;
      }
      
      // Add body for POST requests
      if (method === 'POST') {
        body = JSON.stringify(params);
      }
      
      // Add authentication headers for private requests
      if (isPrivate) {
        const signature = await this.generateSignature(timestamp, method, requestPath, body || '');
        
        headers['OK-ACCESS-KEY'] = this.API_KEY;
        headers['OK-ACCESS-SIGN'] = signature;
        headers['OK-ACCESS-TIMESTAMP'] = timestamp;
        headers['OK-ACCESS-PASSPHRASE'] = this.PASSPHRASE;
        
        if (this.USE_DEMO) {
          headers['x-simulated-trading'] = '1';
        }
      }
      
      const response = await fetch(url, {
        method,
        headers,
        body: method === 'POST' ? body : null
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OKX API error: ${response.status} ${response.statusText} - ${JSON.stringify(errorData)}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('OKX request error:', error);
      throw error;
    }
  }

  /**
   * Get account balance
   * 
   * @returns Promise that resolves to account balance data
   */
  async getAccountBalance(): Promise<any> {
    return this.request('GET', '/api/v5/account/balance', {}, true);
  }

  /**
   * Get market price for a symbol
   * 
   * @param symbol - Trading symbol (e.g., 'BTC-USDT')
   * @returns Promise that resolves to market price data
   */
  async getMarketPrice(symbol: string): Promise<any> {
    // Convert symbol format from 'BTC/USDT' to 'BTC-USDT'
    const formattedSymbol = symbol.replace('/', '-');
    
    // Get ticker data
    const tickerResponse = await this.request('GET', '/api/v5/market/ticker', {
      instId: formattedSymbol
    });
    
    if (!tickerResponse.data || tickerResponse.data.length === 0) {
      throw new Error(`No ticker data found for ${symbol}`);
    }
    
    const ticker = tickerResponse.data[0];
    
    // Get order book data
    const orderBookResponse = await this.request('GET', '/api/v5/market/books', {
      instId: formattedSymbol,
      sz: 5
    });
    
    if (!orderBookResponse.data || orderBookResponse.data.length === 0) {
      throw new Error(`No order book data found for ${symbol}`);
    }
    
    const orderBook = orderBookResponse.data[0];
    
    return {
      symbol: formattedSymbol,
      price: parseFloat(ticker.last),
      bid: parseFloat(orderBook.bids[0][0]),
      ask: parseFloat(orderBook.asks[0][0]),
      volume: parseFloat(ticker.vol24h),
      timestamp: parseInt(ticker.ts)
    };
  }

  /**
   * Place a limit order
   * 
   * @param symbol - Trading symbol (e.g., 'BTC-USDT')
   * @param side - Order side ('buy' or 'sell')
   * @param size - Order size
   * @param price - Order price
   * @returns Promise that resolves to the order result
   */
  async placeLimitOrder(
    symbol: string,
    side: 'buy' | 'sell',
    size: string,
    price: string
  ): Promise<any> {
    const formattedSymbol = symbol.replace('/', '-');
    
    return this.request('POST', '/api/v5/trade/order', {
      instId: formattedSymbol,
      tdMode: 'cash',
      side,
      ordType: 'limit',
      sz: size,
      px: price
    }, true);
  }

  /**
   * Place a market order
   * 
   * @param symbol - Trading symbol (e.g., 'BTC-USDT')
   * @param side - Order side ('buy' or 'sell')
   * @param size - Order size
   * @returns Promise that resolves to the order result
   */
  async placeMarketOrder(
    symbol: string,
    side: 'buy' | 'sell',
    size: string
  ): Promise<any> {
    const formattedSymbol = symbol.replace('/', '-');
    
    return this.request('POST', '/api/v5/trade/order', {
      instId: formattedSymbol,
      tdMode: 'cash',
      side,
      ordType: 'market',
      sz: size
    }, true);
  }

  /**
   * Get open orders
   * 
   * @param symbol - Optional trading symbol to filter by
   * @returns Promise that resolves to open orders
   */
  async getOpenOrders(symbol?: string): Promise<any> {
    const params: Record<string, any> = {};
    
    if (symbol) {
      params.instId = symbol.replace('/', '-');
    }
    
    return this.request('GET', '/api/v5/trade/orders-pending', params, true);
  }

  /**
   * Cancel an order
   * 
   * @param symbol - Trading symbol
   * @param orderId - Order ID
   * @returns Promise that resolves to the cancellation result
   */
  async cancelOrder(symbol: string, orderId: string): Promise<any> {
    return this.request('POST', '/api/v5/trade/cancel-order', {
      instId: symbol.replace('/', '-'),
      ordId: orderId
    }, true);
  }

  /**
   * Get funding rate for a futures symbol
   * 
   * @param symbol - Futures symbol (e.g., 'BTC-USDT-SWAP')
   * @returns Promise that resolves to funding rate data
   */
  async getFundingRate(symbol: string): Promise<any> {
    // Convert symbol format if needed
    let formattedSymbol = symbol.replace('/', '-');
    if (!formattedSymbol.endsWith('-SWAP')) {
      formattedSymbol = `${formattedSymbol}-SWAP`;
    }
    
    return this.request('GET', '/api/v5/public/funding-rate', {
      instId: formattedSymbol
    });
  }
}