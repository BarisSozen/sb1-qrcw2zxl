/**
 * Deribit Service
 * 
 * This service provides methods for interacting with the Deribit exchange API.
 */
export class DeribitService {
  private readonly BASE_URL = 'https://www.deribit.com/api/v2';
  private readonly API_KEY: string;
  private readonly API_SECRET: string;
  private readonly USE_TESTNET: boolean;
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;

  /**
   * Constructor
   * 
   * @param apiKey - Deribit API key
   * @param apiSecret - Deribit API secret
   * @param useTestnet - Whether to use the testnet (default: false)
   */
  constructor(apiKey: string, apiSecret: string, useTestnet: boolean = false) {
    this.API_KEY = apiKey;
    this.API_SECRET = apiSecret;
    this.USE_TESTNET = useTestnet;
    
    if (this.USE_TESTNET) {
      this.BASE_URL = 'https://test.deribit.com/api/v2';
    }
  }

  /**
   * Get authentication token
   * 
   * @returns Promise that resolves to the authentication token
   */
  private async getAuthToken(): Promise<string> {
    // Check if we have a valid token
    if (this.accessToken && Date.now() < this.tokenExpiry - 60000) {
      return this.accessToken;
    }
    
    try {
      const response = await fetch(`${this.BASE_URL}/public/auth`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          grant_type: 'client_credentials',
          client_id: this.API_KEY,
          client_secret: this.API_SECRET
        })
      });
      
      if (!response.ok) {
        throw new Error(`Deribit authentication error: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      
      if (!data.result || !data.result.access_token) {
        throw new Error('Failed to get Deribit authentication token');
      }
      
      this.accessToken = data.result.access_token;
      this.tokenExpiry = Date.now() + (data.result.expires_in * 1000);
      
      return this.accessToken;
    } catch (error) {
      console.error('Deribit authentication error:', error);
      throw error;
    }
  }

  /**
   * Make a request to the Deribit API
   * 
   * @param method - HTTP method
   * @param endpoint - API endpoint
   * @param params - Request parameters
   * @param isPrivate - Whether this is a private API request
   * @returns Promise that resolves to the API response
   */
  private async request(
    method: 'GET' | 'POST',
    endpoint: string,
    params: Record<string, any> = {},
    isPrivate: boolean = false
  ): Promise<any> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      
      // Add authentication token for private requests
      if (isPrivate) {
        const token = await this.getAuthToken();
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      // Build URL with query parameters for GET requests
      let url = `${this.BASE_URL}${endpoint}`;
      if (method === 'GET' && Object.keys(params).length > 0) {
        const queryString = Object.entries(params)
          .map(([key, value]) => `${key}=${encodeURIComponent(String(value))}`)
          .join('&');
        url = `${url}?${queryString}`;
      }
      
      const response = await fetch(url, {
        method,
        headers,
        body: method === 'POST' ? JSON.stringify(params) : null
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Deribit API error: ${response.status} ${response.statusText} - ${JSON.stringify(errorData)}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Deribit request error:', error);
      throw error;
    }
  }

  /**
   * Get account summary
   * 
   * @param currency - Currency (e.g., 'BTC', 'ETH')
   * @returns Promise that resolves to account summary
   */
  async getAccountBalance(currency: string = 'BTC'): Promise<any> {
    return this.request('GET', '/private/get_account_summary', {
      currency,
      extended: true
    }, true);
  }

  /**
   * Get market price for an instrument
   * 
   * @param instrumentName - Instrument name (e.g., 'BTC-PERPETUAL')
   * @returns Promise that resolves to market price data
   */
  async getMarketPrice(instrumentName: string): Promise<any> {
    // Convert symbol format if needed (e.g., 'BTC/USD' to 'BTC-USD')
    let formattedName = instrumentName.replace('/', '-');
    
    // If not a specific instrument, assume it's a currency and get the perpetual
    if (!formattedName.includes('-')) {
      formattedName = `${formattedName}-PERPETUAL`;
    }
    
    // Get ticker data
    const tickerResponse = await this.request('GET', '/public/ticker', {
      instrument_name: formattedName
    });
    
    if (!tickerResponse.result) {
      throw new Error(`No ticker data found for ${instrumentName}`);
    }
    
    // Get order book data
    const orderBookResponse = await this.request('GET', '/public/get_order_book', {
      instrument_name: formattedName,
      depth: 5
    });
    
    if (!orderBookResponse.result) {
      throw new Error(`No order book data found for ${instrumentName}`);
    }
    
    return {
      instrument: formattedName,
      price: tickerResponse.result.last_price,
      bid: orderBookResponse.result.bids[0][0],
      ask: orderBookResponse.result.asks[0][0],
      volume: tickerResponse.result.stats.volume,
      timestamp: Date.now()
    };
  }

  /**
   * Place a limit order
   * 
   * @param instrumentName - Instrument name (e.g., 'BTC-PERPETUAL')
   * @param side - Order side ('buy' or 'sell')
   * @param amount - Order amount
   * @param price - Order price
   * @returns Promise that resolves to the order result
   */
  async placeLimitOrder(
    instrumentName: string,
    side: 'buy' | 'sell',
    amount: number,
    price: number
  ): Promise<any> {
    const formattedName = instrumentName.replace('/', '-');
    
    return this.request('POST', `/private/${side}`, {
      instrument_name: formattedName,
      amount,
      type: 'limit',
      price,
      post_only: true
    }, true);
  }

  /**
   * Place a market order
   * 
   * @param instrumentName - Instrument name (e.g., 'BTC-PERPETUAL')
   * @param side - Order side ('buy' or 'sell')
   * @param amount - Order amount
   * @returns Promise that resolves to the order result
   */
  async placeMarketOrder(
    instrumentName: string,
    side: 'buy' | 'sell',
    amount: number
  ): Promise<any> {
    const formattedName = instrumentName.replace('/', '-');
    
    return this.request('POST', `/private/${side}`, {
      instrument_name: formattedName,
      amount,
      type: 'market'
    }, true);
  }

  /**
   * Get open orders
   * 
   * @param instrumentName - Optional instrument name to filter by
   * @returns Promise that resolves to open orders
   */
  async getOpenOrders(instrumentName?: string): Promise<any> {
    const params: Record<string, any> = {};
    
    if (instrumentName) {
      params.instrument_name = instrumentName.replace('/', '-');
    }
    
    return this.request('GET', '/private/get_open_orders_by_currency', params, true);
  }

  /**
   * Cancel an order
   * 
   * @param orderId - Order ID
   * @returns Promise that resolves to the cancellation result
   */
  async cancelOrder(orderId: string): Promise<any> {
    return this.request('POST', '/private/cancel', {
      order_id: orderId
    }, true);
  }

  /**
   * Get funding rate for an instrument
   * 
   * @param instrumentName - Instrument name (e.g., 'BTC-PERPETUAL')
   * @returns Promise that resolves to funding rate data
   */
  async getFundingRate(instrumentName: string): Promise<any> {
    const formattedName = instrumentName.replace('/', '-');
    
    return this.request('GET', '/public/get_funding_rate_history', {
      instrument_name: formattedName,
      limit: 1
    });
  }
}