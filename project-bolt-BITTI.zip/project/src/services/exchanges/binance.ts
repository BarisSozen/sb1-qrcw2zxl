/**
 * Binance Service
 * 
 * This service provides methods for interacting with the Binance exchange API.
 */
export class BinanceService {
  private readonly BASE_URL = 'https://api.binance.com';
  private readonly API_KEY: string;
  private readonly API_SECRET: string;
  private readonly USE_TESTNET: boolean;

  /**
   * Constructor
   * 
   * @param apiKey - Binance API key
   * @param apiSecret - Binance API secret
   * @param useTestnet - Whether to use the testnet (default: false)
   */
  constructor(apiKey: string, apiSecret: string, useTestnet: boolean = false) {
    this.API_KEY = apiKey;
    this.API_SECRET = apiSecret;
    this.USE_TESTNET = useTestnet;
    
    if (this.USE_TESTNET) {
      this.BASE_URL = 'https://testnet.binance.vision';
    }
  }

  /**
   * Sign a request with the API secret
   * 
   * @param queryString - Query string to sign
   * @returns Signed query string
   */
  private async signRequest(queryString: string): Promise<string> {
    // In a browser environment, we need to use the Web Crypto API
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(this.API_SECRET),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    
    const signature = await crypto.subtle.sign(
      'HMAC',
      key,
      encoder.encode(queryString)
    );
    
    // Convert the signature to hex
    const signatureArray = Array.from(new Uint8Array(signature));
    const signatureHex = signatureArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    return `${queryString}&signature=${signatureHex}`;
  }

  /**
   * Make a public request to the Binance API
   * 
   * @param endpoint - API endpoint
   * @param params - Query parameters
   * @returns Promise that resolves to the API response
   */
  private async publicRequest(endpoint: string, params: Record<string, string> = {}): Promise<any> {
    try {
      const queryString = Object.entries(params)
        .map(([key, value]) => `${key}=${encodeURIComponent(value)}`)
        .join('&');
      
      const url = `${this.BASE_URL}${endpoint}${queryString ? `?${queryString}` : ''}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Binance API error: ${response.status} ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Binance public request error:', error);
      throw error;
    }
  }

  /**
   * Make a private request to the Binance API
   * 
   * @param endpoint - API endpoint
   * @param method - HTTP method
   * @param params - Query parameters
   * @returns Promise that resolves to the API response
   */
  private async privateRequest(
    endpoint: string,
    method: 'GET' | 'POST' | 'DELETE' = 'GET',
    params: Record<string, string> = {}
  ): Promise<any> {
    try {
      // Add timestamp and receive window
      const timestamp = Date.now().toString();
      const queryParams = {
        ...params,
        timestamp,
        recvWindow: '5000'
      };
      
      // Create query string
      let queryString = Object.entries(queryParams)
        .map(([key, value]) => `${key}=${encodeURIComponent(value)}`)
        .join('&');
      
      // Sign the request
      queryString = await this.signRequest(queryString);
      
      // Build URL
      const url = `${this.BASE_URL}${endpoint}?${queryString}`;
      
      // Make request
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'X-MBX-APIKEY': this.API_KEY
        }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Binance API error: ${response.status} ${response.statusText} - ${JSON.stringify(errorData)}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Binance private request error:', error);
      throw error;
    }
  }

  /**
   * Get account information
   * 
   * @returns Promise that resolves to account information
   */
  async getAccountBalance(): Promise<any> {
    return this.privateRequest('/api/v3/account');
  }

  /**
   * Get futures account information
   * 
   * @returns Promise that resolves to futures account information
   */
  async getFuturesAccountBalance(): Promise<any> {
    return this.privateRequest('/fapi/v2/account');
  }

  /**
   * Get market price for a symbol
   * 
   * @param symbol - Trading symbol (e.g., 'BTCUSDT')
   * @returns Promise that resolves to market price data
   */
  async getMarketPrice(symbol: string): Promise<any> {
    // Convert symbol format if needed (e.g., 'BTC/USDT' to 'BTCUSDT')
    const formattedSymbol = symbol.replace('/', '');
    
    // Get ticker price
    const tickerData = await this.publicRequest('/api/v3/ticker/price', {
      symbol: formattedSymbol
    });
    
    // Get order book for more detailed price info
    const orderBookData = await this.publicRequest('/api/v3/depth', {
      symbol: formattedSymbol,
      limit: '5'
    });
    
    // Get 24hr statistics
    const statsData = await this.publicRequest('/api/v3/ticker/24hr', {
      symbol: formattedSymbol
    });
    
    return {
      symbol: formattedSymbol,
      price: parseFloat(tickerData.price),
      bid: parseFloat(orderBookData.bids[0][0]),
      ask: parseFloat(orderBookData.asks[0][0]),
      volume: parseFloat(statsData.volume),
      timestamp: Date.now()
    };
  }

  /**
   * Place a limit order
   * 
   * @param symbol - Trading symbol (e.g., 'BTCUSDT')
   * @param side - Order side ('BUY' or 'SELL')
   * @param quantity - Order quantity
   * @param price - Order price
   * @returns Promise that resolves to the order result
   */
  async placeLimitOrder(
    symbol: string,
    side: 'BUY' | 'SELL',
    quantity: number,
    price: number
  ): Promise<any> {
    // Convert symbol format if needed
    const formattedSymbol = symbol.replace('/', '');
    
    return this.privateRequest('/api/v3/order', 'POST', {
      symbol: formattedSymbol,
      side,
      type: 'LIMIT',
      timeInForce: 'GTC',
      quantity: quantity.toString(),
      price: price.toString()
    });
  }

  /**
   * Place a market order
   * 
   * @param symbol - Trading symbol (e.g., 'BTCUSDT')
   * @param side - Order side ('BUY' or 'SELL')
   * @param quantity - Order quantity
   * @returns Promise that resolves to the order result
   */
  async placeMarketOrder(
    symbol: string,
    side: 'BUY' | 'SELL',
    quantity: number
  ): Promise<any> {
    // Convert symbol format if needed
    const formattedSymbol = symbol.replace('/', '');
    
    return this.privateRequest('/api/v3/order', 'POST', {
      symbol: formattedSymbol,
      side,
      type: 'MARKET',
      quantity: quantity.toString()
    });
  }

  /**
   * Get open orders
   * 
   * @param symbol - Optional trading symbol to filter by
   * @returns Promise that resolves to open orders
   */
  async getOpenOrders(symbol?: string): Promise<any> {
    const params: Record<string, string> = {};
    
    if (symbol) {
      params.symbol = symbol.replace('/', '');
    }
    
    return this.privateRequest('/api/v3/openOrders', 'GET', params);
  }

  /**
   * Cancel an order
   * 
   * @param symbol - Trading symbol
   * @param orderId - Order ID
   * @returns Promise that resolves to the cancellation result
   */
  async cancelOrder(symbol: string, orderId: string): Promise<any> {
    return this.privateRequest('/api/v3/order', 'DELETE', {
      symbol: symbol.replace('/', ''),
      orderId
    });
  }

  /**
   * Get funding rate for a futures symbol
   * 
   * @param symbol - Futures symbol (e.g., 'BTCUSDT')
   * @returns Promise that resolves to funding rate data
   */
  async getFundingRate(symbol: string): Promise<any> {
    const formattedSymbol = symbol.replace('/', '');
    
    return this.publicRequest('/fapi/v1/fundingRate', {
      symbol: formattedSymbol,
      limit: '1'
    });
  }
}