import { supabase } from '../../lib/supabaseClient';
import { BinanceService } from './binance';
import { BybitService } from './bybit';
import { OKXService } from './okx';
import { DeribitService } from './deribit';
import { UniswapService } from './uniswap';

/**
 * Exchange Service
 * 
 * This service manages connections to different exchanges and provides
 * a unified interface for interacting with them.
 */
export class ExchangeService {
  private exchangeInstances: Map<string, any> = new Map();
  private apiKeys: Map<string, any> = new Map();
  private isInitialized: boolean = false;

  constructor() {}

  /**
   * Initialize exchange connections
   * 
   * Fetches API keys from the database and initializes exchange instances.
   * 
   * @param clientId - Optional client ID to fetch keys for a specific client
   * @returns Promise that resolves when initialization is complete
   */
  async initialize(clientId?: string): Promise<void> {
    try {
      // Fetch API keys from database
      let query = supabase
        .from('exchange_api_keys')
        .select('*')
        .eq('active', true);
      
      if (clientId) {
        query = query.eq('client_id', clientId);
      }
      
      const { data: apiKeys, error } = await query;
      
      if (error) {
        throw new Error(`Failed to fetch API keys: ${error.message}`);
      }
      
      if (!apiKeys || apiKeys.length === 0) {
        console.warn('No active API keys found');
        return;
      }
      
      // Store API keys
      apiKeys.forEach(key => {
        this.apiKeys.set(key.exchange, {
          apiKey: key.api_key,
          apiSecret: key.api_secret,
          passphrase: key.passphrase,
          clientId: key.client_id
        });
      });
      
      // Initialize exchange instances
      await this.initializeExchanges();
      
      this.isInitialized = true;
      console.log('Exchange service initialized successfully');
    } catch (error) {
      console.error('Failed to initialize exchange service:', error);
      throw error;
    }
  }
  
  /**
   * Initialize exchange instances
   * 
   * Creates instances of exchange services for each supported exchange.
   */
  private async initializeExchanges(): Promise<void> {
    try {
      // Initialize Binance
      if (this.apiKeys.has('binance')) {
        const { apiKey, apiSecret } = this.apiKeys.get('binance');
        const binanceService = new BinanceService(apiKey, apiSecret);
        this.exchangeInstances.set('binance', binanceService);
      }
      
      // Initialize Bybit
      if (this.apiKeys.has('bybit')) {
        const { apiKey, apiSecret } = this.apiKeys.get('bybit');
        const bybitService = new BybitService(apiKey, apiSecret);
        this.exchangeInstances.set('bybit', bybitService);
      }
      
      // Initialize OKX (requires passphrase)
      if (this.apiKeys.has('okx')) {
        const { apiKey, apiSecret, passphrase } = this.apiKeys.get('okx');
        if (!passphrase) {
          console.warn('OKX requires a passphrase, but none was provided');
        } else {
          const okxService = new OKXService(apiKey, apiSecret, passphrase);
          this.exchangeInstances.set('okx', okxService);
        }
      }
      
      // Initialize Deribit
      if (this.apiKeys.has('deribit')) {
        const { apiKey, apiSecret } = this.apiKeys.get('deribit');
        const deribitService = new DeribitService(apiKey, apiSecret);
        this.exchangeInstances.set('deribit', deribitService);
      }
      
      // Initialize Uniswap (doesn't require API keys)
      const uniswapService = new UniswapService();
      this.exchangeInstances.set('uniswap', uniswapService);
      
    } catch (error) {
      console.error('Error initializing exchanges:', error);
      throw error;
    }
  }
  
  /**
   * Get exchange instance
   * 
   * Returns the instance for a specific exchange.
   * 
   * @param exchange - Exchange name
   * @returns Exchange instance
   */
  getExchange(exchange: string): any {
    if (!this.isInitialized) {
      throw new Error('Exchange service not initialized. Call initialize() first.');
    }
    
    const instance = this.exchangeInstances.get(exchange.toLowerCase());
    if (!instance) {
      throw new Error(`Exchange ${exchange} not initialized or not supported`);
    }
    
    return instance;
  }
  
  /**
   * Check if an exchange is initialized
   * 
   * @param exchange - Exchange name
   * @returns Boolean indicating if the exchange is initialized
   */
  hasExchange(exchange: string): boolean {
    return this.exchangeInstances.has(exchange.toLowerCase());
  }
  
  /**
   * Get market prices from all initialized exchanges
   * 
   * @param symbol - Trading symbol (e.g., 'BTC/USDT')
   * @returns Promise that resolves to market prices from all exchanges
   */
  async getMarketPrices(symbol: string): Promise<any[]> {
    if (!this.isInitialized) {
      throw new Error('Exchange service not initialized. Call initialize() first.');
    }
    
    const prices: any[] = [];
    
    for (const [exchange, instance] of this.exchangeInstances.entries()) {
      try {
        const price = await instance.getMarketPrice(symbol);
        prices.push({
          exchange,
          symbol,
          ...price
        });
      } catch (error) {
        console.error(`Failed to get market price from ${exchange}:`, error);
      }
    }
    
    return prices;
  }
  
  /**
   * Get account balances from all initialized exchanges
   * 
   * @returns Promise that resolves to account balances from all exchanges
   */
  async getAccountBalances(): Promise<any[]> {
    if (!this.isInitialized) {
      throw new Error('Exchange service not initialized. Call initialize() first.');
    }
    
    const balances: any[] = [];
    
    for (const [exchange, instance] of this.exchangeInstances.entries()) {
      try {
        if (exchange === 'uniswap') continue; // Skip Uniswap as it doesn't have account balances
        
        const balance = await instance.getAccountBalance();
        balances.push({
          exchange,
          ...balance
        });
      } catch (error) {
        console.error(`Failed to get account balance from ${exchange}:`, error);
      }
    }
    
    return balances;
  }
  
  /**
   * Execute a trade on a specific exchange
   * 
   * @param exchange - Exchange name
   * @param symbol - Trading symbol
   * @param side - Trade side ('buy' or 'sell')
   * @param amount - Trade amount
   * @param price - Trade price (optional for market orders)
   * @param orderType - Order type ('limit' or 'market')
   * @returns Promise that resolves to the trade result
   */
  async executeTrade(
    exchange: string,
    symbol: string,
    side: 'buy' | 'sell',
    amount: number,
    price?: number,
    orderType: 'limit' | 'market' = 'limit'
  ): Promise<any> {
    if (!this.isInitialized) {
      throw new Error('Exchange service not initialized. Call initialize() first.');
    }
    
    const instance = this.getExchange(exchange);
    
    try {
      if (orderType === 'limit' && !price) {
        throw new Error('Price is required for limit orders');
      }
      
      if (exchange === 'uniswap') {
        // Special handling for Uniswap
        return await instance.executeTrade(symbol, side, amount);
      } else {
        // Generic handling for CEX exchanges
        return await instance.placeLimitOrder(symbol, side, amount, price);
      }
    } catch (error) {
      console.error(`Failed to execute trade on ${exchange}:`, error);
      throw error;
    }
  }
}