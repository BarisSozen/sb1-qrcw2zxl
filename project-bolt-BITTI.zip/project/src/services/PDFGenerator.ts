import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import fs from 'fs';
import path from 'path';
import { marked } from 'marked';

export class PDFGenerator {
  private doc: jsPDF;

  constructor() {
    this.doc = new jsPDF();
  }

  async generateSystemOverview(): Promise<Buffer> {
    const markdown = fs.readFileSync(path.join(process.cwd(), 'docs', 'SYSTEM_OVERVIEW.md'), 'utf-8');
    const content = marked(markdown);

    this.doc.setFontSize(20);
    this.doc.text('Dow Digital Capital', 105, 20, { align: 'center' });
    this.doc.setFontSize(16);
    this.doc.text('System Overview', 105, 30, { align: 'center' });
    
    this.doc.setFontSize(12);
    let y = 50;

    // Split content into sections
    const sections = content.split('\n## ');
    
    for (const section of sections) {
      if (!section.trim()) continue;

      const [title, ...content] = section.split('\n');
      
      // Add section title
      this.doc.setFontSize(14);
      this.doc.setFont('helvetica', 'bold');
      
      if (y > 250) {
        this.doc.addPage();
        y = 20;
      }
      
      this.doc.text(title.trim(), 20, y);
      y += 10;

      // Add section content
      this.doc.setFontSize(12);
      this.doc.setFont('helvetica', 'normal');
      
      const lines = content.join('\n').split('\n');
      for (const line of lines) {
        if (!line.trim()) continue;

        // Check if new page needed
        if (y > 280) {
          this.doc.addPage();
          y = 20;
        }

        // Handle bullet points
        if (line.startsWith('- ')) {
          this.doc.text('•', 25, y);
          this.doc.text(line.substring(2), 30, y);
        } else if (line.startsWith('### ')) {
          this.doc.setFont('helvetica', 'bold');
          this.doc.text(line.substring(4), 20, y);
          this.doc.setFont('helvetica', 'normal');
        } else {
          this.doc.text(line, 20, y);
        }
        
        y += 7;
      }
      
      y += 10;
    }

    return Buffer.from(this.doc.output('arraybuffer'));
  }
}