export class CircuitBreaker {
  private failures = 0;
  private readonly MAX_FAILURES: number;
  private readonly RESET_TIMEOUT: number;
  private readonly RISK_THRESHOLD: number;
  private lastFailureTime: number = 0;
  private isOpen = false;

  constructor(
    maxFailures: number = 3,
    resetTimeoutMs: number = 60000,
    riskThreshold: number = 0.8
  ) {
    this.MAX_FAILURES = maxFailures;
    this.RESET_TIMEOUT = resetTimeoutMs;
    this.RISK_THRESHOLD = riskThreshold;
  }

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.isOpen) {
      if (Date.now() - this.lastFailureTime >= this.RESET_TIMEOUT) {
        this.reset();
      } else {
        throw new Error('Circuit breaker is open');
      }
    }

    try {
      const result = await operation();
      this.recordSuccess();
      return result;
    } catch (error) {
      await this.recordFailure(error);
      throw error;
    }
  }

  private async recordFailure(error: any): Promise<void> {
    this.failures++;
    this.lastFailureTime = Date.now();

    if (this.failures >= this.MAX_FAILURES) {
      this.isOpen = true;
      console.error('Circuit breaker opened due to too many failures');
    }
  }

  private recordSuccess(): void {
    if (this.failures > 0) {
      this.failures = Math.max(0, this.failures - 1);
    }
  }

  private reset(): void {
    this.failures = 0;
    this.isOpen = false;
    this.lastFailureTime = 0;
  }

  getStatus(): { isOpen: boolean; failures: number; lastFailureTime: number } {
    return {
      isOpen: this.isOpen,
      failures: this.failures,
      lastFailureTime: this.lastFailureTime
    };
  }
}