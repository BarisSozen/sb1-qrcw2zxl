import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabaseClient';

/**
 * Market price interface
 * 
 * Represents a market price data point for a specific token.
 */
export interface MarketPrice {
  token: string;
  spotPrice: number;
  futuresPrice: number;
  fundingRate: number;
  futuresExpiry: number;
  timestamp: number;
  source: string;
  target: string;
  category: 'dex' | 'cex' | 'hybrid';
}

/**
 * Basis opportunity interface
 * 
 * Represents a basis arbitrage opportunity.
 */
export interface BasisOpportunity {
  token: string;
  spotPrice: number;
  futuresPrice: number;
  basisSpread: number;
  annualizedReturn: number;
  daysToExpiry: number;
  requiredCapital: number;
  estimatedProfit: number;
  fundingRate: number;
  timestamp: number;
  source: string;
  target: string;
  category: 'dex' | 'cex' | 'hybrid';
  riskScore: number;
}

/**
 * Trade execution interface
 * 
 * Represents a trade execution record.
 */
export interface TradeExecution {
  opportunity: BasisOpportunity;
  result: {
    success: boolean;
    profit: number;
    commission: number;
    timestamp: number;
    error?: string;
  };
}

/**
 * Custom hook for arbitrage functionality
 * 
 * This hook provides functions to scan for arbitrage opportunities,
 * execute trades, and track trade executions.
 * 
 * @param minAnnualizedReturn - Minimum annualized return threshold (%)
 * @param maxPositionSize - Maximum position size in USD
 * @param leverageMultiple - Leverage multiple to use
 * @returns Object with opportunities, executions, loading state, error, and functions
 */
export function useArbitrage(
  minAnnualizedReturn: number = 5,
  maxPositionSize: number = 100000,
  leverageMultiple: number = 3
) {
  const [opportunities, setOpportunities] = useState<BasisOpportunity[]>([]);
  const [executions, setExecutions] = useState<TradeExecution[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeBots, setActiveBots] = useState<any[]>([]);

  /**
   * Scan for arbitrage opportunities with improved error handling
   */
  const scanForOpportunities = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Generate synthetic data instead of trying to fetch from database
      const prices: MarketPrice[] = generateSyntheticMarketData(activeBots);
      
      // Calculate opportunities
      const calculatedOpportunities = findBasisOpportunities(
        prices,
        minAnnualizedReturn,
        maxPositionSize,
        leverageMultiple
      );
      
      setOpportunities(calculatedOpportunities);
      setError(null);
    } catch (err: any) {
      console.error('Error scanning for opportunities:', err);
      setError(`Failed to scan for opportunities: ${err.message}`);
      setOpportunities([]);
    } finally {
      setIsLoading(false);
    }
  }, [activeBots, minAnnualizedReturn, maxPositionSize, leverageMultiple]);

  /**
   * Execute a trade for a given opportunity
   * 
   * @param opportunity - The opportunity to trade
   * @returns Boolean indicating success
   */
  const executeTrade = async (opportunity: BasisOpportunity): Promise<boolean> => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Simulate trade execution
      const execution: TradeExecution = {
        opportunity,
        result: {
          success: true,
          profit: opportunity.estimatedProfit,
          commission: opportunity.estimatedProfit * 0.2, // 20% commission
          timestamp: Date.now()
        }
      };
      
      setExecutions(prev => [...prev, execution]);
      
      // Remove executed opportunity from the list
      setOpportunities(prev => prev.filter(op => 
        op.token !== opportunity.token || 
        op.source !== opportunity.source || 
        op.target !== opportunity.target
      ));
      
      return true;
    } catch (err: any) {
      console.error('Error executing trade:', err);
      setError(`Failed to execute trade: ${err.message}`);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // Initial scan for opportunities
  useEffect(() => {
    scanForOpportunities();
    
    // Set up interval to scan periodically
    const interval = setInterval(scanForOpportunities, 30000);
    return () => clearInterval(interval);
  }, [scanForOpportunities]);

  return {
    opportunities,
    executions,
    isLoading,
    error,
    scanForOpportunities,
    executeTrade
  };
}

/**
 * Generate synthetic market data based on active bots
 * 
 * Used when no real market data is available in the database.
 * 
 * @param activeBots - Array of active bot configurations
 * @returns Array of synthetic market price data
 */
function generateSyntheticMarketData(activeBots: any[]): MarketPrice[] {
  const prices: MarketPrice[] = [];
  const now = Date.now();
  
  // Extract unique pairs and exchanges from active bots
  const pairs = new Set<string>();
  const exchanges = new Set<string>();
  
  activeBots.forEach(bot => {
    bot.pairs?.forEach((pair: string) => pairs.add(pair));
    bot.exchanges?.forEach((exchange: string) => exchanges.add(exchange));
  });
  
  // If no bots, use default values
  const defaultPairs = ['BTC/USD', 'ETH/USD', 'SOL/USD'];
  const defaultExchanges = ['binance', 'bybit', 'okx', 'deribit', 'uniswap'];
  
  const pairsArray = pairs.size > 0 ? Array.from(pairs) : defaultPairs;
  const exchangesArray = exchanges.size > 0 ? Array.from(exchanges) : defaultExchanges;
  
  // Generate prices for each pair across exchanges
  pairsArray.forEach(pair => {
    const token = pair.split('/')[0];
    let baseSpotPrice = 0;
    
    // Set base price based on token
    if (token === 'BTC') baseSpotPrice = 35000 + (Math.random() * 2000);
    else if (token === 'ETH') baseSpotPrice = 2000 + (Math.random() * 200);
    else if (token === 'SOL') baseSpotPrice = 100 + (Math.random() * 10);
    else baseSpotPrice = 1 + (Math.random() * 10);
    
    // Generate prices for CEX exchanges
    exchangesArray.filter(e => e !== 'uniswap').forEach(exchange => {
      // Add small variation for each exchange
      const spotPrice = baseSpotPrice * (1 + (Math.random() * 0.02 - 0.01)); // ±1%
      const futuresPrice = spotPrice * (1 + (Math.random() * 0.05)); // 0-5% premium
      const fundingRate = Math.random() * 0.0005; // 0-0.05% funding rate
      
      prices.push({
        token,
        spotPrice,
        futuresPrice,
        fundingRate,
        futuresExpiry: now + (90 * 24 * 60 * 60 * 1000), // 90 days
        timestamp: now,
        source: exchange,
        target: exchange,
        category: 'cex'
      });
    });
    
    // Add some DEX opportunities
    if (['ETH', 'SOL'].includes(token)) {
      const dexSpotPrice = baseSpotPrice * (1 + (Math.random() * 0.03 - 0.015)); // ±1.5%
      prices.push({
        token,
        spotPrice: dexSpotPrice,
        futuresPrice: dexSpotPrice * (1 + (Math.random() * 0.04)), // 0-4% premium
        fundingRate: 0,
        futuresExpiry: now + (30 * 24 * 60 * 60 * 1000), // 30 days
        timestamp: now,
        source: 'uniswap',
        target: 'dydx',
        category: 'dex'
      });
    }
  });
  
  return prices;
}

/**
 * Find basis arbitrage opportunities in market data
 * 
 * Analyzes market price data to identify profitable basis arbitrage opportunities.
 * 
 * @param prices - Array of market price data
 * @param minAnnualizedReturn - Minimum annualized return threshold (%)
 * @param maxPositionSize - Maximum position size in USD
 * @param leverageMultiple - Leverage multiple to use
 * @returns Array of basis arbitrage opportunities
 */
function findBasisOpportunities(
  prices: MarketPrice[],
  minAnnualizedReturn: number,
  maxPositionSize: number,
  leverageMultiple: number
): BasisOpportunity[] {
  const opportunities: BasisOpportunity[] = [];
  const tokens = new Set(prices.map(p => p.token));
  
  tokens.forEach(token => {
    const tokenPrices = prices.filter(p => p.token === token);
    
    // Group prices by category (DEX vs CEX)
    const dexPrices = tokenPrices.filter(p => p.category === 'dex');
    const cexPrices = tokenPrices.filter(p => p.category === 'cex');
    
    // Find min spot price and max futures price
    const minSpotPrice = Math.min(...tokenPrices.map(p => p.spotPrice));
    const maxFuturesPrice = Math.max(...tokenPrices.map(p => p.futuresPrice));
    
    const minSpotExchange = tokenPrices.find(p => p.spotPrice === minSpotPrice)?.source || '';
    const maxFuturesExchange = tokenPrices.find(p => p.futuresPrice === maxFuturesPrice)?.source || '';
    
    // Skip if same exchange (can't arbitrage on same exchange)
    if (minSpotExchange === maxFuturesExchange && minSpotExchange !== 'uniswap') return;
    
    const basisSpread = ((maxFuturesPrice - minSpotPrice) / minSpotPrice) * 100;
    const futuresExpiry = tokenPrices.find(p => p.futuresPrice === maxFuturesPrice)?.futuresExpiry || 0;
    const daysToExpiry = (futuresExpiry - Date.now()) / (1000 * 60 * 60 * 24);
    
    const annualizedReturn = (basisSpread / daysToExpiry) * 365;
    
    // Only include if meets minimum return
    if (annualizedReturn > minAnnualizedReturn) {
      // Calculate optimal position size
      const positionSize = Math.min(
        maxPositionSize,
        maxPositionSize * (annualizedReturn / (minAnnualizedReturn * 2)) // Scale by return
      );
      
      const estimatedProfit = (positionSize * basisSpread) / 100;
      
      // Determine category based on exchanges
      let category: 'dex' | 'cex' | 'hybrid';
      if (minSpotExchange === 'uniswap' || maxFuturesExchange === 'uniswap') {
        category = 'dex';
      } else if (minSpotExchange.includes('dex') || maxFuturesExchange.includes('dex')) {
        category = 'hybrid';
      } else {
        category = 'cex';
      }
      
      // Calculate risk score (0-1)
      const riskScore = calculateRiskScore(
        basisSpread,
        daysToExpiry,
        minSpotExchange,
        maxFuturesExchange,
        token
      );
      
      opportunities.push({
        token,
        spotPrice: minSpotPrice,
        futuresPrice: maxFuturesPrice,
        basisSpread,
        annualizedReturn,
        daysToExpiry,
        requiredCapital: positionSize,
        estimatedProfit,
        fundingRate: tokenPrices.find(p => p.futuresPrice === maxFuturesPrice)?.fundingRate || 0,
        timestamp: Date.now(),
        source: minSpotExchange,
        target: maxFuturesExchange,
        category,
        riskScore
      });
    }
  });
  
  // Sort by risk-adjusted return (annualizedReturn / riskScore)
  return opportunities.sort((a, b) => 
    (b.annualizedReturn / b.riskScore) - (a.annualizedReturn / a.riskScore)
  );
}

/**
 * Calculate risk score for an opportunity
 * 
 * Evaluates various risk factors to produce a risk score between 0 and 1.
 * 
 * @param basisSpread - Basis spread percentage
 * @param daysToExpiry - Days until futures contract expiry
 * @param spotExchange - Spot exchange name
 * @param futuresExchange - Futures exchange name
 * @param token - Token symbol
 * @returns Risk score between 0 and 1 (higher = riskier)
 */
function calculateRiskScore(
  basisSpread: number,
  daysToExpiry: number,
  spotExchange: string,
  futuresExchange: string,
  token: string
): number {
  let riskScore = 0;
  
  // Higher spread = higher risk
  riskScore += Math.min(basisSpread / 20, 0.3); // Max 0.3 from spread
  
  // Longer expiry = higher risk
  riskScore += Math.min(daysToExpiry / 180, 0.3); // Max 0.3 from expiry
  
  // DEX risk premium
  if (spotExchange === 'uniswap' || futuresExchange === 'uniswap') {
    riskScore += 0.2;
  }
  
  // Token risk (BTC lowest, others higher)
  if (token === 'BTC') riskScore += 0.05;
  else if (token === 'ETH') riskScore += 0.1;
  else riskScore += 0.15;
  
  return Math.min(riskScore, 0.95); // Cap at 0.95
}