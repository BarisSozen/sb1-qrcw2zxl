import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

/**
 * Bot metrics interface
 * 
 * Defines the structure of bot performance metrics data returned from the database.
 */
export interface BotMetrics {
  id: string;
  bot_id: string;
  timestamp: string;
  period: 'hourly' | 'daily' | 'weekly' | 'monthly';
  sharpe_ratio: number;
  sortino_ratio: number;
  max_drawdown: number;
  avg_drawdown: number;
  volatility: number;
  var_95: number;
  success_rate: number;
  uptime_percent: number;
  avg_latency: number;
  execution_speed: number;
  order_fill_rate: number;
  avg_slippage: number;
  profit_factor: number;
  recovery_factor: number;
  cost_efficiency: number;
  return_on_capital: number;
  win_rate: number;
  profit_per_trade: number;
  win_loss_ratio: number;
  strategy_allocation: Record<string, number>;
}

/**
 * Custom hook for fetching and subscribing to bot metrics
 * 
 * This hook fetches bot metrics from the database and sets up a real-time
 * subscription to receive updates when metrics change.
 * 
 * @param botId - The ID of the bot to fetch metrics for
 * @param period - The time period for metrics (hourly, daily, weekly, monthly)
 * @returns Object containing metrics data, loading state, and any error
 */
export function useBotMetrics(botId: string, period: 'hourly' | 'daily' | 'weekly' | 'monthly' = 'daily') {
  const [metrics, setMetrics] = useState<BotMetrics[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Function to fetch metrics from the database
    const fetchMetrics = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Query the database for bot metrics
        const { data, error: fetchError } = await supabase
          .from('bot_metrics')
          .select('*')
          .eq('bot_id', botId)
          .eq('period', period)
          .order('timestamp', { ascending: false })
          .limit(30); // Last 30 data points

        if (fetchError) throw fetchError;
        
        // If no data is returned, generate sample data for demonstration
        if (!data || data.length === 0) {
          const sampleData = generateSampleMetrics(botId, period);
          setMetrics(sampleData);
        } else {
          setMetrics(data);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch bot metrics');
        console.error('Error fetching bot metrics:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMetrics();

    // Set up real-time subscription to bot metrics
    const subscription = supabase
      .channel('bot-metrics-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'bot_metrics',
        filter: `bot_id=eq.${botId} AND period=eq.${period}`
      }, fetchMetrics)
      .subscribe();

    // Clean up subscription when component unmounts
    return () => {
      subscription.unsubscribe();
    };
  }, [botId, period]);

  return {
    metrics,
    isLoading,
    error
  };
}

/**
 * Generate sample metrics data for demonstration purposes
 * 
 * This function creates realistic sample data when no real data is available.
 * It's useful for development, testing, and demonstration.
 * 
 * @param botId - The ID of the bot to generate metrics for
 * @param period - The time period for metrics
 * @returns Array of sample bot metrics
 */
function generateSampleMetrics(botId: string, period: 'hourly' | 'daily' | 'weekly' | 'monthly'): BotMetrics[] {
  const metrics: BotMetrics[] = [];
  const now = new Date();
  
  // Generate 30 data points
  for (let i = 0; i < 30; i++) {
    // Calculate timestamp based on period
    let timestamp: Date;
    switch (period) {
      case 'hourly':
        timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
        break;
      case 'daily':
        timestamp = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        break;
      case 'weekly':
        timestamp = new Date(now.getTime() - i * 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        timestamp = new Date(now.getTime() - i * 30 * 24 * 60 * 60 * 1000);
        break;
    }
    
    // Add some randomness to make the data look realistic
    const baseValue = Math.random() * 0.5 + 0.5; // 0.5 to 1.0
    const trend = Math.sin(i / 5) * 0.2; // Sinusoidal trend
    const noise = (Math.random() - 0.5) * 0.1; // Random noise
    
    metrics.push({
      id: `sample-${i}`,
      bot_id: botId,
      timestamp: timestamp.toISOString(),
      period,
      sharpe_ratio: 1.5 + baseValue + trend + noise,
      sortino_ratio: 2.0 + baseValue + trend + noise,
      max_drawdown: 5.0 + (1 - baseValue) * 10 + noise * 5,
      avg_drawdown: 3.0 + (1 - baseValue) * 5 + noise * 3,
      volatility: 10.0 + (1 - baseValue) * 10 + noise * 5,
      var_95: 5.0 + (1 - baseValue) * 5 + noise * 2,
      success_rate: 75.0 + baseValue * 20 + trend * 5,
      uptime_percent: 98.0 + baseValue * 2,
      avg_latency: 30.0 + (1 - baseValue) * 50 + noise * 10,
      execution_speed: 0.1 + baseValue * 0.2 + noise * 0.05,
      order_fill_rate: 95.0 + baseValue * 5,
      avg_slippage: 0.01 + (1 - baseValue) * 0.1 + noise * 0.02,
      profit_factor: 1.5 + baseValue * 1.5 + trend * 0.5,
      recovery_factor: 2.0 + baseValue * 2 + trend * 0.5,
      cost_efficiency: 80.0 + baseValue * 15 + trend * 5,
      return_on_capital: 10.0 + baseValue * 20 + trend * 10,
      win_rate: 60.0 + baseValue * 25 + trend * 5,
      profit_per_trade: 100.0 + baseValue * 200 + trend * 50,
      win_loss_ratio: 1.5 + baseValue * 1.5 + trend * 0.5,
      strategy_allocation: {
        'Market Neutral': 0.3,
        'Funding Rate Arbitrage': 0.3,
        'Basis Trading': 0.2,
        'Statistical Arbitrage': 0.2
      }
    });
  }
  
  return metrics;
}