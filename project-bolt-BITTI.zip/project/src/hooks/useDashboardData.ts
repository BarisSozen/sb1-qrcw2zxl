import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabaseClient';

/**
 * Dashboard statistics interface
 * 
 * Defines the structure of dashboard statistics data.
 */
export interface DashboardStats {
  totalTrades: number;
  totalPnl: number;
  winRate: number;
  activeBots: number;
  openPositions: number;
  totalInvested: number;
  currentBalance: number;
  bestPerformingPair: string;
  bestPerformingBot: string;
  maxDrawdown: number;
  avgDrawdown: number;
  recoveryTime: number;
  calmarRatio: number;
  avgProfitPerTrade: number;
  winLossRatio: number;
}

/**
 * Bot type performance interface
 * 
 * Defines the structure of performance data for each bot type.
 */
export interface BotTypePerformance {
  type: string;
  name: string;
  annualYield: number;
  monthlyYield: number;
  weeklyYield: number;
  dailyYield: number;
  totalTrades: number;
  activeBots: number;
}

/**
 * Yield data point interface
 * 
 * Defines the structure of yield data points for charts.
 */
export interface YieldDataPoint {
  date: string;
  dexYield: number;
  cexYield: number;
  hybridYield: number;
  compound: number;
  statisticalYield: number;
  triangularYield?: number;
}

/**
 * Drawdown point interface
 * 
 * Defines the structure of drawdown data points for charts.
 */
export interface DrawdownPoint {
  timestamp: string;
  drawdown: number;
}

/**
 * Custom hook for fetching dashboard data
 * 
 * This hook fetches and processes all data needed for the dashboard,
 * including statistics, performance metrics, yield data, and drawdown history.
 * 
 * @param timeframe - The time period for data (e.g., '7d', '30d', '90d', '1y')
 * @returns Object containing all dashboard data, loading state, and any error
 */
export function useDashboardData(timeframe: string = '30d') {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [botTypePerformance, setBotTypePerformance] = useState<BotTypePerformance[]>([]);
  const [yieldData, setYieldData] = useState<YieldDataPoint[]>([]);
  const [drawdownHistory, setDrawdownHistory] = useState<DrawdownPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboardData = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Generate sample data instead of trying to fetch from Supabase
      // This ensures the dashboard works even without a database connection
      
      // Set sample stats
      setStats(generateSampleStats());
      
      // Set sample bot performance data
      setBotTypePerformance(generateSampleBotPerformance());
      
      // Generate yield data points
      setYieldData(generateYieldData());
      
      // Generate drawdown history
      setDrawdownHistory(generateSampleDrawdownHistory());

    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError('Failed to load dashboard data. Please try again later.');
      
      // Set fallback data
      setStats(generateSampleStats());
      setBotTypePerformance(generateSampleBotPerformance());
      setYieldData(generateYieldData());
      setDrawdownHistory(generateSampleDrawdownHistory());
    } finally {
      setIsLoading(false);
    }
  }, [timeframe]);

  useEffect(() => {
    fetchDashboardData();
    
    // Refresh data every 5 minutes
    const interval = setInterval(fetchDashboardData, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [fetchDashboardData]);

  return {
    stats,
    botTypePerformance,
    yieldData,
    drawdownHistory,
    isLoading,
    error,
    refreshData: fetchDashboardData
  };
}

/**
 * Calculate drawdown metrics from trade data
 * 
 * This function analyzes trade data to calculate maximum drawdown,
 * average drawdown, and recovery time.
 * 
 * @param trades - Array of trade data
 * @returns Object containing drawdown metrics
 */
function calculateDrawdownMetrics(trades: any[]) {
  if (!trades.length) {
    return { maxDrawdown: 0, avgDrawdown: 0, recoveryTime: 0 };
  }

  let peak = 0;
  let maxDrawdown = 0;
  let currentDrawdown = 0;
  let totalDrawdown = 0;
  let drawdownCount = 0;
  let recoveryTime = 0;
  let lastDrawdownStart = 0;

  // Calculate equity curve from trades
  const equity = trades.reduce((acc, trade) => {
    const balance = acc[acc.length - 1] + (trade.pnl || 0);
    acc.push(balance);
    return acc;
  }, [0]);

  // Analyze equity curve for drawdowns
  equity.forEach((balance, i) => {
    if (balance > peak) {
      peak = balance;
      if (currentDrawdown > 0) {
        // Recovery completed
        recoveryTime += i - lastDrawdownStart;
        drawdownCount++;
      }
      currentDrawdown = 0;
    } else {
      const drawdown = peak > 0 ? (peak - balance) / peak : 0;
      if (drawdown > currentDrawdown) {
        if (currentDrawdown === 0) {
          lastDrawdownStart = i;
        }
        currentDrawdown = drawdown;
        totalDrawdown += drawdown;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
    }
  });

  return {
    maxDrawdown: maxDrawdown * 100,
    avgDrawdown: drawdownCount > 0 ? (totalDrawdown / drawdownCount) * 100 : 0,
    recoveryTime: drawdownCount > 0 ? recoveryTime / drawdownCount : 0
  };
}

/**
 * Convert timeframe string to number of days
 * 
 * @param timeframe - Timeframe string (e.g., '7d', '30d')
 * @returns Number of days in the timeframe
 */
function timeframeDays(timeframe: string): number {
  switch (timeframe) {
    case '7d': return 7;
    case '30d': return 30;
    case '90d': return 90;
    case '1y': return 365;
    default: return 30;
  }
}

/**
 * Generate sample statistics for demonstration
 * 
 * @returns Sample dashboard statistics
 */
function generateSampleStats(): DashboardStats {
  return {
    totalTrades: 1250,
    totalPnl: 125000,
    winRate: 68.5,
    activeBots: 12,
    openPositions: 8,
    totalInvested: 500000,
    currentBalance: 625000,
    bestPerformingPair: 'ETH/USD',
    bestPerformingBot: 'Basis Arbitrage Alpha',
    maxDrawdown: 12.5,
    avgDrawdown: 5.8,
    recoveryTime: 3.2,
    calmarRatio: 2.4,
    avgProfitPerTrade: 100,
    winLossRatio: 2.17
  };
}

/**
 * Generate sample bot performance data
 * 
 * @returns Array of sample bot type performance data
 */
function generateSampleBotPerformance(): BotTypePerformance[] {
  return [
    {
      type: 'basis',
      name: 'Basis Arbitrage',
      annualYield: 24.5,
      monthlyYield: 24.5 / 12,
      weeklyYield: 24.5 / 52,
      dailyYield: 24.5 / 365,
      totalTrades: 450,
      activeBots: 4
    },
    {
      type: 'perpetual',
      name: 'Perpetual Arbitrage',
      annualYield: 22.8,
      monthlyYield: 22.8 / 12,
      weeklyYield: 22.8 / 52,
      dailyYield: 22.8 / 365,
      totalTrades: 380,
      activeBots: 3
    },
    {
      type: 'dex',
      name: 'DEX Arbitrage',
      annualYield: 26.2,
      monthlyYield: 26.2 / 12,
      weeklyYield: 26.2 / 52,
      dailyYield: 26.2 / 365,
      totalTrades: 320,
      activeBots: 2
    },
    {
      type: 'statistical',
      name: 'Statistical Arbitrage',
      annualYield: 21.5,
      monthlyYield: 21.5 / 12,
      weeklyYield: 21.5 / 52,
      dailyYield: 21.5 / 365,
      totalTrades: 280,
      activeBots: 2
    },
    {
      type: 'triangular',
      name: 'Triangular Arbitrage',
      annualYield: 23.7,
      monthlyYield: 23.7 / 12,
      weeklyYield: 23.7 / 52,
      dailyYield: 23.7 / 365,
      totalTrades: 420,
      activeBots: 1
    }
  ];
}

/**
 * Generate sample yield data for charts
 * 
 * @returns Array of yield data points
 */
function generateYieldData(): YieldDataPoint[] {
  const yieldPoints: YieldDataPoint[] = [];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  
  for (let i = 0; i < months.length; i++) {
    // Base values with small random variations and upward trend
    const dexYield = 4.0 + (i * 0.2) + (Math.random() * 0.5);
    const cexYield = 3.5 + (i * 0.15) + (Math.random() * 0.5);
    const hybridYield = 5.0 + (i * 0.2) + (Math.random() * 0.5);
    const statisticalYield = 4.5 + (i * 0.25) + (Math.random() * 0.5);
    const triangularYield = 4.8 + (i * 0.22) + (Math.random() * 0.5);
    
    // Compound is slightly higher than the average
    const compound = (dexYield + cexYield + hybridYield + statisticalYield + triangularYield) / 5 * 1.1;
    
    yieldPoints.push({
      date: `2025-${String(i + 1).padStart(2, '0')}`,
      dexYield,
      cexYield,
      hybridYield,
      compound,
      statisticalYield,
      triangularYield
    });
  }
  
  return yieldPoints;
}

/**
 * Generate sample drawdown history for charts
 * 
 * @returns Array of drawdown data points
 */
function generateSampleDrawdownHistory(): DrawdownPoint[] {
  const points: DrawdownPoint[] = [];
  const now = Date.now();
  
  // Generate 30 days of drawdown data
  for (let i = 30; i >= 0; i--) {
    // Create a realistic drawdown pattern
    // Start with low drawdown, increase to a peak, then recover
    let drawdown;
    if (i > 25) {
      drawdown = 2 + Math.random() * 2; // 2-4%
    } else if (i > 20) {
      drawdown = 4 + Math.random() * 3; // 4-7%
    } else if (i > 15) {
      drawdown = 7 + Math.random() * 5; // 7-12%
    } else if (i > 10) {
      drawdown = 5 + Math.random() * 3; // 5-8%
    } else if (i > 5) {
      drawdown = 3 + Math.random() * 2; // 3-5%
    } else {
      drawdown = 1 + Math.random() * 2; // 1-3%
    }
    
    points.push({
      timestamp: new Date(now - i * 24 * 60 * 60 * 1000).toISOString(),
      drawdown
    });
  }
  
  return points;
}