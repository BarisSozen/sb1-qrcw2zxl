import { useState, useEffect } from 'react';
import { supabase, queryWithFallback, generateMockData } from '../lib/supabaseClient';

interface SystemStatus {
  riskLevel: 'low' | 'medium' | 'high';
  lastUpdate: number;
}

interface SecurityMetrics {
  failedValidations24h: number;
  failedValidationsChange: number;
  suspiciousActivities24h: number;
  suspiciousActivitiesChange: number;
  trend: Array<{
    date: string;
    failedValidations: number;
    suspiciousActivities: number;
    riskScore: number;
  }>;
}

interface SecurityIncident {
  timestamp: number;
  type: string;
  description: string;
  riskLevel: 'low' | 'medium' | 'high';
  status: 'active' | 'resolved';
}

export function useSecurityReport() {
  const [isKillSwitchActive, setIsKillSwitchActive] = useState(false);
  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    riskLevel: 'low',
    lastUpdate: Date.now()
  });

  const [securityMetrics, setSecurityMetrics] = useState<SecurityMetrics>({
    failedValidations24h: 0,
    failedValidationsChange: 0,
    suspiciousActivities24h: 0,
    suspiciousActivitiesChange: 0,
    trend: []
  });

  const [recentIncidents, setRecentIncidents] = useState<SecurityIncident[]>([]);

  useEffect(() => {
    const fetchSecurityData = async () => {
      try {
        // Fetch recent incidents with fallback
        const incidentsData = await queryWithFallback(
          supabase
            .from('security_incidents')
            .select('*')
            .order('timestamp', { ascending: false })
            .limit(10),
          [{
            timestamp: Date.now() - 1000 * 60 * 30,
            type: 'Validation Failure',
            description: 'Multiple failed trade validations from address 0x1234',
            risk_level: 'medium',
            status: 'resolved'
          },
          {
            timestamp: Date.now() - 1000 * 60 * 45,
            type: 'Suspicious Activity',
            description: 'Rapid successive trades detected',
            risk_level: 'high',
            status: 'active'
          },
          {
            timestamp: Date.now() - 1000 * 60 * 120,
            type: 'API Key Misuse',
            description: 'Unusual API usage pattern detected',
            risk_level: 'medium',
            status: 'active'
          }],
          'Error fetching security incidents'
        );

        // Transform to our format
        const incidents: SecurityIncident[] = incidentsData.map(incident => ({
          timestamp: new Date(incident.timestamp).getTime(),
          type: incident.type,
          description: incident.description,
          riskLevel: incident.risk_level,
          status: incident.status
        }));

        setRecentIncidents(incidents);

        // Fetch security metrics with fallback
        const metricsData = await queryWithFallback(
          supabase
            .from('security_metrics')
            .select('*')
            .order('timestamp', { ascending: false })
            .limit(1),
          [generateMockData.securityMetrics()],
          'Error fetching security metrics'
        );

        const currentMetrics = metricsData[0];

        // Fetch historical metrics for trend with fallback
        const trendData = await queryWithFallback(
          supabase
            .from('security_metrics_history')
            .select('*')
            .order('timestamp', { ascending: true })
            .limit(7),
          Array.from({ length: 7 }, (_, i) => ({
            timestamp: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toISOString(),
            failed_validations: Math.floor(Math.random() * 20),
            suspicious_activities: Math.floor(Math.random() * 5),
            risk_score: 0.2 + Math.random() * 0.3
          })),
          'Error fetching security metrics history'
        );

        // Calculate change percentages
        const previousDay = trendData.at(-2);
        const failedValidationsChange = previousDay && previousDay.failed_validations > 0
          ? ((currentMetrics.failed_validations - previousDay.failed_validations) / previousDay.failed_validations) * 100
          : 0;
        
        const suspiciousActivitiesChange = previousDay && previousDay.suspicious_activities > 0
          ? ((currentMetrics.suspicious_activities - previousDay.suspicious_activities) / previousDay.suspicious_activities) * 100
          : 0;

        // Determine system risk level
        let riskLevel: 'low' | 'medium' | 'high' = 'low';
        if (currentMetrics.risk_score > 0.7) riskLevel = 'high';
        else if (currentMetrics.risk_score > 0.4) riskLevel = 'medium';

        setSystemStatus({
          riskLevel,
          lastUpdate: new Date(currentMetrics.timestamp).getTime()
        });

        setSecurityMetrics({
          failedValidations24h: currentMetrics.failed_validations,
          failedValidationsChange,
          suspiciousActivities24h: currentMetrics.suspicious_activities,
          suspiciousActivitiesChange,
          trend: trendData.map(item => ({
            date: new Date(item.timestamp).toLocaleDateString(),
            failedValidations: item.failed_validations,
            suspiciousActivities: item.suspicious_activities,
            riskScore: item.risk_score
          }))
        });

        setIsKillSwitchActive(currentMetrics.kill_switch_active);

      } catch (error) {
        console.warn('Error in security data processing:', error);
        
        // Set fallback data if there's an error
        setRecentIncidents([
          {
            timestamp: Date.now() - 1000 * 60 * 30,
            type: 'Validation Failure',
            description: 'Multiple failed trade validations from address 0x1234',
            riskLevel: 'medium',
            status: 'resolved'
          },
          {
            timestamp: Date.now() - 1000 * 60 * 45,
            type: 'Suspicious Activity',
            description: 'Rapid successive trades detected',
            riskLevel: 'high',
            status: 'active'
          }
        ]);
        
        setSecurityMetrics({
          failedValidations24h: 12,
          failedValidationsChange: -5,
          suspiciousActivities24h: 3,
          suspiciousActivitiesChange: +15,
          trend: Array.from({ length: 7 }, (_, i) => ({
            date: new Date(Date.now() - i * 24 * 60 * 60 * 1000).toLocaleDateString(),
            failedValidations: Math.floor(Math.random() * 20),
            suspiciousActivities: Math.floor(Math.random() * 5),
            riskScore: 0.2 + Math.random() * 0.3
          }))
        });
      }
    };

    fetchSecurityData();
    const interval = setInterval(fetchSecurityData, 60000);
    return () => clearInterval(interval);
  }, []);

  const toggleKillSwitch = async () => {
    try {
      const newStatus = !isKillSwitchActive;
      setIsKillSwitchActive(newStatus);
      
      // Try to update in database, but don't fail if it doesn't work
      try {
        await supabase
          .from('security_settings')
          .upsert([{
            id: 'global',
            kill_switch_active: newStatus,
            updated_at: new Date().toISOString(),
            updated_by: 'system'
          }]);
        
        await supabase
          .from('security_incidents')
          .insert([{
            type: newStatus ? 'Kill Switch Activation' : 'Kill Switch Deactivation',
            description: newStatus ? 'Trading system halted by user' : 'Trading system resumed by user',
            risk_level: newStatus ? 'high' : 'low',
            status: 'active'
          }]);
        
        if (newStatus) {
          await supabase
            .from('bot_configs')
            .update({ status: 'stopped' })
            .eq('status', 'running');
        }
      } catch (dbError) {
        console.warn('Database update failed, but UI state was updated:', dbError);
      }
    } catch (error) {
      console.warn('Error toggling kill switch:', error);
      setIsKillSwitchActive(!newStatus);
    }
  };

  return {
    systemStatus,
    securityMetrics,
    recentIncidents,
    isKillSwitchActive,
    toggleKillSwitch
  };
}