import { useState, useEffect } from 'react';
import { supabase, queryWithFallback, generateMockData } from '../lib/supabaseClient';
import { ExchangeService } from '../services/exchanges/ExchangeService';

interface ExchangeStatus {
  exchange: string;
  connected: boolean;
  error?: string;
  lastChecked: Date;
}

export function useExchangeConnection(clientId?: string) {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exchangeStatuses, setExchangeStatuses] = useState<ExchangeStatus[]>([]);
  const [exchangeService, setExchangeService] = useState<ExchangeService | null>(null);

  useEffect(() => {
    const initializeExchanges = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const service = new ExchangeService();
        await service.initialize(clientId);
        setExchangeService(service);
        
        await checkAllConnections(service);
      } catch (err) {
        console.warn('Error initializing exchanges:', err);
        setError(err instanceof Error ? err.message : 'Failed to initialize exchanges');
      } finally {
        setIsLoading(false);
      }
    };
    
    initializeExchanges();
  }, [clientId]);

  const checkAllConnections = async (service: ExchangeService) => {
    try {
      // Get all active API keys with fallback data
      const apiKeys = await queryWithFallback(
        supabase
          .from('exchange_api_keys')
          .select('exchange, active')
          .eq('active', true),
        generateMockData.exchangeApiKeys(),
        'Error fetching API keys'
      );
      
      const exchanges = [
        ...new Set([
          ...apiKeys.map(key => key.exchange),
          'binance',
          'bybit',
          'okx',
          'deribit',
          'uniswap'
        ])
      ];
      
      const statuses: ExchangeStatus[] = [];
      
      for (const exchange of exchanges) {
        try {
          const connected = service.hasExchange(exchange);
          
          if (exchange === 'uniswap') {
            statuses.push({
              exchange,
              connected: true,
              lastChecked: new Date()
            });
            continue;
          }
          
          const hasActiveKey = apiKeys.some(key => 
            key.exchange === exchange && key.active
          );
          
          statuses.push({
            exchange,
            connected: connected && hasActiveKey,
            error: !hasActiveKey ? 'No active API key' : undefined,
            lastChecked: new Date()
          });
        } catch (err) {
          statuses.push({
            exchange,
            connected: false,
            error: err instanceof Error ? err.message : 'Connection failed',
            lastChecked: new Date()
          });
        }
      }
      
      setExchangeStatuses(statuses);
    } catch (err) {
      console.warn('Error checking exchange connections:', err);
      setError(err instanceof Error ? err.message : 'Failed to check exchange connections');
    }
  };

  const testConnection = async (exchange: string): Promise<boolean> => {
    if (!exchangeService) {
      throw new Error('Exchange service not initialized');
    }
    
    try {
      if (exchange === 'uniswap') {
        const uniswap = exchangeService.getExchange('uniswap');
        await uniswap.getMarketPrice('ETH/USDC');
        
        setExchangeStatuses(prev => prev.map(status => 
          status.exchange === exchange
            ? { ...status, connected: true, error: undefined, lastChecked: new Date() }
            : status
        ));
        
        return true;
      }
      
      if (!exchangeService.hasExchange(exchange)) {
        throw new Error(`Exchange ${exchange} not initialized`);
      }
      
      const instance = exchangeService.getExchange(exchange);
      await instance.getAccountBalance();
      
      setExchangeStatuses(prev => prev.map(status => 
        status.exchange === exchange
          ? { ...status, connected: true, error: undefined, lastChecked: new Date() }
          : status
      ));
      
      return true;
    } catch (err) {
      console.warn(`Error testing connection to ${exchange}:`, err);
      
      setExchangeStatuses(prev => prev.map(status => 
        status.exchange === exchange
          ? { 
              ...status, 
              connected: false, 
              error: err instanceof Error ? err.message : 'Connection failed', 
              lastChecked: new Date() 
            }
          : status
      ));
      
      return false;
    }
  };

  const getMarketPrices = async (symbol: string) => {
    if (!exchangeService) {
      throw new Error('Exchange service not initialized');
    }
    
    try {
      return await exchangeService.getMarketPrices(symbol);
    } catch (err) {
      console.warn('Error getting market prices:', err);
      throw err;
    }
  };

  return {
    isLoading,
    error,
    exchangeStatuses,
    testConnection,
    getMarketPrices,
    exchangeService
  };
}