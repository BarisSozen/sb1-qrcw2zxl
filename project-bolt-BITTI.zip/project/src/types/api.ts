/**
 * API type definitions
 * 
 * This file contains TypeScript type definitions for API-related data structures.
 * These types are used for API requests, responses, and data models.
 */

/**
 * API Key interface
 * 
 * Represents an exchange API key stored in the system.
 */
export interface ApiKey {
  id: string;
  exchange: 'binance' | 'bybit' | 'okx' | 'deribit';
  apiKey: string;
  apiSecret: string;
  passphrase?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

/**
 * Client interface
 * 
 * Represents a client entity in the system.
 */
export interface Client {
  id: string;
  name: string;
  email: string;
  walletAddress?: string;
  active: boolean;
  commissionRate: number;
  totalInvested: number;
  currentBalance: number;
  createdAt: string;
  clientType: 'standard' | 'audit';
  salesRepId?: string;
  preferredBotTypes?: string[];
}

/**
 * Trade interface
 * 
 * Represents a trade executed by the system.
 */
export interface Trade {
  id: string;
  clientId: string;
  exchange: string;
  pair: string;
  side: 'buy' | 'sell';
  amount: number;
  price: number;
  profit: number;
  timestamp: string;
  status: 'open' | 'closed' | 'error';
  botId?: string;
  tradeType?: 'spot' | 'perpetual' | 'basis' | 'statistical' | 'triangular';
}

/**
 * Commission interface
 * 
 * Represents a commission record for a trade.
 */
export interface Commission {
  id: string;
  clientId: string;
  amount: number;
  tradeId: string;
  paid: boolean;
  createdAt: string;
}

/**
 * SalesRep interface
 * 
 * Represents a sales representative in the system.
 */
export interface SalesRep {
  id: string;
  name: string;
  email: string;
  active: boolean;
  defaultCommissionRate: number;
  totalCommissionEarned: number;
  paymentDetails?: {
    bankAccount?: string;
    paymentMethod?: string;
    [key: string]: any;
  };
}

/**
 * RiskMetrics interface
 * 
 * Represents risk metrics for a bot or client.
 */
export interface RiskMetrics {
  positionConcentration: number;
  crossExchangeExposure: number;
  avgLeverageRatio: number;
  marginUtilization: number;
  liquidationRisk: number;
  slippageImpact: number;
  orderFillRate: number;
  executionLatency: number;
}