/**
 * Market data type definitions
 * 
 * This file contains TypeScript type definitions for market data structures
 * used throughout the application.
 */

/**
 * Market price interface
 * 
 * Represents a market price data point for a specific token on a specific exchange.
 * Includes spot and futures prices, funding rates, and other market data.
 */
export interface MarketPrice {
  token: string;           // Token symbol (e.g., 'BTC', 'ETH')
  spotPrice: number;       // Current spot price
  futuresPrice: number;    // Current futures price
  fundingRate: number;     // Current funding rate (for perpetual contracts)
  futuresExpiry: number;   // Timestamp of futures contract expiry
  timestamp: number;       // Timestamp when this price was recorded
  source: string;          // Source exchange (e.g., 'binance', 'uniswap')
  target: string;          // Target exchange or currency (e.g., 'USD')
  category: 'dex' | 'cex' | 'hybrid'; // Exchange category
  volume?: number;         // 24h trading volume (optional)
  liquidity?: number;      // Available liquidity (optional)
  volatility?: number;     // Price volatility (optional)
}

/**
 * Market depth interface
 * 
 * Represents market depth data for a trading pair.
 */
export interface MarketDepth {
  bids: [number, number][]; // Array of [price, quantity] pairs for buy orders
  asks: [number, number][]; // Array of [price, quantity] pairs for sell orders
  timestamp: number;        // Timestamp when this depth was recorded
  exchange: string;         // Source exchange
  pair: string;             // Trading pair (e.g., 'BTC/USD')
}

/**
 * Funding rate interface
 * 
 * Represents funding rate data for perpetual contracts.
 */
export interface FundingRate {
  token: string;           // Token symbol
  exchange: string;        // Exchange name
  rate: number;            // Current funding rate
  nextPayment: number;     // Timestamp of next funding payment
  predicted: number;       // Predicted next funding rate
  timestamp: number;       // Timestamp when this data was recorded
}

/**
 * Liquidity pool interface
 * 
 * Represents data for a DEX liquidity pool.
 */
export interface LiquidityPool {
  exchange: string;        // DEX name (e.g., 'uniswap', 'sushiswap')
  address: string;         // Pool contract address
  token0: string;          // First token in the pair
  token1: string;          // Second token in the pair
  reserve0: number;        // Reserve amount of token0
  reserve1: number;        // Reserve amount of token1
  fee: number;             // Pool fee percentage
  tvl: number;             // Total value locked in USD
  timestamp: number;       // Timestamp when this data was recorded
}

/**
 * Market summary interface
 * 
 * Represents a summary of market conditions for a token.
 */
export interface MarketSummary {
  token: string;
  spotPrice: number;
  spotPriceChange24h: number;
  volume24h: number;
  marketCap: number;
  availableExchanges: string[];
  volatility24h: number;
  timestamp: number;
}