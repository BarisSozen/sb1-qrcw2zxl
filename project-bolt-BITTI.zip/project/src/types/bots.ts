/**
 * Bot type definitions
 * 
 * This file contains TypeScript type definitions for the trading bots in the system.
 * It defines the supported bot types, statuses, and configuration parameters.
 */

// Supported bot types in the system
export type BotType = 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular';

// Possible bot operational statuses
export type BotStatus = 'running' | 'stopped' | 'error';

/**
 * Bot configuration interface
 * 
 * Defines the structure of a bot configuration object, including all parameters
 * needed to initialize and run a trading bot.
 */
export interface BotConfig {
  id: string;
  type: BotType;
  name: string;
  description?: string;
  active: boolean;
  status: BotStatus;
  interval?: number;
  minProfitThreshold: number;
  maxPositionSize: number;
  leverageLimit: number;
  exchanges: string[];
  pairs: string[];
  maxGasPrice?: number;  // For DEX and triangular bots (in GWEI)
  maxSlippage?: number;  // For DEX and triangular bots (as decimal, e.g., 0.01 = 1%)
}

/**
 * Bot statistics interface
 * 
 * Defines the structure for bot performance statistics.
 */
export interface BotStats {
  totalTrades: number;
  successfulTrades: number;
  failedTrades: number;
  totalProfit: number;
  winRate: number;
  averageProfit: number;
  lastTradeTime?: string;
  uptime: number;
  clientId?: string;
}