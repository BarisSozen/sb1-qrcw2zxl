export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      bot_configs: {
        Row: {
          id: string
          type: 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular'
          name: string
          description: string | null
          active: boolean | null
          status: 'running' | 'stopped' | 'error'
          interval: number | null
          min_profit_threshold: number
          max_position_size: number
          leverage_limit: number
          exchanges: string[]
          pairs: string[]
          created_at: string | null
          updated_at: string | null
          client_id: string | null
          subaccount_id: string | null
          wallet_address: string | null
          last_error_at: string | null
          error_count: number | null
          max_gas_price: number | null
          max_slippage: number | null
        }
        Insert: {
          id?: string
          type: 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular'
          name: string
          description?: string | null
          active?: boolean | null
          status?: 'running' | 'stopped' | 'error'
          interval?: number | null
          min_profit_threshold?: number
          max_position_size?: number
          leverage_limit?: number
          exchanges: string[]
          pairs: string[]
          created_at?: string | null
          updated_at?: string | null
          client_id?: string | null
          subaccount_id?: string | null
          wallet_address?: string | null
          last_error_at?: string | null
          error_count?: number | null
          max_gas_price?: number | null
          max_slippage?: number | null
        }
        Update: {
          id?: string
          type?: 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular'
          name?: string
          description?: string | null
          active?: boolean | null
          status?: 'running' | 'stopped' | 'error'
          interval?: number | null
          min_profit_threshold?: number
          max_position_size?: number
          leverage_limit?: number
          exchanges?: string[]
          pairs?: string[]
          created_at?: string | null
          updated_at?: string | null
          client_id?: string | null
          subaccount_id?: string | null
          wallet_address?: string | null
          last_error_at?: string | null
          error_count?: number | null
          max_gas_price?: number | null
          max_slippage?: number | null
        }
      }
      bot_metrics: {
        Row: {
          id: string
          bot_id: string | null
          timestamp: string | null
          period: string
          sharpe_ratio: number | null
          sortino_ratio: number | null
          max_drawdown: number | null
          avg_drawdown: number | null
          volatility: number | null
          var_95: number | null
          success_rate: number | null
          uptime_percent: number | null
          avg_latency: number | null
          execution_speed: number | null
          order_fill_rate: number | null
          avg_slippage: number | null
          profit_factor: number | null
          recovery_factor: number | null
          cost_efficiency: number | null
          return_on_capital: number | null
          win_rate: number | null
          profit_per_trade: number | null
          win_loss_ratio: number | null
          strategy_allocation: Record<string, number> | null
        }
        Insert: {
          id?: string
          bot_id?: string | null
          timestamp?: string | null
          period: string
          sharpe_ratio?: number | null
          sortino_ratio?: number | null
          max_drawdown?: number | null
          avg_drawdown?: number | null
          volatility?: number | null
          var_95?: number | null
          success_rate?: number | null
          uptime_percent?: number | null
          avg_latency?: number | null
          execution_speed?: number | null
          order_fill_rate?: number | null
          avg_slippage?: number | null
          profit_factor?: number | null
          recovery_factor?: number | null
          cost_efficiency?: number | null
          return_on_capital?: number | null
          win_rate?: number | null
          profit_per_trade?: number | null
          win_loss_ratio?: number | null
          strategy_allocation?: Record<string, number> | null
        }
        Update: {
          id?: string
          bot_id?: string | null
          timestamp?: string | null
          period?: string
          sharpe_ratio?: number | null
          sortino_ratio?: number | null
          max_drawdown?: number | null
          avg_drawdown?: number | null
          volatility?: number | null
          var_95?: number | null
          success_rate?: number | null
          uptime_percent?: number | null
          avg_latency?: number | null
          execution_speed?: number | null
          order_fill_rate?: number | null
          avg_slippage?: number | null
          profit_factor?: number | null
          recovery_factor?: number | null
          cost_efficiency?: number | null
          return_on_capital?: number | null
          win_rate?: number | null
          profit_per_trade?: number | null
          win_loss_ratio?: number | null
          strategy_allocation?: Record<string, number> | null
        }
      }
      bot_trades: {
        Row: {
          id: string
          bot_id: string | null
          client_id: string | null
          trade_type: string
          entry_price: number
          exit_price: number | null
          quantity: number
          pnl: number | null
          fees: number | null
          slippage: number | null
          execution_time: number | null
          status: string
          entry_timestamp: string | null
          exit_timestamp: string | null
          strategy: string
          exchange: string
          pair: string
          error_details: Json | null
        }
        Insert: {
          id?: string
          bot_id?: string | null
          client_id?: string | null
          trade_type: string
          entry_price: number
          exit_price?: number | null
          quantity: number
          pnl?: number | null
          fees?: number | null
          slippage?: number | null
          execution_time?: number | null
          status: string
          entry_timestamp?: string | null
          exit_timestamp?: string | null
          strategy: string
          exchange: string
          pair: string
          error_details?: Json | null
        }
        Update: {
          id?: string
          bot_id?: string | null
          client_id?: string | null
          trade_type?: string
          entry_price?: number
          exit_price?: number | null
          quantity?: number
          pnl?: number | null
          fees?: number | null
          slippage?: number | null
          execution_time?: number | null
          status?: string
          entry_timestamp?: string | null
          exit_timestamp?: string | null
          strategy?: string
          exchange?: string
          pair?: string
          error_details?: Json | null
        }
      }
      clients: {
        Row: {
          id: string
          name: string
          email: string
          wallet_address: string | null
          created_at: string | null
          active: boolean | null
          commission_rate: number
          total_invested: number | null
          current_balance: number | null
          sales_rep_id: string | null
          preferred_bot_types: string[]
          client_type: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          wallet_address?: string | null
          created_at?: string | null
          active?: boolean | null
          commission_rate?: number
          total_invested?: number | null
          current_balance?: number | null
          sales_rep_id?: string | null
          preferred_bot_types?: string[]
          client_type?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          wallet_address?: string | null
          created_at?: string | null
          active?: boolean | null
          commission_rate?: number
          total_invested?: number | null
          current_balance?: number | null
          sales_rep_id?: string | null
          preferred_bot_types?: string[]
          client_type?: string
        }
      }
      market_prices: {
        Row: {
          id: string
          token: string
          spot_price: number
          futures_price: number
          funding_rate: number | null
          futures_expiry: string | null
          timestamp: string | null
          source: string
          target: string
          category: string
        }
        Insert: {
          id?: string
          token: string
          spot_price: number
          futures_price: number
          funding_rate?: number | null
          futures_expiry?: string | null
          timestamp?: string | null
          source: string
          target: string
          category: string
        }
        Update: {
          id?: string
          token?: string
          spot_price?: number
          futures_price?: number
          funding_rate?: number | null
          futures_expiry?: string | null
          timestamp?: string | null
          source?: string
          target?: string
          category?: string
        }
      }
      bot_assignments: {
        Row: {
          id: string
          bot_id: string | null
          client_id: string | null
          assigned_at: string | null
          unassigned_at: string | null
          assigned_by: string | null
          status: string
          notes: string | null
        }
        Insert: {
          id?: string
          bot_id?: string | null
          client_id?: string | null
          assigned_at?: string | null
          unassigned_at?: string | null
          assigned_by?: string | null
          status: string
          notes?: string | null
        }
        Update: {
          id?: string
          bot_id?: string | null
          client_id?: string | null
          assigned_at?: string | null
          unassigned_at?: string | null
          assigned_by?: string | null
          status?: string
          notes?: string | null
        }
      }
    }
    Views: {
      active_bot_assignments: {
        Row: {
          bot_id: string | null
          bot_name: string | null
          bot_type: string | null
          bot_status: string | null
          client_id: string | null
          client_name: string | null
          client_email: string | null
          assigned_at: string | null
          assigned_by: string | null
        }
        Insert: {
          bot_id?: string | null
          bot_name?: string | null
          bot_type?: string | null
          bot_status?: string | null
          client_id?: string | null
          client_name?: string | null
          client_email?: string | null
          assigned_at?: string | null
          assigned_by?: string | null
        }
        Update: {
          bot_id?: string | null
          bot_name?: string | null
          bot_type?: string | null
          bot_status?: string | null
          client_id?: string | null
          client_name?: string | null
          client_email?: string | null
          assigned_at?: string | null
          assigned_by?: string | null
        }
      }
      bot_performance_stats: {
        Row: {
          bot_id: string | null
          total_trades: number | null
          winning_trades: number | null
          losing_trades: number | null
          total_pnl: number | null
          avg_pnl_per_trade: number | null
          avg_execution_time: number | null
          avg_slippage: number | null
          win_loss_ratio: number | null
          win_rate: number | null
        }
      }
    }
  }
}