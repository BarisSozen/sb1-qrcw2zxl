/*
  # Add Error Logging Tables

  1. New Tables
    - `error_logs` - Stores detailed error information
    - Add error tracking fields to existing tables

  2. Security
    - Enable RLS on new tables
    - Add policies for authenticated users
*/

-- Create error_logs table
CREATE TABLE IF NOT EXISTS error_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timestamp timestamptz DEFAULT now(),
  level text NOT NULL CHECK (level IN ('error', 'warn', 'info')),
  message text NOT NULL,
  stack text,
  context jsonb NOT NULL DEFAULT '{}',
  resolved boolean DEFAULT false,
  resolved_at timestamptz,
  resolved_by uuid REFERENCES auth.users(id),
  resolution text,
  created_at timestamptz DEFAULT now()
);

-- Add error tracking fields to bot_configs
ALTER TABLE bot_configs
ADD COLUMN IF NOT EXISTS last_error_at timestamptz,
ADD COLUMN IF NOT EXISTS error_count integer DEFAULT 0;

-- Add error tracking fields to bot_trades
ALTER TABLE bot_trades
ADD COLUMN IF NOT EXISTS error_details jsonb;

-- Enable RLS
ALTER TABLE error_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated users can view error logs"
  ON error_logs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert error logs"
  ON error_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update error logs"
  ON error_logs
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_error_logs_timestamp ON error_logs(timestamp);
CREATE INDEX idx_error_logs_level ON error_logs(level);
CREATE INDEX idx_error_logs_resolved ON error_logs(resolved);