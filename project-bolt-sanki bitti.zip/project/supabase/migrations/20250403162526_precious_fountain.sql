/*
  # Add Triangular Arbitrage Bot Type

  1. Changes
    - Update bot_configs type check constraint to include 'triangular' type
    - Add new columns for triangular arbitrage specific settings
*/

-- Update bot type check constraint to include 'triangular'
ALTER TABLE bot_configs
DROP CONSTRAINT IF EXISTS bot_configs_type_check;

ALTER TABLE bot_configs
ADD CONSTRAINT bot_configs_type_check 
CHECK (type = ANY (ARRAY['basis'::text, 'perpetual'::text, 'dex'::text, 'statistical'::text, 'triangular'::text]));

-- Add columns for triangular arbitrage specific settings
ALTER TABLE bot_configs
ADD COLUMN IF NOT EXISTS max_gas_price integer,
ADD COLUMN IF NOT EXISTS max_slippage numeric;

-- Add index for the new bot type
CREATE INDEX IF NOT EXISTS idx_bot_configs_triangular ON bot_configs(type) WHERE type = 'triangular';