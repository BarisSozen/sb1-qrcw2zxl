import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/database';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Missing environment variables: VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY must be defined'
  );
}

// Validate URL format
try {
  new URL(supabaseUrl);
} catch (error) {
  throw new Error(
    'Invalid VITE_SUPABASE_URL format. Must be a valid URL (e.g., https://your-project.supabase.co)'
  );
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  },
  global: {
    headers: {
      'x-application-name': 'crypto-arbitrage-platform'
    }
  },
  db: {
    schema: 'public'
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// Add error handling for failed requests
supabase.handleFailedRequest = async (error: any) => {
  console.error('Supabase request failed:', error);
  
  // Check if error is due to network connectivity
  if (!navigator.onLine) {
    throw new Error('No internet connection. Please check your network and try again.');
  }

  // Check if error is due to authentication
  if (error.status === 401 || error.status === 403) {
    throw new Error('Authentication error. Please sign in again.');
  }

  // Generic error message
  throw new Error('Failed to connect to database. Please try again later.');
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) {
    console.error('Error signing out:', error.message);
    throw error;
  }
  window.location.href = '/';
};

export type { Database };