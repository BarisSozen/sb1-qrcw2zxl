import { createPublicClient, http, createWalletClient, custom } from 'viem';
import { mainnet } from 'viem/chains';
import { bundlerActions, createBundlerClient } from 'permissionless';
import { pimlicoBundlerActions, createPimlicoBundlerClient } from 'permissionless/clients/pimlico';
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts';
import { UserOperation } from 'permissionless';

export class AccountAbstraction {
  private publicClient;
  private bundlerClient;
  private walletClient;
  private entryPoint = '0x5FF137D4b0FDCD49DcA30c7CF57E578a026d2789';

  constructor(rpcUrl: string, bundlerUrl: string) {
    this.publicClient = createPublicClient({
      chain: mainnet,
      transport: http(rpcUrl)
    });

    this.bundlerClient = createPimlicoBundlerClient({
      transport: http(bundlerUrl),
      entryPoint: this.entryPoint
    });

    // Initialize wallet client with window.ethereum if available
    if (typeof window !== 'undefined' && window.ethereum) {
      this.walletClient = createWalletClient({
        chain: mainnet,
        transport: custom(window.ethereum)
      });
    }
  }

  async createAccount() {
    const privateKey = generatePrivateKey();
    const account = privateKeyToAccount(privateKey);
    return { account, privateKey };
  }

  async createUserOperation(params: {
    sender: string;
    target: string;
    data: string;
    value?: bigint;
    maxFeePerGas?: bigint;
    maxPriorityFeePerGas?: bigint;
    callGasLimit?: bigint;
    verificationGasLimit?: bigint;
    preVerificationGas?: bigint;
  }): Promise<UserOperation> {
    const nonce = await this.bundlerClient.getUserOperationNonce({
      sender: params.sender,
      entryPoint: this.entryPoint
    });

    const gasPrice = await this.publicClient.getGasPrice();
    const chainId = await this.publicClient.getChainId();

    const userOperation: UserOperation = {
      sender: params.sender,
      nonce,
      initCode: '0x',
      callData: params.data,
      callGasLimit: params.callGasLimit || 100000n,
      verificationGasLimit: params.verificationGasLimit || 100000n,
      preVerificationGas: params.preVerificationGas || 50000n,
      maxFeePerGas: params.maxFeePerGas || gasPrice,
      maxPriorityFeePerGas: params.maxPriorityFeePerGas || gasPrice,
      paymasterAndData: '0x',
      signature: '0x'
    };

    return userOperation;
  }

  async sendUserOperation(userOperation: UserOperation): Promise<string> {
    try {
      // Submit the user operation to the bundler
      const userOpHash = await this.bundlerClient.sendUserOperation({
        userOperation,
        entryPoint: this.entryPoint
      });

      // Wait for the user operation to be included
      const receipt = await this.bundlerClient.waitForUserOperationReceipt({
        hash: userOpHash
      });

      return receipt.receipt.transactionHash;
    } catch (error) {
      console.error('Error sending user operation:', error);
      throw error;
    }
  }

  async estimateUserOperationGas(userOperation: UserOperation) {
    try {
      const gasEstimates = await this.bundlerClient.estimateUserOperationGas({
        userOperation,
        entryPoint: this.entryPoint
      });

      return {
        callGasLimit: gasEstimates.callGasLimit,
        verificationGasLimit: gasEstimates.verificationGasLimit,
        preVerificationGas: gasEstimates.preVerificationGas
      };
    } catch (error) {
      console.error('Error estimating gas:', error);
      throw error;
    }
  }

  async getUserOperationStatus(userOpHash: string): Promise<'success' | 'failed' | 'pending'> {
    try {
      const receipt = await this.bundlerClient.getUserOperationReceipt({
        hash: userOpHash
      });

      if (!receipt) return 'pending';
      return receipt.success ? 'success' : 'failed';
    } catch (error) {
      console.error('Error getting user operation status:', error);
      throw error;
    }
  }

  async getUserOperationByHash(userOpHash: string) {
    try {
      const userOp = await this.bundlerClient.getUserOperationByHash({
        hash: userOpHash
      });
      return userOp;
    } catch (error) {
      console.error('Error getting user operation:', error);
      throw error;
    }
  }
}