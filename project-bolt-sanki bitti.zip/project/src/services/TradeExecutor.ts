import { AccountAbstraction } from './AccountAbstraction';
import { ethers } from 'ethers';
import { supabase } from '../lib/supabaseClient';

interface TradeParams {
  token: string;
  amount: string;
  price: string;
  side: 'buy' | 'sell';
  exchange: string;
  userAddress: string;
}

export class TradeExecutor {
  private aa: AccountAbstraction;
  private exchangeContracts: Map<string, string> = new Map([
    ['uniswap', '0x...'], // Add actual exchange contract addresses
    ['sushiswap', '0x...'],
    ['curve', '0x...']
  ]);

  constructor(rpcUrl: string, bundlerUrl: string) {
    this.aa = new AccountAbstraction(rpcUrl, bundlerUrl);
  }

  async executeTrade(params: TradeParams) {
    try {
      // Get exchange contract address
      const exchangeAddress = this.exchangeContracts.get(params.exchange);
      if (!exchangeAddress) {
        throw new Error(`Unsupported exchange: ${params.exchange}`);
      }

      // Encode trade function call
      const data = this.encodeTrade(params);

      // Create user operation
      const userOp = await this.aa.createUserOperation({
        sender: params.userAddress,
        target: exchangeAddress,
        data: data,
        value: ethers.parseEther('0')
      });

      // Estimate gas
      const gasEstimates = await this.aa.estimateUserOperationGas(userOp);
      Object.assign(userOp, gasEstimates);

      // Send user operation
      const userOpHash = await this.aa.sendUserOperation(userOp);

      // Store trade details
      await this.storeTrade({
        userOpHash,
        ...params,
        status: 'pending'
      });

      // Monitor trade status
      this.monitorTrade(userOpHash);

      return userOpHash;
    } catch (error) {
      console.error('Error executing trade:', error);
      throw error;
    }
  }

  private encodeTrade(params: TradeParams): string {
    // Encode trade function call based on exchange
    const amount = ethers.parseUnits(params.amount, 18);
    const price = ethers.parseUnits(params.price, 18);

    // Example encoding for a swap function
    const iface = new ethers.Interface([
      'function swap(address token, uint256 amount, uint256 price, bool isBuy) returns (bool)'
    ]);

    return iface.encodeFunctionData('swap', [
      params.token,
      amount,
      price,
      params.side === 'buy'
    ]);
  }

  private async storeTrade(tradeDetails: any) {
    try {
      const { error } = await supabase
        .from('bot_trades')
        .insert([{
          ...tradeDetails,
          trade_type: 'dex',
          execution_time: Date.now()
        }]);

      if (error) throw error;
    } catch (error) {
      console.error('Error storing trade:', error);
    }
  }

  private async monitorTrade(userOpHash: string) {
    const checkStatus = async () => {
      try {
        const status = await this.aa.getUserOperationStatus(userOpHash);
        
        if (status !== 'pending') {
          // Update trade status in database
          const { error } = await supabase
            .from('bot_trades')
            .update({ status: status === 'success' ? 'closed' : 'error' })
            .eq('user_op_hash', userOpHash);

          if (error) throw error;
          return;
        }

        // Check again in 5 seconds
        setTimeout(checkStatus, 5000);
      } catch (error) {
        console.error('Error monitoring trade:', error);
      }
    };

    // Start monitoring
    checkStatus();
  }
}