import { ErrorLoggingService } from './ErrorLoggingService';
import { supabase } from '../lib/supabaseClient';

export class ErrorReportingService {
  private static instance: ErrorReportingService;
  private errorLogger: ErrorLoggingService;
  private intervals: number[] = [];
  private isRunning = false;

  private constructor() {
    this.errorLogger = ErrorLoggingService.getInstance();
    this.startCronJobs();
  }

  public static getInstance(): ErrorReportingService {
    if (!ErrorReportingService.instance) {
      ErrorReportingService.instance = new ErrorReportingService();
    }
    return ErrorReportingService.instance;
  }

  public startCronJobs() {
    if (this.isRunning) return;
    this.isRunning = true;

    // Generate monthly report on the 1st of each month
    this.intervals.push(window.setInterval(() => {
      const now = new Date();
      if (now.getDate() === 1 && now.getHours() === 0 && now.getMinutes() === 0) {
        this.generateMonthlyReport().catch(console.error);
      }
    }, 60000)); // Check every minute

    // Check for unresolved errors daily
    this.intervals.push(window.setInterval(() => {
      const now = new Date();
      if (now.getHours() === 0 && now.getMinutes() === 0) {
        this.checkUnresolvedErrors().catch(console.error);
      }
    }, 60000)); // Check every minute
  }

  public stopCronJobs() {
    this.intervals.forEach(interval => window.clearInterval(interval));
    this.intervals = [];
    this.isRunning = false;
  }

  public async generateManualReport(): Promise<void> {
    try {
      const report = await this.errorLogger.generateMonthlyReport();
      await this.saveMonthlyReport(report, 'manual');
      await this.checkUnresolvedErrors();
    } catch (error) {
      console.error('Failed to generate manual report:', error);
      throw error;
    }
  }

  private async generateMonthlyReport(): Promise<void> {
    try {
      const report = await this.errorLogger.generateMonthlyReport();
      await this.saveMonthlyReport(report, 'monthly');
    } catch (error) {
      console.error('Failed to generate monthly report:', error);
    }
  }

  private async saveMonthlyReport(report: string, type: 'monthly' | 'manual' = 'monthly') {
    try {
      const { error } = await supabase
        .from('error_reports')
        .insert([{
          report_type: type,
          content: report,
          generated_at: new Date().toISOString()
        }]);

      if (error) throw error;
    } catch (error) {
      console.error('Failed to save report:', error);
      throw error;
    }
  }

  private async checkUnresolvedErrors() {
    try {
      const { data: errors, error } = await supabase
        .from('error_logs')
        .select('*')
        .eq('resolved', false)
        .order('timestamp', { ascending: false });

      if (error) throw error;

      if (errors && errors.length > 0) {
        // Group errors by type and severity
        const groupedErrors = this.groupUnresolvedErrors(errors);

        // Create incident report
        await supabase
          .from('security_incidents')
          .insert([{
            type: 'Unresolved Errors',
            description: `${errors.length} unresolved errors found`,
            risk_level: errors.length > 10 ? 'high' : errors.length > 5 ? 'medium' : 'low',
            status: 'active',
            details: groupedErrors
          }]);
      }
    } catch (error) {
      console.error('Failed to check unresolved errors:', error);
      throw error;
    }
  }

  private groupUnresolvedErrors(errors: any[]) {
    return errors.reduce((groups: Record<string, any[]>, error) => {
      const type = error.context?.type || 'unknown';
      if (!groups[type]) {
        groups[type] = [];
      }
      groups[type].push({
        message: error.message,
        timestamp: error.timestamp,
        context: error.context
      });
      return groups;
    }, {});
  }
}