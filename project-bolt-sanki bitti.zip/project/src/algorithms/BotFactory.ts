import { BotConfig } from './types';
import { BasisArbitrageBot } from './bots/BasisArbitrageBot';
import { PerpetualArbitrageBot } from './bots/PerpetualArbitrageBot';
import { DexArbitrageBot } from './bots/DexArbitrageBot';
import { StatisticalArbitrageBot } from './bots/StatisticalArbitrageBot';
import { TriangularArbitrageBot } from './bots/TriangularArbitrageBot';

export class BotFactory {
  static createBot(config: BotConfig) {
    switch (config.type) {
      case 'basis':
        return new BasisArbitrageBot(config);
      case 'perpetual':
        return new PerpetualArbitrageBot(config);
      case 'dex':
        return new DexArbitrageBot(config);
      case 'statistical':
        return new StatisticalArbitrageBot(config);
      case 'triangular':
        return new TriangularArbitrageBot(config);
      default:
        throw new Error(`Unknown bot type: ${config.type}`);
    }
  }
}