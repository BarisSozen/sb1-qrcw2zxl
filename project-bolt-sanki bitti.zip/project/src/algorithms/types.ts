// Add these types to the existing types.ts file

export interface OpportunityAnalysis {
  currentPosition: {
    annualizedReturn: number;
    holdingPeriod: number;
    costs: {
      execution: number;
      funding: number;
      total: number;
    };
  };
  newOpportunity: {
    estimatedReturn: number;
    estimatedCosts: {
      execution: number;
      funding: number;
      slippage: number;
      total: number;
    };
    riskAdjustedReturn: number;
  };
  improvement: {
    gross: number;
    net: number;
    percentageImprovement: number;
  };
  recommendation: {
    shouldRotate: boolean;
    reason: string;
    confidence: number;
  };
}

export interface MarketConditions {
  volatility: number;
  volume: number;
  liquidity: number;
  spreadWidth: number;
  fundingRate: number;
  timestamp: number;
}