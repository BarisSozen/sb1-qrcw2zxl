import { 
  TradingBot, 
  BotConfig, 
  TradeOpportunity, 
  TradeResult, 
  RiskAssessment, 
  PositionSize 
} from './types';
import { MarketPrice } from '../types/market';
import { supabase } from '../lib/supabaseClient';
import { CircuitBreaker } from '../services/CircuitBreaker';
import { OpportunityOptimizer } from './OpportunityOptimizer';

export abstract class AbstractBot implements TradingBot {
  id: string;
  name: string;
  type: 'basis' | 'perpetual' | 'dex' | 'statistical';
  status: 'running' | 'stopped' | 'error' = 'stopped';
  minProfitThreshold: number;
  maxPositionSize: number;
  leverageLimit: number;
  exchanges: string[];
  pairs: string[];
  protected interval: NodeJS.Timer | null = null;
  protected config: BotConfig;
  protected lastScan: number = 0;
  protected readonly SCAN_INTERVAL = 1000; // 1 second between scans
  protected readonly MAX_CONCURRENT_TRADES = 5;
  protected activeTradeCount = 0;
  protected circuitBreaker: CircuitBreaker;
  protected opportunityOptimizer: OpportunityOptimizer;

  constructor(config: BotConfig) {
    this.id = config.id;
    this.name = config.name;
    this.type = config.type;
    this.minProfitThreshold = config.minProfitThreshold;
    this.maxPositionSize = config.maxPositionSize;
    this.leverageLimit = config.leverageLimit;
    this.exchanges = config.exchanges;
    this.pairs = config.pairs;
    this.config = config;
    
    // Initialize circuit breaker with custom settings based on bot type
    this.circuitBreaker = new CircuitBreaker(
      this.getCircuitBreakerConfig().maxFailures,
      this.getCircuitBreakerConfig().resetTimeout,
      this.getCircuitBreakerConfig().riskThreshold
    );

    // Initialize opportunity optimizer
    this.opportunityOptimizer = new OpportunityOptimizer();
  }

  private getCircuitBreakerConfig() {
    // Configure circuit breaker settings based on bot type
    switch (this.type) {
      case 'dex':
        return {
          maxFailures: 2, // More sensitive due to blockchain risks
          resetTimeout: 120000, // 2 minutes
          riskThreshold: 0.7 // Lower threshold for DEX operations
        };
      case 'perpetual':
        return {
          maxFailures: 3,
          resetTimeout: 60000, // 1 minute
          riskThreshold: 0.8
        };
      case 'basis':
        return {
          maxFailures: 4,
          resetTimeout: 90000, // 1.5 minutes
          riskThreshold: 0.85
        };
      case 'statistical':
        return {
          maxFailures: 5,
          resetTimeout: 180000, // 3 minutes
          riskThreshold: 0.9
        };
      default:
        return {
          maxFailures: 3,
          resetTimeout: 60000,
          riskThreshold: 0.8
        };
    }
  }

  async start(): Promise<void> {
    if (this.status === 'running') return;

    try {
      await this.circuitBreaker.execute(async () => {
        this.status = 'running';
        await this.updateStatus('running');
        this.startMonitoring();
      });
    } catch (error) {
      console.error(`Failed to start bot ${this.name}:`, error);
      this.status = 'error';
      await this.updateStatus('error');
      throw error;
    }
  }

  private startMonitoring() {
    if (this.interval) {
      clearInterval(this.interval);
    }

    this.interval = setInterval(async () => {
      try {
        const now = Date.now();
        if (now - this.lastScan >= this.SCAN_INTERVAL && 
            this.activeTradeCount < this.MAX_CONCURRENT_TRADES) {
          this.lastScan = now;
          await this.circuitBreaker.execute(() => this.tradingLoop());
        }
      } catch (error) {
        console.error(`Error in trading loop for ${this.name}:`, error);
        await this.logError(error);
      }
    }, 100);
  }

  async stop(): Promise<void> {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    this.status = 'stopped';
    await this.updateStatus('stopped');
  }

  getStatus(): string {
    return this.status;
  }

  protected async executeTrade(opportunity: TradeOpportunity): Promise<TradeResult> {
    return this.circuitBreaker.execute(async () => {
      try {
        // Get current positions
        const { data: positions } = await supabase
          .from('bot_positions')
          .select('*')
          .eq('bot_id', this.id)
          .eq('status', 'open');

        // Check each position for potential rotation
        for (const position of positions || []) {
          const rotationAnalysis = await this.opportunityOptimizer.evaluatePositionRotation(
            {
              id: position.id,
              botId: position.bot_id,
              clientId: position.client_id,
              exchange: position.exchange,
              pair: position.pair,
              size: position.size,
              leverage: position.leverage,
              margin: position.margin,
              entryPrice: position.entry_price,
              currentPrice: position.current_price,
              entryTimestamp: new Date(position.entry_timestamp),
              status: position.status,
              pnl: position.pnl || 0
            },
            opportunity
          );

          if (rotationAnalysis.shouldRotate) {
            console.log(`Rotating position ${position.id}: ${rotationAnalysis.reason}`);
            
            // Close existing position
            await this.closePosition(position.id);
            
            // Execute new trade
            this.activeTradeCount++;
            const result = await this.executeTradeInternal(opportunity);
            this.activeTradeCount--;
            
            return {
              ...result,
              metadata: {
                ...result.metadata,
                rotationType: 'position_rotation',
                previousPosition: position.id,
                improvementReason: rotationAnalysis.reason,
                expectedImprovement: rotationAnalysis.expectedImprovement,
                rotationCosts: rotationAnalysis.costs
              }
            };
          }
        }

        // If no rotation needed or no existing positions, execute new trade
        this.activeTradeCount++;
        const result = await this.executeTradeInternal(opportunity);
        this.activeTradeCount--;
        return result;
      } catch (error) {
        console.error('Error executing trade:', error);
        throw error;
      }
    });
  }

  private async closePosition(positionId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('bot_positions')
        .update({
          status: 'closed',
          exit_timestamp: new Date().toISOString()
        })
        .eq('id', positionId);

      if (error) throw error;
    } catch (error) {
      console.error('Error closing position:', error);
      throw error;
    }
  }

  // Abstract methods that must be implemented by specific bot types
  abstract findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]>;
  abstract validateOpportunity(opportunity: TradeOpportunity): Promise<boolean>;
  abstract checkRiskLimits(opportunity: TradeOpportunity): Promise<RiskAssessment>;
  abstract calculatePosition(opportunity: TradeOpportunity): Promise<PositionSize>;
  protected abstract executeTradeInternal(opportunity: TradeOpportunity): Promise<TradeResult>;

  protected async updateStatus(status: 'running' | 'stopped' | 'error'): Promise<void> {
    try {
      const { error } = await supabase
        .from('bot_configs')
        .update({ status })
        .eq('id', this.id);

      if (error) throw error;
    } catch (error) {
      console.error(`Failed to update bot status for ${this.id}:`, error);
    }
  }

  protected async logError(error: unknown): Promise<void> {
    try {
      const { error: dbError } = await supabase
        .from('bot_trades')
        .insert([{
          bot_id: this.id,
          status: 'error',
          error: error instanceof Error ? error.message : 'Unknown error'
        }]);

      if (dbError) throw dbError;
    } catch (logError) {
      console.error(`Failed to log error for bot ${this.id}:`, logError);
    }
  }

  protected async getMarketPrices(): Promise<MarketPrice[]> {
    try {
      const { data, error } = await supabase
        .from('market_prices')
        .select('*')
        .in('source', this.exchanges)
        .order('timestamp', { ascending: false });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error(`Failed to fetch market prices for bot ${this.id}:`, error);
      return [];
    }
  }

  private async tradingLoop(): Promise<void> {
    const prices = await this.getMarketPrices();
    const opportunities = await this.findOpportunities(prices);

    for (const opportunity of opportunities) {
      if (await this.validateOpportunity(opportunity)) {
        const riskAssessment = await this.checkRiskLimits(opportunity);
        
        if (!riskAssessment.warnings.length && 
            Object.values(riskAssessment.limits).every(limit => limit)) {
          await this.executeTrade(opportunity);
        }
      }
    }
  }
}

export { AbstractBot }