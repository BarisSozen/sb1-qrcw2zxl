import { AbstractBot } from '../AbstractBot';
import { MarketPrice, TradeOpportunity, TradeResult, RiskAssessment, PositionSize } from '../types';

export class DexArbitrageBot extends AbstractBot {
  async findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]> {
    const opportunities: TradeOpportunity[] = [];
    const tokens = new Set(prices.map(p => p.token));

    for (const token of tokens) {
      const tokenPrices = prices.filter(p => p.token === token);
      
      // Group prices by category (DEX vs CEX)
      const dexPrices = tokenPrices.filter(p => p.category === 'dex');
      const cexPrices = tokenPrices.filter(p => p.category === 'cex');
      
      // Find arbitrage opportunities between DEX and CEX
      for (const dexPrice of dexPrices) {
        for (const cexPrice of cexPrices) {
          // Calculate price difference percentage
          const priceDiff = Math.abs(dexPrice.spotPrice - cexPrice.spotPrice);
          const spread = (priceDiff / Math.min(dexPrice.spotPrice, cexPrice.spotPrice)) * 100;
          
          if (spread > this.minProfitThreshold) {
            // Determine direction (buy on lower price, sell on higher price)
            const [entryPrice, exitPrice] = dexPrice.spotPrice < cexPrice.spotPrice
              ? [dexPrice, cexPrice]
              : [cexPrice, dexPrice];

            // Calculate optimal position size
            const volume = Math.min(
              this.maxPositionSize,
              this.maxPositionSize * (spread / (this.minProfitThreshold * 2))
            );

            // Calculate gas costs for DEX transactions
            const estimatedGasCost = await this.estimateGasCost(
              entryPrice.source,
              token,
              volume
            );

            // Calculate net profit after gas and fees
            const grossProfit = (volume * spread) / 100;
            const netProfit = grossProfit - estimatedGasCost;

            // Only include if still profitable after gas
            if (netProfit > 0) {
              opportunities.push({
                id: crypto.randomUUID(),
                type: 'dex',
                token,
                entry: {
                  exchange: entryPrice.source,
                  price: entryPrice.spotPrice,
                  timestamp: Date.now()
                },
                exit: {
                  exchange: exitPrice.source,
                  price: exitPrice.spotPrice,
                  timestamp: Date.now()
                },
                spread,
                volume,
                estimatedProfit: netProfit,
                requiredCapital: volume,
                riskScore: this.calculateRiskScore(
                  spread,
                  entryPrice.source,
                  exitPrice.source,
                  estimatedGasCost
                ),
                metadata: {
                  estimatedGasCost,
                  isDexEntry: entryPrice.category === 'dex',
                  dexExchange: dexPrice.source,
                  cexExchange: cexPrice.source,
                  slippageEstimate: this.estimateSlippage(volume, entryPrice.source)
                }
              });
            }
          }
        }
      }
    }

    return opportunities.sort((a, b) => b.estimatedProfit - a.estimatedProfit);
  }

  async validateOpportunity(opportunity: TradeOpportunity): Promise<boolean> {
    const metadata = opportunity.metadata;
    
    // Get current prices
    const currentPrices = await this.getMarketPrices();
    
    // Find current prices for both exchanges
    const dexPrice = currentPrices.find(p => 
      p.token === opportunity.token && 
      p.source === metadata.dexExchange
    );
    
    const cexPrice = currentPrices.find(p => 
      p.token === opportunity.token && 
      p.source === metadata.cexExchange
    );

    if (!dexPrice || !cexPrice) return false;

    // Recalculate spread
    const priceDiff = Math.abs(dexPrice.spotPrice - cexPrice.spotPrice);
    const currentSpread = (priceDiff / Math.min(dexPrice.spotPrice, cexPrice.spotPrice)) * 100;

    // Check if still profitable after gas
    const estimatedGasCost = await this.estimateGasCost(
      metadata.dexExchange,
      opportunity.token,
      opportunity.volume
    );

    const grossProfit = (opportunity.volume * currentSpread) / 100;
    const netProfit = grossProfit - estimatedGasCost;

    // Validate liquidity
    const hasLiquidity = await this.checkLiquidity(
      metadata.dexExchange,
      opportunity.token,
      opportunity.volume
    );

    return netProfit > 0 && hasLiquidity;
  }

  async executeTrade(opportunity: TradeOpportunity): Promise<TradeResult> {
    const metadata = opportunity.metadata;
    
    try {
      // Execute DEX trade
      const dexResult = await this.executeDexTrade(
        opportunity.token,
        metadata.dexExchange,
        opportunity.volume,
        metadata.isDexEntry ? 'buy' : 'sell'
      );

      // Execute CEX trade
      const cexResult = await this.executeCexTrade(
        opportunity.token,
        metadata.cexExchange,
        opportunity.volume,
        metadata.isDexEntry ? 'sell' : 'buy'
      );

      return {
        success: true,
        entry: {
          price: opportunity.entry.price,
          timestamp: Date.now(),
          txHash: metadata.isDexEntry ? dexResult.txHash : cexResult.txHash
        },
        exit: {
          price: opportunity.exit.price,
          timestamp: Date.now(),
          txHash: metadata.isDexEntry ? cexResult.txHash : dexResult.txHash
        },
        fees: dexResult.fees + cexResult.fees,
        metadata: {
          gasCost: dexResult.gasCost,
          dexOrderId: dexResult.orderId,
          cexOrderId: cexResult.orderId,
          actualSlippage: dexResult.slippage
        }
      };
    } catch (error) {
      return {
        success: false,
        fees: 0,
        error: error instanceof Error ? error.message : 'Trade execution failed',
        metadata: {}
      };
    }
  }

  async checkRiskLimits(opportunity: TradeOpportunity): Promise<RiskAssessment> {
    const metadata = opportunity.metadata;
    
    // Calculate maximum potential loss including gas costs
    const maxLoss = opportunity.requiredCapital * 0.1 + metadata.estimatedGasCost;
    
    // Check DEX-specific limits
    const dexLimits = await this.checkDexLimits(
      metadata.dexExchange,
      opportunity.token,
      opportunity.volume
    );

    // Check CEX limits
    const cexLimits = await this.checkExchangeLimits(
      metadata.cexExchange,
      opportunity.token,
      opportunity.volume
    );

    return {
      riskScore: opportunity.riskScore,
      maxLoss,
      warnings: [...dexLimits.warnings, ...cexLimits.warnings],
      limits: {
        position: opportunity.volume <= this.maxPositionSize,
        leverage: false, // DEX trades don't use leverage
        concentration: dexLimits.withinConcentrationLimits && cexLimits.withinConcentrationLimits,
        liquidity: dexLimits.hasLiquidity && cexLimits.hasLiquidity
      }
    };
  }

  async calculatePosition(opportunity: TradeOpportunity): Promise<PositionSize> {
    // Calculate optimal position size considering gas costs
    const gasCost = opportunity.metadata.estimatedGasCost;
    const minProfitableSize = (gasCost * 100) / opportunity.spread;
    
    // Ensure position size covers gas costs with some margin
    const adjustedSize = Math.max(
      minProfitableSize * 1.5, // 50% margin over break-even
      opportunity.volume
    );

    return {
      size: Math.min(adjustedSize, this.maxPositionSize),
      leverage: 1, // No leverage for DEX trades
      margin: adjustedSize,
      notional: adjustedSize * opportunity.entry.price,
      maxDrawdown: adjustedSize * 0.1 + gasCost // Include gas cost in max drawdown
    };
  }

  private calculateRiskScore(
    spread: number,
    exchange1: string,
    exchange2: string,
    gasCost: number
  ): number {
    let riskScore = 0;
    
    // Spread risk (higher spread = higher risk)
    riskScore += Math.min(spread / 20, 0.3);
    
    // DEX-specific risks
    riskScore += 0.2; // Base DEX risk
    
    // Gas cost risk (higher gas = higher risk)
    const gasRiskFactor = gasCost / (spread * 100);
    riskScore += Math.min(gasRiskFactor, 0.2);
    
    // Exchange risk
    const exchangeRisk = {
      uniswap: 0.15,
      sushiswap: 0.2,
      binance: 0.1,
      bybit: 0.15,
      okx: 0.15
    };
    
    riskScore += (
      exchangeRisk[exchange1 as keyof typeof exchangeRisk] || 0.3
    );
    
    riskScore += (
      exchangeRisk[exchange2 as keyof typeof exchangeRisk] || 0.3
    );
    
    return Math.min(riskScore, 0.95);
  }

  private async estimateGasCost(
    dexExchange: string,
    token: string,
    volume: number
  ): Promise<number> {
    // Mock implementation - replace with actual gas estimation
    return volume * 0.001; // 0.1% of volume as gas cost
  }

  private async checkLiquidity(
    exchange: string,
    token: string,
    volume: number
  ): Promise<boolean> {
    // Mock implementation - replace with actual liquidity check
    return true;
  }

  private async executeDexTrade(
    token: string,
    exchange: string,
    volume: number,
    side: 'buy' | 'sell'
  ): Promise<{
    orderId: string;
    txHash: string;
    fees: number;
    gasCost: number;
    slippage: number;
  }> {
    // Mock implementation - replace with actual DEX trading logic
    return {
      orderId: crypto.randomUUID(),
      txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`,
      fees: volume * 0.003, // 0.3% DEX fee
      gasCost: volume * 0.001, // Gas cost
      slippage: 0.001 // 0.1% slippage
    };
  }

  private async executeCexTrade(
    token: string,
    exchange: string,
    volume: number,
    side: 'buy' | 'sell'
  ): Promise<{
    orderId: string;
    txHash: string;
    fees: number;
  }> {
    // Mock implementation - replace with actual CEX trading logic
    return {
      orderId: crypto.randomUUID(),
      txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`,
      fees: volume * 0.001 // 0.1% CEX fee
    };
  }

  private async checkDexLimits(
    exchange: string,
    token: string,
    volume: number
  ): Promise<{
    warnings: string[];
    withinConcentrationLimits: boolean;
    hasLiquidity: boolean;
  }> {
    // Mock implementation - replace with actual DEX limit checks
    return {
      warnings: [],
      withinConcentrationLimits: true,
      hasLiquidity: true
    };
  }

  private async checkExchangeLimits(
    exchange: string,
    token: string,
    volume: number
  ): Promise<{
    warnings: string[];
    withinConcentrationLimits: boolean;
    hasLiquidity: boolean;
  }> {
    // Mock implementation - replace with actual CEX limit checks
    return {
      warnings: [],
      withinConcentrationLimits: true,
      hasLiquidity: true
    };
  }

  private estimateSlippage(volume: number, exchange: string): number {
    // Mock implementation - replace with actual slippage estimation
    return 0.001; // 0.1% estimated slippage
  }
}