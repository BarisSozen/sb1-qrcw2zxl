import { AbstractBot } from '../AbstractBot';
import { MarketPrice, TradeOpportunity, TradeResult, RiskAssessment, PositionSize } from '../types';
import { supabase } from '../../lib/supabaseClient';

interface TriangularPath {
  tokens: string[];
  exchanges: string[];
  rates: number[];
  profit: number;
  gasEstimate: number;
  netProfit: number;
}

export class TriangularArbitrageBot extends AbstractBot {
  private readonly MAX_SLIPPAGE = 0.01; // 1% max slippage
  private readonly MIN_PROFIT_AFTER_GAS = 0.003; // 0.3% min profit after gas
  private readonly GAS_PRICE_GWEI = 50; // Default gas price in Gwei
  private readonly GAS_LIMIT_BASE = 150000; // Base gas limit for a swap
  private readonly MAX_PATHS_TO_CHECK = 100; // Maximum number of paths to check

  constructor(config: any) {
    super(config);
  }

  async findOpportunities(prices: MarketPrice[]): Promise<TradeOpportunity[]> {
    try {
      // Filter for DEX prices only (Uniswap)
      const dexPrices = prices.filter(p => p.category === 'dex' && p.source.toLowerCase().includes('uniswap'));
      
      if (dexPrices.length === 0) {
        console.log('No DEX prices available for triangular arbitrage');
        return [];
      }

      // Get all available tokens
      const tokens = [...new Set(dexPrices.map(p => p.token))];
      
      // Build exchange rate graph
      const graph = this.buildExchangeRateGraph(dexPrices);
      
      // Find negative cycles using Bellman-Ford algorithm
      const paths = this.findArbitragePaths(graph, tokens);
      
      // Convert paths to trade opportunities
      return this.pathsToOpportunities(paths);
    } catch (error) {
      console.error('Error finding triangular arbitrage opportunities:', error);
      return [];
    }
  }

  private buildExchangeRateGraph(prices: MarketPrice[]): Map<string, Map<string, number>> {
    const graph = new Map<string, Map<string, number>>();
    
    // Initialize graph
    for (const price of prices) {
      if (!graph.has(price.token)) {
        graph.set(price.token, new Map<string, number>());
      }
      
      // Add edges for each trading pair
      // For each token pair, we need to add both directions
      const baseToken = price.token;
      const quoteToken = price.target;
      
      // Add base -> quote edge (using spot price)
      const baseToQuote = graph.get(baseToken)!;
      baseToQuote.set(quoteToken, -Math.log(price.spotPrice)); // Negative log for finding negative cycles
      
      // Add quote -> base edge (inverse of spot price)
      if (!graph.has(quoteToken)) {
        graph.set(quoteToken, new Map<string, number>());
      }
      const quoteToBase = graph.get(quoteToken)!;
      quoteToBase.set(baseToken, -Math.log(1 / price.spotPrice));
    }
    
    return graph;
  }

  private findArbitragePaths(graph: Map<string, Map<string, number>>, tokens: string[]): TriangularPath[] {
    const paths: TriangularPath[] = [];
    const n = tokens.length;
    
    // For each possible starting token
    for (let i = 0; i < n && paths.length < this.MAX_PATHS_TO_CHECK; i++) {
      const source = tokens[i];
      
      // Initialize distance and predecessor arrays
      const distance = new Map<string, number>();
      const predecessor = new Map<string, string>();
      
      // Initialize distances
      for (const token of tokens) {
        distance.set(token, token === source ? 0 : Infinity);
        predecessor.set(token, '');
      }
      
      // Relax edges |V| - 1 times
      for (let j = 0; j < n - 1; j++) {
        for (const u of tokens) {
          const edges = graph.get(u);
          if (!edges) continue;
          
          for (const [v, weight] of edges.entries()) {
            if (distance.get(u)! + weight < distance.get(v)!) {
              distance.set(v, distance.get(u)! + weight);
              predecessor.set(v, u);
            }
          }
        }
      }
      
      // Check for negative weight cycles
      for (const u of tokens) {
        const edges = graph.get(u);
        if (!edges) continue;
        
        for (const [v, weight] of edges.entries()) {
          if (distance.get(u)! + weight < distance.get(v)!) {
            // Negative cycle detected
            // Reconstruct the cycle
            const cycle = this.reconstructCycle(u, v, predecessor);
            
            if (cycle.length >= 3) {
              // Calculate profit for this cycle
              const profit = this.calculateCycleProfit(cycle, graph);
              
              // Estimate gas cost
              const gasEstimate = this.estimateGasCost(cycle.length);
              
              // Calculate net profit after gas
              const netProfit = profit - gasEstimate;
              
              // Only add if profitable after gas
              if (netProfit > this.MIN_PROFIT_AFTER_GAS) {
                paths.push({
                  tokens: cycle,
                  exchanges: cycle.map(() => 'uniswap'), // All on Uniswap
                  rates: this.getCycleRates(cycle, graph),
                  profit,
                  gasEstimate,
                  netProfit
                });
              }
            }
          }
        }
      }
    }
    
    // Sort by net profit
    return paths.sort((a, b) => b.netProfit - a.netProfit);
  }

  private reconstructCycle(u: string, v: string, predecessor: Map<string, string>): string[] {
    const cycle: string[] = [v, u];
    let current = predecessor.get(u)!;
    
    // Prevent infinite loops
    const visited = new Set<string>([u, v]);
    
    while (current && !visited.has(current)) {
      cycle.push(current);
      visited.add(current);
      current = predecessor.get(current)!;
    }
    
    return cycle;
  }

  private calculateCycleProfit(cycle: string[], graph: Map<string, Map<string, number>>): number {
    let profit = 0;
    
    for (let i = 0; i < cycle.length; i++) {
      const from = cycle[i];
      const to = cycle[(i + 1) % cycle.length];
      
      const edges = graph.get(from);
      if (!edges || !edges.has(to)) continue;
      
      profit += edges.get(to)!;
    }
    
    // Convert from log space back to normal space
    return Math.exp(-profit) - 1;
  }

  private getCycleRates(cycle: string[], graph: Map<string, Map<string, number>>): number[] {
    const rates: number[] = [];
    
    for (let i = 0; i < cycle.length; i++) {
      const from = cycle[i];
      const to = cycle[(i + 1) % cycle.length];
      
      const edges = graph.get(from);
      if (!edges || !edges.has(to)) {
        rates.push(0);
        continue;
      }
      
      // Convert from log space back to normal space
      rates.push(Math.exp(-edges.get(to)!));
    }
    
    return rates;
  }

  private estimateGasCost(pathLength: number): number {
    // Estimate gas cost based on path length
    const gasLimit = this.GAS_LIMIT_BASE * pathLength;
    const gasCostEth = (gasLimit * this.GAS_PRICE_GWEI) / 1e9;
    
    // Assume ETH price of $3000 for conversion to USD
    const ethPrice = 3000;
    return gasCostEth * ethPrice;
  }

  private pathsToOpportunities(paths: TriangularPath[]): TradeOpportunity[] {
    return paths.map(path => ({
      id: crypto.randomUUID(),
      type: 'triangular',
      token: path.tokens[0], // Starting token
      entry: {
        exchange: path.exchanges[0],
        price: 1, // Not applicable for triangular
        timestamp: Date.now()
      },
      exit: {
        exchange: path.exchanges[path.exchanges.length - 1],
        price: 1, // Not applicable for triangular
        timestamp: Date.now()
      },
      spread: path.profit * 100, // Convert to percentage
      volume: this.maxPositionSize * 0.1, // Start with 10% of max position
      estimatedProfit: path.netProfit * (this.maxPositionSize * 0.1),
      requiredCapital: this.maxPositionSize * 0.1,
      riskScore: this.calculateRiskScore(path),
      metadata: {
        path: path.tokens,
        exchanges: path.exchanges,
        rates: path.rates,
        gasEstimate: path.gasEstimate,
        netProfit: path.netProfit
      }
    }));
  }

  private calculateRiskScore(path: TriangularPath): number {
    // Calculate risk based on various factors
    let riskScore = 0;
    
    // Path length risk (longer paths = higher risk)
    riskScore += Math.min((path.tokens.length - 3) * 0.1, 0.3);
    
    // Profit margin risk (lower profit = higher risk)
    riskScore += Math.max(0.5 - path.netProfit * 10, 0);
    
    // Gas price risk
    const gasPriceRisk = this.GAS_PRICE_GWEI / 200; // Normalize to 0-0.25 range
    riskScore += Math.min(gasPriceRisk, 0.25);
    
    // Slippage risk (estimated)
    riskScore += 0.2; // Base slippage risk for DEX trades
    
    return Math.min(riskScore, 0.95);
  }

  async validateOpportunity(opportunity: TradeOpportunity): Promise<boolean> {
    // Validate that the opportunity is still profitable
    const path = opportunity.metadata.path;
    const rates = opportunity.metadata.rates;
    
    // Check if all tokens in the path are still available
    const { data: marketPrices } = await supabase
      .from('market_prices')
      .select('*')
      .eq('source', 'uniswap')
      .in('token', path)
      .order('timestamp', { ascending: false });
    
    if (!marketPrices || marketPrices.length < path.length) {
      return false;
    }
    
    // Check if rates have changed significantly
    const currentRates: number[] = [];
    for (let i = 0; i < path.length; i++) {
      const from = path[i];
      const to = path[(i + 1) % path.length];
      
      const fromPrice = marketPrices.find(p => p.token === from)?.spotPrice;
      const toPrice = marketPrices.find(p => p.token === to)?.spotPrice;
      
      if (!fromPrice || !toPrice) return false;
      
      const currentRate = toPrice / fromPrice;
      currentRates.push(currentRate);
      
      // If rate has changed by more than MAX_SLIPPAGE, opportunity is invalid
      if (Math.abs(currentRate - rates[i]) / rates[i] > this.MAX_SLIPPAGE) {
        return false;
      }
    }
    
    // Calculate current profit
    let product = 1;
    for (const rate of currentRates) {
      product *= rate;
    }
    
    const currentProfit = product - 1;
    
    // Estimate current gas cost
    const gasEstimate = this.estimateGasCost(path.length);
    
    // Check if still profitable after gas
    return currentProfit > (gasEstimate / opportunity.volume);
  }

  async checkRiskLimits(opportunity: TradeOpportunity): Promise<RiskAssessment> {
    const path = opportunity.metadata.path;
    const gasEstimate = opportunity.metadata.gasEstimate;
    
    // Calculate maximum potential loss
    const maxLoss = opportunity.volume * this.MAX_SLIPPAGE * path.length + gasEstimate;
    
    // Check liquidity for each token in the path
    const liquidityWarnings: string[] = [];
    let hasLiquidity = true;
    
    for (const token of path) {
      const { data: liquidity } = await supabase
        .from('market_prices')
        .select('liquidity')
        .eq('token', token)
        .eq('source', 'uniswap')
        .order('timestamp', { ascending: false })
        .limit(1)
        .single();
      
      if (!liquidity || liquidity.liquidity < opportunity.volume * 10) {
        liquidityWarnings.push(`Low liquidity for ${token}`);
        hasLiquidity = false;
      }
    }
    
    return {
      riskScore: opportunity.riskScore,
      maxLoss,
      warnings: liquidityWarnings,
      limits: {
        position: opportunity.volume <= this.maxPositionSize,
        leverage: true, // No leverage in triangular arbitrage
        concentration: true, // Not applicable
        liquidity: hasLiquidity
      }
    };
  }

  async calculatePosition(opportunity: TradeOpportunity): Promise<PositionSize> {
    // For triangular arbitrage, we don't use leverage
    return {
      size: opportunity.volume,
      leverage: 1,
      margin: opportunity.volume,
      notional: opportunity.volume,
      maxDrawdown: opportunity.volume * 0.1 + opportunity.metadata.gasEstimate
    };
  }

  protected async executeTradeInternal(opportunity: TradeOpportunity): Promise<TradeResult> {
    try {
      const path = opportunity.metadata.path;
      const volume = opportunity.volume;
      
      // Mock implementation - in a real system, this would execute the trades
      console.log(`Executing triangular arbitrage: ${path.join(' -> ')} with volume ${volume}`);
      
      // Simulate trade execution
      const success = Math.random() > 0.1; // 90% success rate
      
      if (!success) {
        return {
          success: false,
          fees: opportunity.metadata.gasEstimate,
          error: 'Trade execution failed due to price movement',
          metadata: {
            path,
            executionTime: Math.floor(Math.random() * 200 + 300) // 300-500ms
          }
        };
      }
      
      // Calculate actual profit (with some randomness to simulate real-world conditions)
      const profitVariation = 1 + (Math.random() * 0.2 - 0.1); // +/- 10%
      const actualProfit = opportunity.estimatedProfit * profitVariation;
      
      // Calculate fees (gas cost)
      const fees = opportunity.metadata.gasEstimate;
      
      return {
        success: true,
        entry: {
          price: 1, // Not applicable for triangular
          timestamp: Date.now(),
          txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`
        },
        exit: {
          price: 1, // Not applicable for triangular
          timestamp: Date.now() + Math.floor(Math.random() * 1000), // 0-1000ms later
          txHash: `0x${crypto.randomUUID().replace(/-/g, '')}`
        },
        profit: actualProfit,
        fees,
        metadata: {
          path,
          executionTime: Math.floor(Math.random() * 200 + 300), // 300-500ms
          gasUsed: Math.floor(opportunity.metadata.gasEstimate * 1e9 / this.GAS_PRICE_GWEI),
          slippage: (Math.random() * 0.008).toFixed(4) // 0-0.8% slippage
        }
      };
    } catch (error) {
      console.error('Error executing triangular arbitrage trade:', error);
      return {
        success: false,
        fees: opportunity.metadata.gasEstimate,
        error: error instanceof Error ? error.message : 'Unknown error during trade execution',
        metadata: {}
      };
    }
  }
}