import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

export interface RiskMetricsData {
  positionMetrics: {
    positionConcentration: number;
    crossExchangeExposure: number;
    positionCorrelation: number;
  };
  leverageMetrics: {
    avgLeverageRatio: number;
    marginUtilization: number;
    liquidationRisk: number;
  };
  executionMetrics: {
    slippageImpact: number;
    orderFillRate: number;
    executionLatency: number;
  };
  counterpartyMetrics: {
    exchangeConcentration: number;
    settlementRisk: number;
    custodyRisk: number;
  };
}

export function useRiskMetrics() {
  const [riskMetrics, setRiskMetrics] = useState<RiskMetricsData>({
    positionMetrics: {
      positionConcentration: 0,
      crossExchangeExposure: 0,
      positionCorrelation: 0
    },
    leverageMetrics: {
      avgLeverageRatio: 0,
      marginUtilization: 0,
      liquidationRisk: 0
    },
    executionMetrics: {
      slippageImpact: 0,
      orderFillRate: 0,
      executionLatency: 0
    },
    counterpartyMetrics: {
      exchangeConcentration: 0,
      settlementRisk: 0,
      custodyRisk: 0
    }
  });

  useEffect(() => {
    const fetchRiskMetrics = async () => {
      try {
        // Fetch latest risk metrics for all active bots
        const { data: metricsData, error } = await supabase
          .from('risk_metrics')
          .select(`
            position_concentration,
            cross_exchange_exposure,
            position_correlation,
            avg_leverage_ratio,
            margin_utilization,
            liquidation_risk,
            slippage_impact,
            order_fill_rate,
            execution_latency,
            exchange_concentration,
            settlement_risk,
            custody_risk
          `)
          .order('timestamp', { ascending: false })
          .limit(1);

        if (error) throw error;

        if (metricsData && metricsData.length > 0) {
          const metrics = metricsData[0];
          setRiskMetrics({
            positionMetrics: {
              positionConcentration: metrics.position_concentration * 100,
              crossExchangeExposure: metrics.cross_exchange_exposure * 100,
              positionCorrelation: metrics.position_correlation * 100
            },
            leverageMetrics: {
              avgLeverageRatio: metrics.avg_leverage_ratio,
              marginUtilization: metrics.margin_utilization * 100,
              liquidationRisk: metrics.liquidation_risk * 100
            },
            executionMetrics: {
              slippageImpact: metrics.slippage_impact * 100,
              orderFillRate: metrics.order_fill_rate * 100,
              executionLatency: metrics.execution_latency
            },
            counterpartyMetrics: {
              exchangeConcentration: metrics.exchange_concentration * 100,
              settlementRisk: metrics.settlement_risk * 100,
              custodyRisk: metrics.custody_risk * 100
            }
          });
        }

        // Set up real-time subscription
        const subscription = supabase
          .channel('risk-metrics-changes')
          .on('postgres_changes', {
            event: '*',
            schema: 'public',
            table: 'risk_metrics'
          }, fetchRiskMetrics)
          .subscribe();

        return () => {
          subscription.unsubscribe();
        };

      } catch (error) {
        console.error('Error fetching risk metrics:', error);
      }
    };

    fetchRiskMetrics();
    const interval = setInterval(fetchRiskMetrics, 60000); // Update every minute

    return () => clearInterval(interval);
  }, []);

  return riskMetrics;
}