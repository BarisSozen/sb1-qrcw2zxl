import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

export interface DashboardStats {
  totalTrades: number;
  totalPnl: number;
  winRate: number;
  activeBots: number;
  openPositions: number;
  totalInvested: number;
  currentBalance: number;
  bestPerformingPair: string;
  bestPerformingBot: string;
  maxDrawdown: number;
  avgDrawdown: number;
  recoveryTime: number;
  calmarRatio: number;
  avgProfitPerTrade: number;
  winLossRatio: number;
}

export interface BotTypePerformance {
  type: string;
  name: string;
  annualYield: number;
  monthlyYield: number;
  weeklyYield: number;
  dailyYield: number;
  totalTrades: number;
  activeBots: number;
}

export interface YieldDataPoint {
  date: string;
  dexYield: number;
  cexYield: number;
  hybridYield: number;
  compound: number;
  statisticalYield: number;
}

export interface DrawdownPoint {
  timestamp: string;
  drawdown: number;
}

export function useDashboardData(timeframe: string = '30d') {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [botTypePerformance, setBotTypePerformance] = useState<BotTypePerformance[]>([]);
  const [yieldData, setYieldData] = useState<YieldDataPoint[]>([]);
  const [drawdownHistory, setDrawdownHistory] = useState<DrawdownPoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Calculate date range based on timeframe
        const endDate = new Date();
        const startDate = new Date();
        
        switch (timeframe) {
          case '7d':
            startDate.setDate(endDate.getDate() - 7);
            break;
          case '30d':
            startDate.setDate(endDate.getDate() - 30);
            break;
          case '90d':
            startDate.setDate(endDate.getDate() - 90);
            break;
          case '1y':
            startDate.setDate(endDate.getDate() - 365);
            break;
          default:
            startDate.setDate(endDate.getDate() - 30);
        }

        // Fetch trades within timeframe
        const { data: trades, error: tradesError } = await supabase
          .from('bot_trades')
          .select('*')
          .gte('entry_timestamp', startDate.toISOString())
          .lte('entry_timestamp', endDate.toISOString());

        if (tradesError) throw tradesError;

        // Fetch active bots
        const { data: bots, error: botsError } = await supabase
          .from('bot_configs')
          .select('*')
          .eq('active', true);

        if (botsError) throw botsError;

        // Fetch open positions
        const { data: positions, error: positionsError } = await supabase
          .from('bot_positions')
          .select('*')
          .eq('status', 'open');

        if (positionsError) throw positionsError;

        // Calculate dashboard stats
        const closedTrades = trades?.filter(t => t.status === 'closed') || [];
        const winningTrades = closedTrades.filter(t => t.pnl > 0);
        const losingTrades = closedTrades.filter(t => t.pnl <= 0);
        const totalPnl = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
        
        // Calculate drawdown metrics
        const { maxDrawdown, avgDrawdown, recoveryTime } = calculateDrawdownMetrics(closedTrades);
        
        // Calculate win/loss ratio and avg profit per trade
        const winLossRatio = losingTrades.length > 0 ? winningTrades.length / losingTrades.length : 0;
        const avgProfitPerTrade = closedTrades.length > 0 ? totalPnl / closedTrades.length : 0;
        
        // Calculate Calmar ratio (annualized return / max drawdown)
        const annualizedReturn = (totalPnl / (closedTrades[0]?.entry_price || 1)) * (365 / timeframeDays(timeframe));
        const calmarRatio = maxDrawdown > 0 ? Math.abs(annualizedReturn / maxDrawdown) : 0;
        
        // Calculate best performing pair
        const pairPerformance: Record<string, number> = {};
        closedTrades.forEach(trade => {
          if (!trade.pnl) return;
          pairPerformance[trade.pair] = (pairPerformance[trade.pair] || 0) + trade.pnl;
        });
        
        const bestPair = Object.entries(pairPerformance)
          .sort(([, a], [, b]) => b - a)
          .map(([pair]) => pair)[0] || 'N/A';
        
        // Calculate best performing bot
        const botPerformance: Record<string, number> = {};
        closedTrades.forEach(trade => {
          if (!trade.pnl || !trade.bot_id) return;
          botPerformance[trade.bot_id] = (botPerformance[trade.bot_id] || 0) + trade.pnl;
        });
        
        const bestBotId = Object.entries(botPerformance)
          .sort(([, a], [, b]) => b - a)
          .map(([id]) => id)[0];
        
        const bestBot = bots?.find(b => b.id === bestBotId)?.name || 'N/A';

        setStats({
          totalTrades: closedTrades.length,
          totalPnl,
          winRate: closedTrades.length > 0 ? (winningTrades.length / closedTrades.length) * 100 : 0,
          activeBots: bots?.filter(b => b.status === 'running').length || 0,
          openPositions: positions?.length || 0,
          totalInvested: 0,
          currentBalance: 0,
          bestPerformingPair: bestPair,
          bestPerformingBot: bestBot,
          maxDrawdown,
          avgDrawdown,
          recoveryTime,
          calmarRatio,
          avgProfitPerTrade,
          winLossRatio
        });

        // Calculate bot type performance
        const botTypes = ['basis', 'perpetual', 'dex', 'statistical'];
        const botTypeNames = {
          'basis': 'Basis Arbitrage',
          'perpetual': 'Perpetual Arbitrage',
          'dex': 'DEX Arbitrage',
          'statistical': 'Statistical Arbitrage'
        };
        
        const performance: BotTypePerformance[] = [];
        
        for (const type of botTypes) {
          const typeBots = bots?.filter(b => b.type === type) || [];
          const typeActiveBots = typeBots.filter(b => b.status === 'running').length;
          
          const typeTrades = closedTrades.filter(t => {
            const bot = bots?.find(b => b.id === t.bot_id);
            return bot?.type === type;
          });
          
          const typePnl = typeTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
          const initialCapital = typeBots.reduce((sum, b) => sum + (b.max_position_size || 0), 0);
          
          // Calculate yields (annualized)
          const annualYield = initialCapital > 0 ? (typePnl / initialCapital) * 100 : 0;
          
          performance.push({
            type,
            name: botTypeNames[type as keyof typeof botTypeNames],
            annualYield,
            monthlyYield: annualYield / 12,
            weeklyYield: annualYield / 52,
            dailyYield: annualYield / 365,
            totalTrades: typeTrades.length,
            activeBots: typeActiveBots
          });
        }
        
        setBotTypePerformance(performance);

        // Generate yield data points
        const yieldPoints: YieldDataPoint[] = [];
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        
        for (let i = 0; i < months.length; i++) {
          // Base values with small random variations
          const dexYield = 4.0 + (i * 0.2) + (Math.random() * 0.5);
          const cexYield = 3.5 + (i * 0.15) + (Math.random() * 0.5);
          const hybridYield = 5.0 + (i * 0.2) + (Math.random() * 0.5);
          const statisticalYield = 4.5 + (i * 0.25) + (Math.random() * 0.5);
          
          // Compound is slightly higher than the average
          const compound = (dexYield + cexYield + hybridYield + statisticalYield) / 4 * 1.1;
          
          yieldPoints.push({
            date: `2025-${String(i + 1).padStart(2, '0')}`,
            dexYield,
            cexYield,
            hybridYield,
            compound,
            statisticalYield
          });
        }
        
        setYieldData(yieldPoints);

        // Generate drawdown history
        const drawdownPoints = generateDrawdownHistory(closedTrades);
        setDrawdownHistory(drawdownPoints);

      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
        
        // Set fallback data
        setStats({
          totalTrades: 0,
          totalPnl: 0,
          winRate: 0,
          activeBots: 0,
          openPositions: 0,
          totalInvested: 0,
          currentBalance: 0,
          bestPerformingPair: 'N/A',
          bestPerformingBot: 'N/A',
          maxDrawdown: 0,
          avgDrawdown: 0,
          recoveryTime: 0,
          calmarRatio: 0,
          avgProfitPerTrade: 0,
          winLossRatio: 0
        });
        
        setBotTypePerformance([]);
        setYieldData([]);
        setDrawdownHistory([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
    
    // Refresh data every 5 minutes
    const interval = setInterval(fetchDashboardData, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [timeframe]);

  return {
    stats,
    botTypePerformance,
    yieldData,
    drawdownHistory,
    isLoading,
    error
  };
}

function calculateDrawdownMetrics(trades: any[]) {
  if (!trades.length) {
    return { maxDrawdown: 0, avgDrawdown: 0, recoveryTime: 0 };
  }

  let peak = 0;
  let maxDrawdown = 0;
  let currentDrawdown = 0;
  let totalDrawdown = 0;
  let drawdownCount = 0;
  let recoveryTime = 0;
  let lastDrawdownStart = 0;

  const equity = trades.reduce((acc, trade) => {
    const balance = acc[acc.length - 1] + (trade.pnl || 0);
    acc.push(balance);
    return acc;
  }, [0]);

  equity.forEach((balance, i) => {
    if (balance > peak) {
      peak = balance;
      if (currentDrawdown > 0) {
        // Recovery completed
        recoveryTime += i - lastDrawdownStart;
        drawdownCount++;
      }
      currentDrawdown = 0;
    } else {
      const drawdown = (peak - balance) / peak;
      if (drawdown > currentDrawdown) {
        if (currentDrawdown === 0) {
          lastDrawdownStart = i;
        }
        currentDrawdown = drawdown;
        totalDrawdown += drawdown;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
    }
  });

  return {
    maxDrawdown: maxDrawdown * 100,
    avgDrawdown: drawdownCount > 0 ? (totalDrawdown / drawdownCount) * 100 : 0,
    recoveryTime: drawdownCount > 0 ? recoveryTime / drawdownCount : 0
  };
}

function generateDrawdownHistory(trades: any[]): DrawdownPoint[] {
  if (!trades.length) return [];

  let peak = 0;
  const points: DrawdownPoint[] = [];

  const equity = trades.reduce((acc, trade) => {
    const balance = acc[acc.length - 1] + (trade.pnl || 0);
    acc.push(balance);
    return acc;
  }, [0]);

  equity.forEach((balance, i) => {
    if (balance > peak) {
      peak = balance;
    }
    const drawdown = peak > 0 ? ((peak - balance) / peak) * 100 : 0;
    points.push({
      timestamp: trades[i]?.entry_timestamp || new Date(Date.now() - (i * 24 * 60 * 60 * 1000)).toISOString(),
      drawdown
    });
  });

  return points;
}

function timeframeDays(timeframe: string): number {
  switch (timeframe) {
    case '7d': return 7;
    case '30d': return 30;
    case '90d': return 90;
    case '1y': return 365;
    default: return 30;
  }
}