export type BotType = 'basis' | 'perpetual' | 'dex' | 'statistical' | 'triangular';
export type BotStatus = 'running' | 'stopped' | 'error';

export interface BotConfig {
  id: string;
  type: BotType;
  name: string;
  description?: string;
  active: boolean;
  status: BotStatus;
  interval?: number;
  minProfitThreshold: number;
  maxPositionSize: number;
  leverageLimit: number;
  exchanges: string[];
  pairs: string[];
  maxGasPrice?: number;
  maxSlippage?: number;
}

export interface BotStats {
  totalTrades: number;
  successfulTrades: number;
  failedTrades: number;
  totalProfit: number;
  winRate: number;
  averageProfit: number;
  lastTradeTime?: string;
  uptime: number;
  clientId?: string;
}