export interface MarketPrice {
  token: string;
  spotPrice: number;
  futuresPrice: number;
  fundingRate: number;
  futuresExpiry: number;
  timestamp: number;
  source: string;
  target: string;
  category: 'dex' | 'cex' | 'hybrid';
}