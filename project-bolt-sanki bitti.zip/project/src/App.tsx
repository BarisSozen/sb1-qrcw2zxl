import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Navbar } from './components/Navbar';
import { Landing } from './pages/Landing';
import { Dashboard } from './pages/Dashboard';
import { Trades } from './pages/Trades';
import { Settings } from './pages/Settings';
import { RiskReport } from './pages/RiskReport';
import { BotPerformance } from './pages/BotPerformance';
import { BotDetails } from './pages/BotDetails';
import { BotManagement } from './pages/BotManagement';
import { SalesCommission } from './pages/SalesCommission';
import { Clients } from './pages/Clients';
import { Exchanges } from './pages/Exchanges';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 1,
      refetchOnWindowFocus: false
    }
  }
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route element={<Navbar />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/trades" element={<Trades />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/risk-report" element={<RiskReport />} />
            <Route path="/bot-performance" element={<BotPerformance />} />
            <Route path="/bot-performance/:botType" element={<BotDetails />} />
            <Route path="/bot-management" element={<BotManagement />} />
            <Route path="/sales-commission" element={<SalesCommission />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/exchanges" element={<Exchanges />} />
          </Route>
        </Routes>
      </Router>
    </QueryClientProvider>
  );
}

export default App;