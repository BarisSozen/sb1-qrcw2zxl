import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabaseClient';
import { Key, RefreshCw, AlertTriangle, CheckCircle, XCircle, Eye, EyeOff } from 'lucide-react';

const SUPPORTED_EXCHANGES = [
  { id: 'binance', name: 'Binance', icon: '💰', requiresPassphrase: false },
  { id: 'bybit', name: 'Bybit', icon: '🔄', requiresPassphrase: false },
  { id: 'okx', name: 'OKX', icon: '📊', requiresPassphrase: true },
  { id: 'deribit', name: 'Deribit', icon: '🎯', requiresPassphrase: false }
] as const;

interface ExchangeApiKey {
  id: string;
  exchange: typeof SUPPORTED_EXCHANGES[number]['id'];
  api_key: string;
  active: boolean;
  created_at: string;
}

export const Exchanges = () => {
  const queryClient = useQueryClient();
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});

  // Fetch API keys
  const { data: apiKeys, isLoading } = useQuery({
    queryKey: ['exchange-api-keys'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('exchange_api_keys')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as ExchangeApiKey[];
    }
  });

  // Toggle API key status mutation
  const toggleApiKey = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase
        .from('exchange_api_keys')
        .update({ active })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exchange-api-keys'] });
    }
  });

  // Delete API key mutation
  const deleteApiKey = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('exchange_api_keys')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exchange-api-keys'] });
    }
  });

  // Rotate API key mutation
  const rotateApiKey = useMutation({
    mutationFn: async ({ id, newApiKey, newApiSecret, newPassphrase }: {
      id: string;
      newApiKey: string;
      newApiSecret: string;
      newPassphrase?: string;
    }) => {
      const { error } = await supabase
        .from('exchange_api_keys')
        .update({
          api_key: newApiKey,
          api_secret: newApiSecret,
          passphrase: newPassphrase || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exchange-api-keys'] });
    }
  });

  const handleToggleKey = async (id: string, currentStatus: boolean) => {
    await toggleApiKey.mutateAsync({ id, active: !currentStatus });
  };

  const handleDeleteKey = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this API key?')) {
      await deleteApiKey.mutateAsync(id);
    }
  };

  const handleRotateKey = async (id: string) => {
    const exchange = apiKeys?.find(key => key.id === id)?.exchange;
    if (!exchange) return;

    const requiresPassphrase = SUPPORTED_EXCHANGES.find(e => e.id === exchange)?.requiresPassphrase;

    const newApiKey = window.prompt('Enter new API key:');
    if (!newApiKey) return;

    const newApiSecret = window.prompt('Enter new API secret:');
    if (!newApiSecret) return;

    let newPassphrase;
    if (requiresPassphrase) {
      newPassphrase = window.prompt('Enter new passphrase:');
      if (!newPassphrase) return;
    }

    await rotateApiKey.mutateAsync({
      id,
      newApiKey,
      newApiSecret,
      newPassphrase
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Exchange API Keys</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {SUPPORTED_EXCHANGES.map(exchange => {
          const exchangeKeys = apiKeys?.filter(key => key.exchange === exchange.id) || [];
          const activeKeys = exchangeKeys.filter(key => key.active).length;
          
          return (
            <div key={exchange.id} className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center">
                  <span className="mr-2">{exchange.icon}</span>
                  {exchange.name}
                </h3>
                {activeKeys > 0 ? (
                  <CheckCircle className="text-green-500" />
                ) : (
                  <AlertTriangle className="text-yellow-500" />
                )}
              </div>
              <p className="text-3xl font-bold mt-2">{exchangeKeys.length}</p>
              <p className="text-sm text-gray-500">
                {activeKeys} active / {exchangeKeys.length} total
              </p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-4 py-5 sm:px-6">
          <h2 className="text-xl font-semibold">API Keys</h2>
        </div>
        <div className="border-t border-gray-200">
          <table className="min-w-full">
            <thead>
              <tr className="border-b">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Exchange
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  API Key
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                    Loading API keys...
                  </td>
                </tr>
              ) : apiKeys?.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                    No API keys found. Add API keys through the Clients page.
                  </td>
                </tr>
              ) : (
                apiKeys?.map((key) => (
                  <tr key={key.id} className="border-b">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <span className="mr-2">
                          {SUPPORTED_EXCHANGES.find(e => e.id === key.exchange)?.icon}
                        </span>
                        <span className="font-medium">
                          {SUPPORTED_EXCHANGES.find(e => e.id === key.exchange)?.name}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap font-mono text-sm">
                      {showSecrets[key.id] ? key.api_key : '••••' + key.api_key.slice(-4)}
                      <button
                        onClick={() => setShowSecrets(prev => ({ ...prev, [key.id]: !prev[key.id] }))}
                        className="ml-2 text-gray-400 hover:text-gray-600"
                      >
                        {showSecrets[key.id] ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(key.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        key.active
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {key.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleToggleKey(key.id, key.active)}
                        className={`p-1 rounded-full ${
                          key.active
                            ? 'text-red-600 hover:text-red-900'
                            : 'text-green-600 hover:text-green-900'
                        }`}
                      >
                        {key.active ? (
                          <XCircle className="w-4 h-4" />
                        ) : (
                          <CheckCircle className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        onClick={() => handleRotateKey(key.id)}
                        className="p-1 rounded-full text-blue-600 hover:text-blue-900 ml-2"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteKey(key.id)}
                        className="p-1 rounded-full text-red-600 hover:text-red-900 ml-2"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Exchanges;