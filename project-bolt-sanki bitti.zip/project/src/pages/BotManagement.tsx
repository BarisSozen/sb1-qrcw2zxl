import React, { useState } from 'react';
import { Play, Square, Plus, Edit2, Trash2, AlertCircle, Users, X, TrendingUp, Network } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabaseClient';
import type { BotConfig, BotType } from '../types/bots';
import type { Client } from '../types/api';

const SUPPORTED_EXCHANGES = [
  { id: 'binance', name: 'Binance' },
  { id: 'bybit', name: 'Bybit' },
  { id: 'okx', name: 'OKX' },
  { id: 'deribit', name: 'Deribit' },
  { id: 'uniswap', name: 'Uniswap' }
] as const;

const TRADING_PAIRS = [
  { id: 'BTC/USD', name: 'Bitcoin/USD' },
  { id: 'ETH/USD', name: 'Ethereum/USD' },
  { id: 'SOL/USD', name: 'Solana/USD' },
  { id: 'BNB/USD', name: 'BNB/USD' },
  { id: 'AVAX/USD', name: 'Avalanche/USD' },
  { id: 'USDT/USD', name: 'USDT/USD' },
  { id: 'USDC/USD', name: 'USDC/USD' },
  { id: 'DAI/USD', name: 'DAI/USD' }
] as const;

interface PairCorrelation {
  pair1: string;
  pair2: string;
  correlation: number;
  lastUpdated: Date;
}

interface CustomPair {
  base: string;
  quote: string;
}

export const BotManagement = () => {
  const [isAddingBot, setIsAddingBot] = useState(false);
  const [isEditingBot, setIsEditingBot] = useState<string | null>(null);
  const [isAssigningBot, setIsAssigningBot] = useState<string | null>(null);
  const [selectedPairs, setSelectedPairs] = useState<string[]>([]);
  const [selectedExchanges, setSelectedExchanges] = useState<string[]>([]);
  const [customPairs, setCustomPairs] = useState<CustomPair[]>([]);
  const [botType, setBotType] = useState<BotType>('basis');
  const queryClient = useQueryClient();

  // Mock correlation data - in production this would come from ML service
  const [correlationData, setCorrelationData] = useState<PairCorrelation[]>([
    {
      pair1: 'BTC/USD',
      pair2: 'ETH/USD',
      correlation: 0.85,
      lastUpdated: new Date()
    },
    {
      pair1: 'ETH/USD',
      pair2: 'SOL/USD',
      correlation: 0.72,
      lastUpdated: new Date()
    }
  ]);

  const { data: botsWithAssignments, isLoading } = useQuery({
    queryKey: ['bots-with-assignments'],
    queryFn: async () => {
      const { data: assignments, error: assignmentsError } = await supabase
        .from('active_bot_assignments')
        .select('*');

      if (assignmentsError) throw assignmentsError;

      const { data: bots,  error: botsError } = await supabase
        .from('bot_configs')
        .select('*')
        .order('created_at', { ascending: false });

      if (botsError) throw botsError;

      return bots.map(bot => ({
        ...bot,
        assignment: assignments?.find(a => a.bot_id === bot.id)
      }));
    }
  });

  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('active', true)
        .order('name');

      if (error) throw error;
      return data as Client[];
    }
  });

  const assignBot = useMutation({
    mutationFn: async ({ botId, clientId, notes }: { botId: string; clientId: string; notes?: string }) => {
      const { error: deactivateError } = await supabase
        .from('bot_assignments')
        .update({ status: 'inactive', unassigned_at: new Date().toISOString() })
        .eq('bot_id', botId)
        .eq('status', 'active');

      if (deactivateError) throw deactivateError;

      const { error: assignError } = await supabase
        .from('bot_assignments')
        .insert([{
          bot_id: botId,
          client_id: clientId,
          status: 'active',
          notes
        }]);

      if (assignError) throw assignError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots-with-assignments'] });
      setIsAssigningBot(null);
    }
  });

  const unassignBot = useMutation({
    mutationFn: async (botId: string) => {
      const { error } = await supabase
        .from('bot_assignments')
        .update({ status: 'inactive', unassigned_at: new Date().toISOString() })
        .eq('bot_id', botId)
        .eq('status', 'active');

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots-with-assignments'] });
    }
  });

  const updateBotStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: 'running' | 'stopped' }) => {
      const { error } = await supabase
        .from('bot_configs')
        .update({ status })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots-with-assignments'] });
    }
  });

  const deleteBot = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('bot_configs')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots-with-assignments'] });
    }
  });

  const handleStartStop = async (bot: BotConfig) => {
    const newStatus = bot.status === 'running' ? 'stopped' : 'running';
    await updateBotStatus.mutateAsync({ id: bot.id, status: newStatus });
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this bot?')) {
      await deleteBot.mutateAsync(id);
    }
  };

  const handleAssign = async (botId: string, clientId: string, notes?: string) => {
    await assignBot.mutateAsync({ botId, clientId, notes });
  };

  const handleUnassign = async (botId: string) => {
    if (window.confirm('Are you sure you want to unassign this bot?')) {
      await unassignBot.mutateAsync(botId);
    }
  };

  const handlePairSelection = (pair: string) => {
    if (selectedPairs.includes(pair)) {
      setSelectedPairs(selectedPairs.filter(p => p !== pair));
    } else if (botType === 'triangular' && selectedPairs.length < 3) {
      setSelectedPairs([...selectedPairs, pair]);
    } else if (selectedPairs.length < 2) {
      setSelectedPairs([...selectedPairs, pair]);
    }
  };

  const handleExchangeSelection = (exchange: string) => {
    if (selectedExchanges.includes(exchange)) {
      setSelectedExchanges(selectedExchanges.filter(e => e !== exchange));
    } else {
      setSelectedExchanges([...selectedExchanges, exchange]);
    }
  };

  const addCustomPair = () => {
    setCustomPairs([...customPairs, { base: '', quote: '' }]);
  };

  const updateCustomPair = (index: number, field: 'base' | 'quote', value: string) => {
    const updatedPairs = [...customPairs];
    updatedPairs[index][field] = value.toUpperCase();
    setCustomPairs(updatedPairs);
  };

  const removeCustomPair = (index: number) => {
    setCustomPairs(customPairs.filter((_, i) => i !== index));
  };

  const getCorrelation = (pair1: string, pair2: string) => {
    return correlationData.find(
      c => (c.pair1 === pair1 && c.pair2 === pair2) || 
           (c.pair1 === pair2 && c.pair2 === pair1)
    )?.correlation || 0;
  };

  const renderCorrelationIndicator = (correlation: number) => {
    const color = correlation > 0.7 ? 'text-green-500' : 
                 correlation > 0.5 ? 'text-yellow-500' : 
                 'text-red-500';
    return (
      <div className="flex items-center">
        <TrendingUp className={`w-4 h-4 mr-2 ${color}`} />
        <span className={color}>{(correlation * 100).toFixed(1)}%</span>
      </div>
    );
  };

  const getBotTypeColor = (type: BotType) => {
    switch (type) {
      case 'basis':
        return 'text-blue-600';
      case 'perpetual':
        return 'text-purple-600';
      case 'dex':
        return 'text-green-600';
      case 'statistical':
        return 'text-orange-600';
      case 'triangular':
        return 'text-indigo-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return 'bg-green-100 text-green-800';
      case 'stopped':
        return 'bg-gray-100 text-gray-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleBotTypeChange = (type: BotType) => {
    setBotType(type);
    setSelectedPairs([]);
    if (type === 'triangular') {
      setSelectedExchanges(['uniswap']);
    } else {
      setSelectedExchanges([]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Bot Management</h1>
        <button
          onClick={() => setIsAddingBot(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Bot
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Active Bots</h3>
          <p className="text-3xl font-bold text-green-600">
            {botsWithAssignments?.filter(bot => bot.status === 'running').length || 0}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Total Bots</h3>
          <p className="text-3xl font-bold text-blue-600">
            {botsWithAssignments?.length || 0}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Bots with Errors</h3>
          <p className="text-3xl font-bold text-red-600">
            {botsWithAssignments?.filter(bot => bot.status === 'error').length || 0}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Assigned Bots</h3>
          <p className="text-3xl font-bold text-purple-600">
            {botsWithAssignments?.filter(bot => bot.assignment).length || 0}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-4 py-5 sm:px-6">
          <h2 className="text-xl font-semibold">Configured Bots</h2>
        </div>
        <div className="border-t border-gray-200">
          <table className="min-w-full">
            <thead>
              <tr className="border-b">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Assigned To
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Profit Threshold
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Position Limit
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {botsWithAssignments?.map((bot) => (
                <tr key={bot.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {bot.name}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${getBotTypeColor(bot.type)}`}>
                      {bot.type.toUpperCase()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {bot.assignment ? (
                      <div className="flex items-center">
                        <div className="text-sm text-gray-900">{bot.assignment.client_name}</div>
                        <button
                          onClick={() => handleUnassign(bot.id)}
                          className="ml-2 text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setIsAssigningBot(bot.id)}
                        className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <Users className="w-4 h-4 mr-1" />
                        Assign
                      </button>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(bot.status)}`}>
                      {bot.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {bot.min_profit_threshold}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${bot.max_position_size.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => handleStartStop(bot)}
                        className={`p-1 rounded-full ${
                          bot.status === 'running'
                            ? 'text-red-600 hover:text-red-900'
                            : 'text-green-600 hover:text-green-900'
                        }`}
                      >
                        {bot.status === 'running' ? (
                          <Square className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        onClick={() => setIsEditingBot(bot.id)}
                        className="p-1 rounded-full text-blue-600 hover:text-blue-900"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(bot.id)}
                        className="p-1 rounded-full text-red-600 hover:text-red-900"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {(isAddingBot || isEditingBot) && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">
                {isEditingBot ? 'Edit Bot' : 'Add New Bot'}
              </h3>
              <button
                onClick={() => {
                  setIsAddingBot(false);
                  setIsEditingBot(null);
                  setSelectedPairs([]);
                  setSelectedExchanges([]);
                  setBotType('basis');
                  setCustomPairs([]);
                }}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              // Form submission logic here
            }}>
              <div className="space-y-6">
                {/* Basic Information */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-md font-medium mb-4">Basic Information</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Name</label>
                      <input
                        type="text"
                        name="name"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Type</label>
                      <select
                        name="type"
                        value={botType}
                        onChange={(e) => handleBotTypeChange(e.target.value as BotType)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                      >
                        <option value="basis">Basis Arbitrage</option>
                        <option value="perpetual">Perpetual Arbitrage</option>
                        <option value="dex">DEX Arbitrage</option>
                        <option value="statistical">Statistical Arbitrage</option>
                        <option value="triangular">Triangular Arbitrage</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Trading Pairs Selection */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-md font-medium">Trading Pairs</h4>
                    <button
                      type="button"
                      onClick={addCustomPair}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add Custom Pair
                    </button>
                  </div>
                  
                  <p className="text-sm text-gray-500 mb-4">
                    {botType === 'triangular' 
                      ? 'Select exactly three trading pairs to form a triangular arbitrage opportunity.'
                      : 'Select exactly two trading pairs. Their correlation will be monitored in real-time.'}
                  </p>

                  {/* Standard Pairs */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                    {TRADING_PAIRS.map(pair => (
                      <label key={pair.id} className="relative flex items-center">
                        <input
                          type="checkbox"
                          checked={selectedPairs.includes(pair.id)}
                          onChange={() => handlePairSelection(pair.id)}
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          disabled={
                            !selectedPairs.includes(pair.id) && 
                            ((botType === 'triangular' && selectedPairs.length >= 3) ||
                             (botType !== 'triangular' && selectedPairs.length >= 2))
                          }
                        />
                        <span className="ml-2 text-sm text-gray-700">{pair.name}</span>
                      </label>
                    ))}
                  </div>

                  {/* Custom Pairs */}
                  {customPairs.length > 0 && (
                    <div className="space-y-4 mt-4 border-t pt-4">
                      <h5 className="text-sm font-medium text-gray-700">Custom Pairs</h5>
                      {customPairs.map((pair, index) => (
                        <div key={index} className="flex items-center space-x-4">
                          <div className="flex-1">
                            <input
                              type="text"
                              value={pair.base}
                              onChange={(e) => updateCustomPair(index, 'base', e.target.value)}
                              placeholder="Base (e.g., BTC)"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            />
                          </div>
                          <div className="flex-none">/</div>
                          <div className="flex-1">
                            <input
                              type="text"
                              value={pair.quote}
                              onChange={(e) => updateCustomPair(index, 'quote', e.target.value)}
                              placeholder="Quote (e.g., USD)"
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => removeCustomPair(index)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {botType === 'triangular' && selectedPairs.length === 3 && (
                    <div className="mt-4 p-4 bg-indigo-50 rounded-lg">
                      <h5 className="text-sm font-medium text-indigo-900 mb-2">Triangular Arbitrage Path</h5>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Network className="w-5 h-5 text-indigo-500" />
                          <span className="text-sm text-indigo-700">
                            {selectedPairs[0]} → {selectedPairs[1]} → {selectedPairs[2]} → {selectedPairs[0]}
                          </span>
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-indigo-600">
                        Using Bellman-Ford algorithm to find optimal arbitrage paths
                      </p>
                    </div>
                  )}

                  {botType !== 'triangular' && selectedPairs.length === 2 && (
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                      <h5 className="text-sm font-medium text-blue-900 mb-2">Correlation Analysis</h5>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-blue-700">
                          {selectedPairs[0]} ↔ {selectedPairs[1]}
                        </span>
                        {renderCorrelationIndicator(getCorrelation(selectedPairs[0], selectedPairs[1]))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Exchange Selection */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-md font-medium">Exchanges</h4>
                    <button
                      type="button"
                      onClick={() => setSelectedExchanges([...selectedExchanges, ''])}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                      disabled={botType === 'triangular'}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add Exchange
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">
                    {botType === 'triangular' 
                      ? 'Triangular arbitrage is currently optimized for Uniswap.'
                      : 'Select the exchanges where the bot will operate.'}
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {SUPPORTED_EXCHANGES.map(exchange => (
                      <label 
                        key={exchange.id} 
                        className={`relative flex items-center ${
                          botType === 'triangular' && exchange.id !== 'uniswap' 
                            ? 'opacity-50 cursor-not-allowed' 
                            : ''
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedExchanges.includes(exchange.id)}
                          onChange={() => handleExchangeSelection(exchange.id)}
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          disabled={botType === 'triangular' && exchange.id !== 'uniswap'}
                        />
                        <span className="ml-2 text-sm text-gray-700">{exchange.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Risk Parameters */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-md font-medium mb-4">Risk Parameters</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Minimum Profit Threshold (%)
                      </label>
                      <input
                        type="number"
                        name="minProfitThreshold"
                        step="0.1"
                        min="0"
                        max="100"
                        defaultValue={botType === 'triangular' ? '0.3' : '0.1'}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                      {botType === 'triangular' && (
                        <p className="mt-1 text-xs text-gray-500">
                          Includes gas fees and exchange fees in calculation
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Maximum Position Size (USD)
                      </label>
                      <input
                        type="number"
                        name="maxPositionSize"
                        min="100"
                        step="100"
                        defaultValue="10000"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        {botType === 'triangular' ? 'Max Gas Price (Gwei)' : 'Leverage Limit'}
                      </label>
                      <input
                        type="number"
                        name={botType === 'triangular' ? 'maxGasPrice' : 'leverageLimit'}
                        step="0.1"
                        min={botType === 'triangular' ? '1' : '1'}
                        max={botType === 'triangular' ? '500' : '100'}
                        defaultValue={botType === 'triangular' ? '50' : '3'}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                      />
                    </div>
                    {botType !== 'triangular' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Correlation Threshold
                        </label>
                        <input
                          type="number"
                          name="correlationThreshold"
                          step="0.1"
                          min="0"
                          max="1"
                          defaultValue="0.7"
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          required
                        />
                        <p className="mt-1 text-sm text-gray-500">
                          Minimum correlation coefficient to maintain positions
                        </p>
                      </div>
                    )}
                    {botType === 'triangular' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Max Slippage (%)
                        </label>
                        <input
                          type="number"
                          name="maxSlippage"
                          step="0.1"
                          min="0.1"
                          max="5"
                          defaultValue="1"
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          required
                        />
                        <p className="mt-1 text-sm text-gray-500">
                          Maximum allowed slippage per swap
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddingBot(false);
                    setIsEditingBot(null);
                    setSelectedPairs([]);
                    setSelectedExchanges([]);
                    setBotType('basis');
                    setCustomPairs([]);
                  }}
                  className="px-4 py-2 border rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  {isEditingBot ? 'Save Changes' : 'Add Bot'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAssigningBot && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-medium mb-4">Assign Bot to Client</h3>
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              handleAssign(
                isAssigningBot,
                formData.get('client_id') as string,
                formData.get('notes') as string
              );
            }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Client
                  </label>
                  <select
                    name="client_id"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  >
                    <option value="">Select a client</option>
                    {clients?.map(client => (
                      <option key={client.id} value={client.id}>
                        {client.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Notes
                  </label>
                  <textarea
                    name="notes"
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="Add any notes about this assignment..."
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsAssigningBot(null)}
                  className="px-4 py-2 border rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Assign Bot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BotManagement;