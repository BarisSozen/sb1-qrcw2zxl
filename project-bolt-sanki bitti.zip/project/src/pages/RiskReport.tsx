import React, { useState, useEffect } from 'react';
import { useSecurityReport } from '../hooks/useSecurityReport';
import { useRiskMetrics } from '../hooks/useRiskMetrics';
import { AlertTriangle, AlertOctagon, CheckCircle, XCircle, Shield, Activity, Zap, Lock, Server, Download, TrendingUp, TrendingDown, DollarSign, Percent } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

export const RiskReport = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('24h');
  const {
    systemStatus,
    securityMetrics,
    recentIncidents,
    isKillSwitchActive,
    toggleKillSwitch
  } = useSecurityReport();

  const riskMetrics = useRiskMetrics();

  // Calculate overall risk score
  const calculateOverallRisk = () => {
    const positionRisk = (
      riskMetrics.positionMetrics.positionConcentration +
      riskMetrics.positionMetrics.crossExchangeExposure +
      riskMetrics.positionMetrics.positionCorrelation
    ) / 3;

    const leverageRisk = (
      riskMetrics.leverageMetrics.avgLeverageRatio / 10 +
      riskMetrics.leverageMetrics.marginUtilization +
      riskMetrics.leverageMetrics.liquidationRisk
    ) / 3;

    const executionRisk = (
      riskMetrics.executionMetrics.slippageImpact +
      (1 - riskMetrics.executionMetrics.orderFillRate) +
      (riskMetrics.executionMetrics.executionLatency / 1000)
    ) / 3;

    const counterpartyRisk = (
      riskMetrics.counterpartyMetrics.exchangeConcentration +
      riskMetrics.counterpartyMetrics.settlementRisk +
      riskMetrics.counterpartyMetrics.custodyRisk
    ) / 3;

    return (positionRisk + leverageRisk + executionRisk + counterpartyRisk) / 4;
  };

  const getRiskLevel = (value: number): 'low' | 'medium' | 'high' => {
    if (value < 0.3) return 'low';
    if (value < 0.7) return 'medium';
    return 'high';
  };

  const getRiskColor = (value: number): string => {
    if (value < 0.3) return 'text-green-500';
    if (value < 0.7) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getProgressColor = (value: number): string => {
    if (value < 0.3) return 'bg-green-500';
    if (value < 0.7) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const formatMetric = (value: number): string => {
    return (value * 100).toFixed(1) + '%';
  };

  const formatLatency = (value: number): string => {
    return value.toFixed(0) + 'ms';
  };

  const radarData = [
    { metric: 'Position Risk', value: (riskMetrics.positionMetrics.positionConcentration + riskMetrics.positionMetrics.crossExchangeExposure) / 2 },
    { metric: 'Leverage Risk', value: riskMetrics.leverageMetrics.avgLeverageRatio / 10 },
    { metric: 'Execution Risk', value: (riskMetrics.executionMetrics.slippageImpact + (1 - riskMetrics.executionMetrics.orderFillRate)) / 2 },
    { metric: 'Counterparty Risk', value: (riskMetrics.counterpartyMetrics.exchangeConcentration + riskMetrics.counterpartyMetrics.settlementRisk) / 2 },
    { metric: 'Liquidity Risk', value: 1 - riskMetrics.executionMetrics.orderFillRate }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Risk Report</h1>
        <div className="flex space-x-4">
          <select
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
            className="px-4 py-2 border rounded-lg shadow-sm focus:border-brand-500 focus:ring-brand-500"
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
          <button
            onClick={toggleKillSwitch}
            className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
              isKillSwitchActive ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isKillSwitchActive ? (
              <>
                <XCircle className="w-4 h-4 mr-2" />
                System Halted - Click to Resume
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                System Active - Click to Halt
              </>
            )}
          </button>
        </div>
      </div>

      {/* Risk Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Overall Risk Score</h3>
          <div className="flex items-center space-x-2">
            <div className="text-3xl font-bold text-brand-600">
              {formatMetric(calculateOverallRisk())}
            </div>
            <div className={`text-sm ${getRiskColor(calculateOverallRisk())}`}>
              {getRiskLevel(calculateOverallRisk()).toUpperCase()}
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Position Risk</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Concentration</span>
              <span className={getRiskColor(riskMetrics.positionMetrics.positionConcentration)}>
                {formatMetric(riskMetrics.positionMetrics.positionConcentration)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Cross-Exchange</span>
              <span className={getRiskColor(riskMetrics.positionMetrics.crossExchangeExposure)}>
                {formatMetric(riskMetrics.positionMetrics.crossExchangeExposure)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Correlation</span>
              <span className={getRiskColor(riskMetrics.positionMetrics.positionCorrelation)}>
                {formatMetric(riskMetrics.positionMetrics.positionCorrelation)}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Leverage Risk</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Avg Leverage</span>
              <span className={getRiskColor(riskMetrics.leverageMetrics.avgLeverageRatio / 10)}>
                {riskMetrics.leverageMetrics.avgLeverageRatio.toFixed(1)}x
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Margin Usage</span>
              <span className={getRiskColor(riskMetrics.leverageMetrics.marginUtilization)}>
                {formatMetric(riskMetrics.leverageMetrics.marginUtilization)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Liquidation Risk</span>
              <span className={getRiskColor(riskMetrics.leverageMetrics.liquidationRisk)}>
                {formatMetric(riskMetrics.leverageMetrics.liquidationRisk)}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Execution Risk</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Slippage</span>
              <span className={getRiskColor(riskMetrics.executionMetrics.slippageImpact)}>
                {formatMetric(riskMetrics.executionMetrics.slippageImpact)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Fill Rate</span>
              <span className={getRiskColor(1 - riskMetrics.executionMetrics.orderFillRate)}>
                {formatMetric(riskMetrics.executionMetrics.orderFillRate)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Latency</span>
              <span className={getRiskColor(riskMetrics.executionMetrics.executionLatency / 1000)}>
                {formatLatency(riskMetrics.executionMetrics.executionLatency)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Risk Radar Chart */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Risk Analysis</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="metric" />
              <PolarRadiusAxis domain={[0, 1]} />
              <Radar
                name="Risk Profile"
                dataKey="value"
                stroke="#8884d8"
                fill="#8884d8"
                fillOpacity={0.6}
              />
              <Tooltip formatter={(value) => formatMetric(value as number)} />
              <Legend />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Detailed Risk Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Position Metrics</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Position Concentration</span>
                <span className={`text-sm ${getRiskColor(riskMetrics.positionMetrics.positionConcentration)}`}>
                  {formatMetric(riskMetrics.positionMetrics.positionConcentration)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${getProgressColor(riskMetrics.positionMetrics.positionConcentration)} h-2 rounded-full`}
                  style={{ width: `${riskMetrics.positionMetrics.positionConcentration * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Cross-Exchange Exposure</span>
                <span className={`text-sm ${getRiskColor(riskMetrics.positionMetrics.crossExchangeExposure)}`}>
                  {formatMetric(riskMetrics.positionMetrics.crossExchangeExposure)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${getProgressColor(riskMetrics.positionMetrics.crossExchangeExposure)} h-2 rounded-full`}
                  style={{ width: `${riskMetrics.positionMetrics.crossExchangeExposure * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Position Correlation</span>
                <span className={`text-sm ${getRiskColor(riskMetrics.positionMetrics.positionCorrelation)}`}>
                  {formatMetric(riskMetrics.positionMetrics.positionCorrelation)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${getProgressColor(riskMetrics.positionMetrics.positionCorrelation)} h-2 rounded-full`}
                  style={{ width: `${riskMetrics.positionMetrics.positionCorrelation * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Counterparty Risk</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Exchange Concentration</span>
                <span className={`text-sm ${getRiskColor(riskMetrics.counterpartyMetrics.exchangeConcentration)}`}>
                  {formatMetric(riskMetrics.counterpartyMetrics.exchangeConcentration)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${getProgressColor(riskMetrics.counterpartyMetrics.exchangeConcentration)} h-2 rounded-full`}
                  style={{ width: `${riskMetrics.counterpartyMetrics.exchangeConcentration * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Settlement Risk</span>
                <span className={`text-sm ${getRiskColor(riskMetrics.counterpartyMetrics.settlementRisk)}`}>
                  {formatMetric(riskMetrics.counterpartyMetrics.settlementRisk)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${getProgressColor(riskMetrics.counterpartyMetrics.settlementRisk)} h-2 rounded-full`}
                  style={{ width: `${riskMetrics.counterpartyMetrics.settlementRisk * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Custody Risk</span>
                <span className={`text-sm ${getRiskColor(riskMetrics.counterpartyMetrics.custodyRisk)}`}>
                  {formatMetric(riskMetrics.counterpartyMetrics.custodyRisk)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${getProgressColor(riskMetrics.counterpartyMetrics.custodyRisk)} h-2 rounded-full`}
                  style={{ width: `${riskMetrics.counterpartyMetrics.custodyRisk * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Security Incidents */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Recent Security Incidents</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3">Time</th>
                <th className="text-left py-3">Type</th>
                <th className="text-left py-3">Description</th>
                <th className="text-left py-3">Risk Level</th>
                <th className="text-left py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentIncidents.map((incident, index) => (
                <tr key={index} className="border-b">
                  <td className="py-3">{new Date(incident.timestamp).toLocaleString()}</td>
                  <td className="py-3">{incident.type}</td>
                  <td className="py-3">{incident.description}</td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      incident.riskLevel === 'high' 
                        ? 'bg-red-100 text-red-800'
                        : incident.riskLevel === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                    }`}>
                      {incident.riskLevel.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      incident.status === 'resolved'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {incident.status.toUpperCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RiskReport;