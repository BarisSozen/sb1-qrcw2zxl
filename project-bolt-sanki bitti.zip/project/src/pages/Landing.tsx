import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sigma, BrainCircuit, LineChart, Bot, Shield, Activity, Zap } from 'lucide-react';

export const Landing = () => {
  return (
    <div className="min-h-screen bg-brand">
      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 z-10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-2xl font-bold text-white">
              Dow Digital
            </Link>
            <Link 
              to="/dashboard" 
              className="px-6 py-2 text-sm font-medium text-white bg-transparent border border-white/20 rounded-lg hover:bg-white/10 transition-colors"
            >
              Launch App
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div 
        className="relative min-h-screen flex items-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-brand/90 to-brand/70" />
        
        <div className="container mx-auto px-6 relative z-10 pt-20">
          <div className="max-w-3xl">
            <h1 className="text-6xl font-bold text-white mb-6 leading-tight">
              Dow Digital Capital
              <span className="block text-4xl mt-4">Quantitative Trading</span>
              <span className="block text-accent mt-2">Redefined</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Harness the power of advanced mathematical models and real-time data analysis 
              to execute sophisticated basis arbitrage strategies across multiple exchanges.
            </p>
            <div className="flex gap-4">
              <Link
                to="/dashboard"
                className="inline-flex items-center px-8 py-4 text-lg font-medium text-brand bg-accent hover:bg-accent-300 rounded-lg transition-colors"
              >
                Launch App
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <a
                href="#learn-more"
                className="inline-flex items-center px-8 py-4 text-lg font-medium text-white border-2 border-white/20 rounded-lg hover:bg-white/10 transition-colors"
              >
                Learn More
              </a>
            </div>
          </div>

          <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10">
              <div className="text-4xl font-bold text-accent mb-2">$1M+</div>
              <div className="text-gray-300">Daily Trading Volume</div>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10">
              <div className="text-4xl font-bold text-accent mb-2">99.9%</div>
              <div className="text-gray-300">System Uptime</div>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10">
              <div className="text-4xl font-bold text-accent mb-2">0.5s</div>
              <div className="text-gray-300">Average Execution Time</div>
            </div>
          </div>
        </div>
      </div>

      {/* Learn More Section */}
      <div id="learn-more" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-4 text-brand">
            Advanced Trading Strategies
          </h2>
          <p className="text-xl text-center text-gray-600 mb-16 max-w-3xl mx-auto">
            Our platform leverages cutting-edge technology and sophisticated algorithms to execute 
            profitable trades across multiple venues.
          </p>

          {/* Trading Bots Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
            <div className="bg-gray-50 rounded-lg p-8 border border-gray-200">
              <Bot className="w-12 h-12 text-blue-600 mb-6" />
              <h3 className="text-2xl font-bold mb-4">CEX Basis Arbitrage</h3>
              <p className="text-gray-600 mb-6">
                Exploits price differences between spot and futures markets on centralized exchanges 
                using advanced funding rate optimization and high-frequency trading capabilities.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2 text-blue-600" />
                  Cross-exchange basis trading
                </li>
                <li className="flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2 text-blue-600" />
                  Funding rate optimization
                </li>
                <li className="flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2 text-blue-600" />
                  High-frequency execution
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 rounded-lg p-8 border border-gray-200">
              <Zap className="w-12 h-12 text-purple-600 mb-6" />
              <h3 className="text-2xl font-bold mb-4">DEX Basis Arbitrage</h3>
              <p className="text-gray-600 mb-6">
                Performs basis arbitrage exclusively on decentralized exchanges with built-in 
                MEV protection and optimized gas usage through smart contract interaction.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2 text-purple-600" />
                  Smart contract optimization
                </li>
                <li className="flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2 text-purple-600" />
                  MEV protection mechanisms
                </li>
                <li className="flex items-center">
                  <ArrowRight className="w-4 h-4 mr-2 text-purple-600" />
                  Flash loan integration
                </li>
              </ul>
            </div>
          </div>

          {/* Machine Learning Section */}
          <div className="bg-brand text-white rounded-lg p-12 mb-20">
            <div className="max-w-4xl mx-auto">
              <BrainCircuit className="w-16 h-16 text-accent mb-8" />
              <h3 className="text-3xl font-bold mb-6">Machine Learning Integration</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-xl font-semibold mb-4 text-accent">Market Analysis</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <ArrowRight className="w-4 h-4 mr-2 mt-1 text-accent" />
                      <span>LSTM networks for time series analysis and price prediction</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-4 h-4 mr-2 mt-1 text-accent" />
                      <span>Gradient Boosting for feature importance identification</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-4 h-4 mr-2 mt-1 text-accent" />
                      <span>Random Forests for market regime classification</span>
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-xl font-semibold mb-4 text-accent">Risk Assessment</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <ArrowRight className="w-4 h-4 mr-2 mt-1 text-accent" />
                      <span>Isolation Forests for anomaly detection</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-4 h-4 mr-2 mt-1 text-accent" />
                      <span>Deep Q-Networks for order execution optimization</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-4 h-4 mr-2 mt-1 text-accent" />
                      <span>CNN and RNN models for pattern recognition</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Risk Management Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            <div className="text-center">
              <Shield className="w-12 h-12 mx-auto text-green-600 mb-6" />
              <h3 className="text-xl font-bold mb-4">Risk Management</h3>
              <p className="text-gray-600">
                Comprehensive risk controls including position monitoring, drawdown management, 
                and dynamic position sizing based on real-time risk metrics.
              </p>
            </div>

            <div className="text-center">
              <Activity className="w-12 h-12 mx-auto text-blue-600 mb-6" />
              <h3 className="text-xl font-bold mb-4">Performance Monitoring</h3>
              <p className="text-gray-600">
                Real-time tracking of key performance indicators including win rates, PnL analysis, 
                execution speed, and slippage monitoring.
              </p>
            </div>

            <div className="text-center">
              <Sigma className="w-12 h-12 mx-auto text-purple-600 mb-6" />
              <h3 className="text-xl font-bold mb-4">Statistical Analysis</h3>
              <p className="text-gray-600">
                Advanced statistical methods for opportunity detection, mean reversion strategies, 
                and correlation analysis across markets.
              </p>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Start Trading?</h2>
            <Link
              to="/dashboard"
              className="inline-flex items-center px-8 py-4 text-lg font-medium text-white bg-brand hover:bg-brand-700 rounded-lg transition-colors"
            >
              Launch Trading Platform
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Landing;